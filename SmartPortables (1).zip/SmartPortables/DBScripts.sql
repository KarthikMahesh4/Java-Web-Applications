CREATE DATABASE Sportable

CREATE TABLE Productdetails(
    ProductType Varchar(200) Not NULL,
    Id Varchar(200) Not NULL,
    productName Varchar(200) Not NULL,
    productPrice DECIMAL(15,2),
    productImage Varchar(1000) Not NULL,
    productManufacturer Varchar(200) Not NULL,
    productCondition Varchar(200) Not NULL,
    productDiscount DECIMAL(15,2)
)

CREATE TABLE Product_accessories(
    productName Varchar(200) Not NULL,
    accessoriesName Varchar(200) Not NULL
)

CREATE TABLE customerOrders(
    OrderId INT,
    UserName Varchar(200) Not NULL,
    OrderName Varchar(200) Not NULL,
    OrderPrice DECIMAL(15,2),
    userAddress Varchar(2000) Not NULL,
    creditCardNo Varchar(2000) Not NULL,
    OrderDate DATETIME DEFAULT CURRENT_TIMESTAMP
)

CREATE TABLE Registration(
    username Varchar(200) Not NULL UNIQUE,
    password Varchar(200) Not NULL,
    repassword Varchar(200) Not NULL,
    usertype Varchar(200) Not NULL
)

ALTER TABLE PRODUCTDETAILS ADD COLUMN ITEMCOUNT INT NOT NULL DEFAULT 1


--Mongo DB codes
use CustomerReviews
db.createCollection("myReviews");


DELETE Productdetails
DELETE Product_accessories
DELETE customerOrders
DELETE Registration