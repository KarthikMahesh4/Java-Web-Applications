import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.*;
import java.io.*;
import java.sql.*;

@WebServlet("/SalesManAccount")

public class SalesManAccount extends HttpServlet {
	private String error_msg;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		Utilities utility = new Utilities(request, pw);
		if(!utility.isLoggedin())
		{
				HttpSession session = request.getSession(true);				
				session.setAttribute("login_msg", "Please Login to view account details");
				response.sendRedirect("Login");
				return;
		}
		else{
			displayAccount(request, response);
		}
	}

	/* Display SalesManAccount Details of the SalesMan (Name and Usertype, Orders) */

	protected void displayAccount(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		Utilities utility = new Utilities(request, pw);
		try
         {  
           response.setContentType("text/html");
			/*if(!utility.isLoggedin())
			{
				HttpSession session = request.getSession(true);				
				session.setAttribute("login_msg", "Please Login to add items to cart");
				response.sendRedirect("Login");
				return;
			}*/
			HttpSession session=request.getSession(); 	
			utility.printHtml("Header.html");
		    utility.printHtml("NAV.html");
			pw.print("<section id='content'>  <article>");
			pw.print("<h3 >Account</h3>");
			User user=utility.getUser();
			if(session.getAttribute("Admin_login_msg")!=null){			
				pw.print("<h5 style='color:red'>"+session.getAttribute("Admin_login_msg")+"</h5>");
				session.removeAttribute("Admin_login_msg");
			}
			pw.print("<p><label for='username'>User Name: </label>&nbsp; <span  name='username' >" +user.getName()+ "</span></p> ");
			//pw.print("<p><label for='usertype'>User Type: </label>&nbsp; <span  name='usertype' >" +user.getUsertype()+ "</span></p> ");
			if(user.getUsertype().equals("retailer"))
			   pw.print("<p><label for='usertype'>User Type: </label>&nbsp; <span  name='usertype' >Salesman </span></p> ");
		    else if(user.getUsertype().equals("manager"))
			   pw.print("<p><label for='usertype'>User Type: </label>&nbsp; <span  name='usertype' >Store Manager</span></p> ");
			else if(user.getUsertype().equals("customer")) 
			   pw.print("<p><label for='usertype'>User Type: </label>&nbsp; <span  name='usertype' >Customer</span></p> ");
			pw.print("<p>&nbsp;</p>");
			HashMap<Integer, ArrayList<OrderPayment>> orderPayments = new HashMap<Integer, ArrayList<OrderPayment>>();
			try
		    {
				orderPayments=MySqlDataStoreUtilities.selectOrder();
			}
			catch(Exception e)
			{
			    e.printStackTrace();
			}
			
			int size=0;
			if(user.getUsertype().equals("manager"))
			{
				pw.print("<table>");
				pw.print("<tr>");
				pw.print("<td colspan='4'>");
				pw.print("<form method='get' action='AddProduct'>");
				pw.print("<input type='submit' name='Order' value='Add New Products' class='button'><br/>");
				pw.print("</form>");
				pw.print("</td>");
				pw.print("</tr>");
				
				
				pw.print("<tr>");
				pw.print("<td>");
				pw.print("<form method='get' action='InventoryReport'>");
				pw.print("<input type='submit' name='Order' value='Inventory Report' class='button'><br/>");
				pw.print("</form>");
				pw.print("</td>");
				pw.print("<td>");
				pw.print("<form method='get' action='ProductOnSaleReport'>");
				pw.print("<input type='submit' name='Order' value='Products On Sale' class='button'><br/>");
				pw.print("</form>");
				pw.print("</td>");
				pw.print("<td>");
				pw.print("<form method='get' action='ProductManufacturerRebate'>");
				pw.print("<input type='submit' name='Order' value='Products On Manufacturer Rebate' class='button'><br/>");
				pw.print("</form>");
				pw.print("</td>");
				pw.print("<td>");
				pw.print("<form method='get' action='InventoryBarChart'>");
				pw.print("<input type='submit' name='Order' value='Inventory Bar Chart' class='button'><br/>");
				pw.print("</form>");
				pw.print("</td>");
				pw.print("</tr>");
				
				pw.print("<tr>");
				pw.print("<td>");
				pw.print("<form method='get' action='SalesReportOnProductSold'>");
				pw.print("<input type='submit' name='Order' value='Sales Report On Product Sold' class='button'><br/>");
				pw.print("</form>");
				pw.print("</td>");
				pw.print("<td>");
				pw.print("<form method='get' action='DailySalesTransaction'>");
				pw.print("<input type='submit' name='Order' value='Daily Sales Transaction' class='button'><br/>");
				pw.print("</form>");
				pw.print("</td>");
				pw.print("<td colspan='2'>");
				pw.print("<form method='get' action='SalesBarChart'>");
				pw.print("<input type='submit' name='Order' value='Sales Report Bar Chart' class='button'><br/>");
				pw.print("</form>");
				pw.print("</td>");
				pw.print("</tr>");
				
			
				pw.print("</table>");
			}
			else if(user.getUsertype().equals("retailer"))
			{
				pw.print("<form method='get' action='CreateCustomerAccount'>");
				pw.print("<input type='submit' name='Order' value='Create Customer Account' class='button'><br/>");
				pw.print("</form>");
				for(Map.Entry<Integer, ArrayList<OrderPayment>> entry : orderPayments.entrySet())
				{
					for(OrderPayment od:entry.getValue())	
					{					//if(od.getUserName().equals(user.getName()))
						size= size+1;
					}
				}
				if(size>0)
				{	
					pw.print("<fieldset><legend>Customers Orders</legend> ");
					pw.print("<table cellspacing='0'>");
					pw.print("<tr><th></th>");
					pw.print("<th>Order Id</th>");
					pw.print("<th>UserName</th>");
					pw.print("<th>Product Ordered</th>");
					pw.print("<th>Product Price</th>");
					pw.print("<th>Order Date</th></tr>");
					for(Map.Entry<Integer, ArrayList<OrderPayment>> entry : orderPayments.entrySet())
					{
						for(OrderPayment oi:entry.getValue())
						{							
							pw.print("<form method='get' action='ViewOrder'>");
							pw.print("<tr>");			
							pw.print("<td><input type='radio' name='orderName' value='"+oi.getOrderName()+"'></td>");			
							pw.print("<td>"+oi.getOrderId()+".</td><td>"+oi.getUserName()+"</td><td>"+oi.getOrderName()+"</td><td>Price: "+oi.getOrderPrice()+"</td><td>"+oi.getOrderDate()+"</td>");
							pw.print("<td><input type='hidden' name='orderId' value='"+oi.getOrderId()+"'></td>");
							pw.print("<td><input type='submit' name='Order' value='CancelOrder' class='button'></td>");
							pw.print("</tr>");
							pw.print("</form>");
							
						}
					
					}
					
					pw.print("</table>");

				}
				else
				{
					pw.print("<h5 style='color:red'>No orders placed by customers</h5>");
				}
			}	
			
				
				
				
						
			pw.print("</fieldset> </article> </section>");
            utility.printHtml("LeftNavigationBar.html");			
			utility.printHtml("Footer.html");	        	
		}
		catch(Exception e)
		{
		}		
	}
}
