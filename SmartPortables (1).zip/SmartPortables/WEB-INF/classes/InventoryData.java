import java.io.*;
public class InventoryData
{
	String productName ;
	String count;
	String productPrice ;

	public  InventoryData(String productName,String count,String productPrice)
	{
		this.productName = productName;
		this.count = count;
		this.productPrice = productPrice;
	}
	
	
	public String getProductPrice(){
	 return productPrice;
	}
	
	public void setProductPrice(String productPrice){
	  this.productPrice=productPrice;
	}



	public String getProductName(){
	 return productName;
	}
	
	public void setProductName(String productName){
	  this.productName=productName;
	}

	public void setCount (String count) {
	  this.count=count;
	}
	
	public String getCount () {
	 return count;
	}
}