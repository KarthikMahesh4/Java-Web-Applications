import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;

@WebServlet("/Registration")

public class Registration extends HttpServlet {
	private String error_msg;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		displayRegistration(request, response, pw, false);
	}

	/*   Username,Password,Usertype information are Obtained from HttpServletRequest variable and validates whether
		 the User Credential Already Exists or else User Details are Added to the Users HashMap */

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		Utilities utility = new Utilities(request, pw);

		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String repassword = request.getParameter("repassword");
		String usertype = "customer";
		if(!utility.isLoggedin())
			usertype = request.getParameter("usertype");

		//if password and repassword does not match show error message

		if(!password.equals(repassword))
		{
			error_msg = "Passwords doesn't match!";
		}
		else
		{
			HashMap<String, User> hm=new HashMap<String, User>();
			String message=MySqlDataStoreUtilities.getConnection();
			System.out.println(message);
			if(message.equals("Successfull"))
			{
				hm=MySqlDataStoreUtilities.selectUser();
				if(hm.containsKey(username))
					error_msg = "Username already exist as " + usertype;
				else
				{
					User user = new User(username,password,usertype);
					hm.put(username, user);
					MySqlDataStoreUtilities.insertUser(username,password,repassword,usertype);					
					HttpSession session = request.getSession(true);	
					session.setAttribute("login_msg", "Your "+usertype+" account has been created. Please login");					
					if(!utility.isLoggedin()){
						response.sendRedirect("Login"); return;
					} else {
						response.sendRedirect("Account"); return;
					}
					/*if(!utility.isLoggedin()){
						session.setAttribute("login_msg", "Your "+usertype+" account has been created. Please login");
						response.sendRedirect("Login"); return;
					} else {
						response.sendRedirect("CustomerCreated"); return;
					}*/
				}
			}
			else 
			{
				error_msg="MySql server is not up and running";
			}			
		}

		//display the error message
		if(utility.isLoggedin()){
			HttpSession session = request.getSession(true);				
			session.setAttribute("login_msg", error_msg);
			response.sendRedirect("Account"); return;
		}
		displayRegistration(request, response, pw, true);
		
	}

	/*  displayRegistration function displays the Registration page of New User */
	
	protected void displayRegistration(HttpServletRequest request,
			HttpServletResponse response, PrintWriter pw, boolean error)
			throws ServletException, IOException {
		Utilities utility = new Utilities(request, pw);
		utility.printHtml("Header.html");
		utility.printHtml("NAV.html");
		pw.print("<section id='content'>  <article>");
		pw.print("<h3 >Registration</h3>");
				
		if (error)
			pw.print("<h5 style='color:red'>"+error_msg+"</h5>");
		pw.print("<fieldset><legend>Enter Registration Details</legend> <form method='post' action='Registration'>"
				+ "<p><label for='username'>Username:</label><input type='text' name='username' value='' required></input></p>"
				+ "<p><label for='password'>Password:</label><input type='password' name='password' value='' required></input> </p>"
				+ "<p><label for='repassword'>Re-Password:</label><input type='password' name='repassword' value='' required ></input></p>"
				+ "<p><label for='usertype'>User Type:</label><select name='usertype' ><option value='customer' selected>Customer</option><option value='retailer'>Store Manager</option><option value='manager'>Salesman</option></select></p>"
				+ "<p><input name='send' style='margin-left: 150px;' name='ByUser' class='formbutton' value='Create User' type='submit' /></p>"
				+ "</form>" + "</fieldset></article> </section>");
		utility.printHtml("LeftNavigationBar.html");
		utility.printHtml("Footer.html");
	}
}
