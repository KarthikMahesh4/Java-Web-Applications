import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ConsoleList")

public class ConsoleList extends HttpServlet {

	/* Console Page Displays all the Consoles and their Information in Smart Portable */

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		String name = null;
		String CategoryName = request.getParameter("maker");
        

		HashMap<String,Console> allconsoles = new HashMap<String,Console> ();
		try{
		     allconsoles = MySqlDataStoreUtilities.getConsoles();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		HashMap<String, Console> hm = new HashMap<String, Console>();
		if(CategoryName==null){
			hm.putAll(allconsoles);
			name = "";
		}
		else
		{
		   if(CategoryName.equals("microsoft"))
		   {
			 for(Map.Entry<String,Console> entry : SaxParserDataStore.consoles.entrySet())
			 {
				if(entry.getValue().getRetailer().equals("Microsoft"))
				 {
					 hm.put(entry.getValue().getId(),entry.getValue());
				 }
			 }
				name = "Microsoft";
		   }
		   else if(CategoryName.equals("sony"))
		    {
			for(Map.Entry<String,Console> entry : SaxParserDataStore.consoles.entrySet())
				{
				 if(entry.getValue().getRetailer().equals("Sony"))
				 {
					 hm.put(entry.getValue().getId(),entry.getValue());
				 }
				}
				 name = "Sony";
			}
			else if(CategoryName.equals("nintendo"))
			{
				for(Map.Entry<String,Console> entry : SaxParserDataStore.consoles.entrySet())
				{
				 if(entry.getValue().getRetailer().equals("Nintendo"))
				 {
					 hm.put(entry.getValue().getId(),entry.getValue());
				 }
				}
			   	 name = "Nintendo";
			}
		}

		
		/* Header, Left Navigation Bar are Printed.

		All the Console and Console information are dispalyed in the Content Section

		and then Footer is Printed*/

		Utilities utility = new Utilities(request,pw);		
		utility.printHtml("Header.html");
		utility.printHtml("NAV.html");
		pw.print("<section id='content'>  <article>");
		pw.print(" <h3>"+name+" Consoles</h3>");
		pw.print("<div id='wrap'><div id='columns' class='columns_3'>");
		int i = 1; int size= hm.size();
		for(Map.Entry<String, Console> entry : hm.entrySet())
		{
			Console console = entry.getValue();
			
			pw.print("<figure>");
			pw.print("<img src='images/consoles/"+console.getImage()+"' style='max-height: 200px !important;'>");
			pw.print("<figcaption>"+console.getName()+"</figcaption>");
			pw.print("<span class=price>$" + console.getPrice() + "</span>");
			pw.print("<form action='Cart' method='post' id='frmconsolecart"+console.getId()+"'> <a class='button' onclick='document.getElementById(\"frmconsolecart"+console.getId()+"\").submit();'>Buy Now</a>" +
					"<input type='hidden' name='name' value='"+entry.getKey()+"'>"+
					"<input type='hidden' name='type' value='consoles'>"+
					"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
					"<input type='hidden' name='access' value=''>"+
					"</form>");
			pw.print("<form action='ProductView' method='post' id='frmconsolewriteReview"+console.getId()+"'> <a class='button' onclick='document.getElementById(\"frmconsolewriteReview"+console.getId()+"\").submit();'>View</a> "+
					"<input type='hidden' name='name' value='"+console.getName()+"'>"+
					"<input type='hidden' name='condition' value='"+console.getCondition()+"'>"+
					"<input type='hidden' name='price' value='"+console.getPrice()+"'>"+
					"<input type='hidden' name='discount' value='"+console.getDiscount()+"'>"+
					"<input type='hidden' name='imagepath' value='images/accessories/"+console.getImage()+"'>"+
					"<input type='hidden' name='key' value='"+entry.getKey()+"'>"+
					"<input type='hidden' name='type' value='consoles'>"+
					"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
					"<input type='hidden' name='access' value=''>"+
				    "</form>");
			pw.print("</figure>");
			i++;
		}	
		pw.print("</div></div></article> </section>");	
        utility.printHtml("LeftNavigationBar.html");		
		utility.printHtml("Footer.html");
		
	}
}
