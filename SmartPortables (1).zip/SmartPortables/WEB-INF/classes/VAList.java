import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/VAList")

public class VAList extends HttpServlet {

	/* SmartAssistance Page Displays all the SmartAssistance and their Information in SmartAssistance Speed */

	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();

		/* Checks the Laptopss type whether it is electronicArts or activision or takeTwoInteractive */
				
		String name = null;
		String CategoryName = request.getParameter("maker");
		HashMap<String, SmartAssistance> hm = new HashMap<String, SmartAssistance>();
		
		HashMap<String,SmartAssistance> allSmartAssistance = new HashMap<String,SmartAssistance> ();
		try{
		     allSmartAssistance = MySqlDataStoreUtilities.getSmartAssistances();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		if(CategoryName==null)
		{
			hm.putAll(allSmartAssistance);
			name = "";
		}
		else
		{
		  if(CategoryName.equals("google"))
		  {
			for(Map.Entry<String,SmartAssistance> entry : allSmartAssistance.entrySet())
				{
				if(entry.getValue().getRetailer().equals("Google"))
				 {
					 hm.put(entry.getValue().getId(),entry.getValue());
				 }
				}
			name = "Google";
		  }
		  else if(CategoryName.equals("harman"))
		  {
			for(Map.Entry<String,SmartAssistance> entry : allSmartAssistance.entrySet())
				{
				if(entry.getValue().getRetailer().equals("Harman"))
				 {
					 hm.put(entry.getValue().getId(),entry.getValue());
				 }
				}	
			name = "Harman";
		  }
		  else if(CategoryName.equals("amazon"))
		  {
			for(Map.Entry<String,SmartAssistance> entry : allSmartAssistance.entrySet())
				{
				if(entry.getValue().getRetailer().equals("Amazon"))
				 {
					 hm.put(entry.getValue().getId(),entry.getValue());
				 }
				}
			name = "Amazon";
		  }
		  else if(CategoryName.equals("mi"))
		  {
			for(Map.Entry<String,SmartAssistance> entry : allSmartAssistance.entrySet())
				{
				if(entry.getValue().getRetailer().equals("MI"))
				 {
					 hm.put(entry.getValue().getId(),entry.getValue());
				 }
				}
			name = "MI";
		  }
		}

		/* Header is Printed.

		All the SmartAssistance and SmartAssistance information are dispalyed in the Content Section

		and then Left Navigation Bar,Footer is Printed*/
		
		Utilities utility = new Utilities(request,pw);
		User user=utility.getUser();
		boolean showButton=true;
		if(user!=null)
		{
			if(user.getUsertype().equals("retailer") || user.getUsertype().equals("manager"))
			{
				showButton=false;
			}
		}
		utility.printHtml("Header.html");
		utility.printHtml("NAV.html");
		pw.print("<section id='content'>  <article>");
		pw.print(" <h3>"+name+" Voice Assistant</h3>");
		pw.print("<div id='wrap'><div id='columns' class='columns_3'>");
		int i = 1; int size= hm.size();
		for(Map.Entry<String, SmartAssistance> entry : hm.entrySet()){
			SmartAssistance smartassistance = entry.getValue();
		    pw.print("<figure>");
			pw.print("<img src='images/smartassistances/"+smartassistance.getImage()+"' style='max-height: 200px !important;'>");
			pw.print("<figcaption>"+smartassistance.getName()+"</figcaption>");
			pw.print("<span class=price>$" + smartassistance.getPrice() + "</span>");
			if(showButton)
			{
				pw.print("<form action='Cart' method='post' id='frmsmartassistancecart"+smartassistance.getId()+"'> <a class='button' onclick='document.getElementById(\"frmsmartassistancecart"+smartassistance.getId()+"\").submit();'>Buy Now</a>" +
						"<input type='hidden' name='name' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='smartassistances'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
				pw.print("<form action='ProductView' method='post' id='frmsmartassistancewriteReview"+smartassistance.getId()+"'> <a class='button' onclick='document.getElementById(\"frmsmartassistancewriteReview"+smartassistance.getId()+"\").submit();'>View</a> "+
						"<input type='hidden' name='name' value='"+smartassistance.getName()+"'>"+
						"<input type='hidden' name='condition' value='"+smartassistance.getCondition()+"'>"+
						"<input type='hidden' name='price' value='"+smartassistance.getPrice()+"'>"+
						"<input type='hidden' name='discount' value='"+smartassistance.getDiscount()+"'>"+
						"<input type='hidden' name='imagepath' value='images/smartassistances/"+smartassistance.getImage()+"'>"+
						"<input type='hidden' name='key' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='smartassistances'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
				pw.print("<form action='WriteReview' method='post' id='frmsmartassistanceWRiview"+smartassistance.getId()+"'> <a class='button' onclick='document.getElementById(\"frmsmartassistanceWRiview"+smartassistance.getId()+"\").submit();'>Write Review</a>" +
						"<input type='hidden' name='name' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='smartassistances'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
			   	pw.print("<form action='ViewReview' method='post' id='frmsmartassistanceVRiview"+smartassistance.getId()+"'> <a class='button' onclick='document.getElementById(\"frmsmartassistanceVRiview"+smartassistance.getId()+"\").submit();'>View Review</a>" +
						"<input type='hidden' name='name' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='smartassistances'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
			}
			if(user!=null)
			{
				if(user.getUsertype().equals("manager"))
				{
					pw.print("<form action='DeleteProduct' method='post' id='frmdeleteVAList"+smartassistance.getId()+"'> <a class='button' onclick='document.getElementById(\"frmdeleteVAList"+smartassistance.getId()+"\").submit();'>Delete</a>" +
							"<input type='hidden' name='prodID' value='"+smartassistance.getId()+"'>"+
							"</form>");
					pw.print("<form action='UpdateProduct' method='get' id='frmUpdateProductVAList"+smartassistance.getId()+"'> <a class='button' onclick='document.getElementById(\"frmUpdateProductVAList"+smartassistance.getId()+"\").submit();'>Update</a>" +
							"<input type='hidden' name='prodID' value='"+smartassistance.getId()+"'>"+
							"<input type='hidden' name='prodName' value='"+smartassistance.getName()+"'>"+
							"<input type='hidden' name='prodPrice' value='"+smartassistance.getPrice()+"'>"+
							"<input type='hidden' name='prodCondition' value='"+smartassistance.getCondition()+"'>"+
							"<input type='hidden' name='prodDiscount' value='"+smartassistance.getDiscount()+"'>"+
							"</form>");
				}
			}
			pw.print("</figure>");
			
			i++;
		}		
		pw.print("</div></div></article> </section>");	
        utility.printHtml("LeftNavigationBar.html");		
		utility.printHtml("Footer.html");
		
	}

}
