import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/WearableList")

public class WearableList extends HttpServlet {

	/* Wearable Page Displays all the Wearable and their Information in Wearable */

	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();

		/* Checks the Wearable type whether it is electronicArts or activision or takeTwoInteractive */
				
		String name = null;
		String CategoryName = request.getParameter("maker");
		HashMap<String, Wearable> hm = new HashMap<String, Wearable>();
		
		HashMap<String,Wearable> allWearable = new HashMap<String,Wearable> ();
		try{
		     allWearable = MySqlDataStoreUtilities.getWearables();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		if(CategoryName==null)
		{
			hm.putAll(allWearable);
			name = "";
		}
		else
		{
		  if(CategoryName.equals("fitness watches"))
		  {
			for(Map.Entry<String,Wearable> entry : allWearable.entrySet())
				{
				if(entry.getValue().getRetailer().equals("Fitness Watches"))
				 {
					 hm.put(entry.getValue().getId(),entry.getValue());
				 }
				}
			name = "Fitness Watches";
		  }
		  else if(CategoryName.equals("smart watches"))
		  {
			for(Map.Entry<String,Wearable> entry : allWearable.entrySet())
				{
				if(entry.getValue().getRetailer().equals("Smart Watches"))
				 {
					 hm.put(entry.getValue().getId(),entry.getValue());
				 }
				}	
			name = "Smart Watches";
		  }
		  else if(CategoryName.equals("headphones"))
		  {
			for(Map.Entry<String,Wearable> entry : allWearable.entrySet())
				{
				if(entry.getValue().getRetailer().equals("Headphones"))
				 {
					 hm.put(entry.getValue().getId(),entry.getValue());
				 }
				}
			name = "Headphones";
		  }
		  else if(CategoryName.equals("virtual reality"))
		  {
			for(Map.Entry<String,Wearable> entry : allWearable.entrySet())
				{
				if(entry.getValue().getRetailer().equals("Virtual Reality"))
				 {
					 hm.put(entry.getValue().getId(),entry.getValue());
				 }
				}
			name = "Virtual Reality";
		  }
		  else if(CategoryName.equals("pet tracker"))
		  {
			for(Map.Entry<String,Wearable> entry : allWearable.entrySet())
				{
				if(entry.getValue().getRetailer().equals("Pet Tracker"))
				 {
					 hm.put(entry.getValue().getId(),entry.getValue());
				 }
				}
			name = "Pet Tracker";
		  }
		}

		/* Header is Printed.

		All the Laptops and Laptops information are dispalyed in the Content Section

		and then Left Navigation Bar,Footer is Printed*/
		
		Utilities utility = new Utilities(request,pw);
		User user=utility.getUser();
		boolean showButton=true;
		if(user!=null)
		{
			if(user.getUsertype().equals("retailer") || user.getUsertype().equals("manager"))
			{
				showButton=false;
			}
		}
		utility.printHtml("Header.html");
		utility.printHtml("NAV.html");
		pw.print("<section id='content'>  <article>");
		pw.print(" <h3>"+name+" Wearables</h3>");
		pw.print("<div id='wrap'><div id='columns' class='columns_3'>");
		int i = 1; int size= hm.size();
		for(Map.Entry<String, Wearable> entry : hm.entrySet()){
			Wearable wearable = entry.getValue();
		    pw.print("<figure>");
			pw.print("<img src='images/wearables/"+wearable.getImage()+"' style='max-height: 200px !important;'>");
			pw.print("<figcaption>"+wearable.getName()+"</figcaption>");
			pw.print("<span class=price>$" + wearable.getPrice() + "</span>");
			if(showButton)
			{
				pw.print("<form action='Cart' method='post' id='frmwearablecart"+wearable.getId()+"'> <a class='button' onclick='document.getElementById(\"frmwearablecart"+wearable.getId()+"\").submit();'>Buy Now</a>" +
						"<input type='hidden' name='name' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='wearables'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
				pw.print("<form action='ProductView' method='post' id='frmwearablewriteReview"+wearable.getId()+"'> <a class='button' onclick='document.getElementById(\"frmwearablewriteReview"+wearable.getId()+"\").submit();'>View</a> "+
						"<input type='hidden' name='name' value='"+wearable.getName()+"'>"+
						"<input type='hidden' name='condition' value='"+wearable.getCondition()+"'>"+
						"<input type='hidden' name='price' value='"+wearable.getPrice()+"'>"+
						"<input type='hidden' name='discount' value='"+wearable.getDiscount()+"'>"+
						"<input type='hidden' name='imagepath' value='images/wearables/"+wearable.getImage()+"'>"+
						"<input type='hidden' name='key' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='wearables'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
				pw.print("<form action='WriteReview' method='post' id='frmwearableWRiview"+wearable.getId()+"'> <a class='button' onclick='document.getElementById(\"frmwearableWRiview"+wearable.getId()+"\").submit();'>Write Review</a>" +
						"<input type='hidden' name='name' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='wearables'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
			   	pw.print("<form action='ViewReview' method='post' id='frmwearableVRiview"+wearable.getId()+"'> <a class='button' onclick='document.getElementById(\"frmwearableVRiview"+wearable.getId()+"\").submit();'>View Review</a>" +
						"<input type='hidden' name='name' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='wearables'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
			}
			if(user!=null)
			{
				if(user.getUsertype().equals("manager"))
				{
					pw.print("<form action='DeleteProduct' method='post' id='frmdeleteWEList"+wearable.getId()+"'> <a class='button' onclick='document.getElementById(\"frmdeleteWEList"+wearable.getId()+"\").submit();'>Delete</a>" +
							"<input type='hidden' name='prodID' value='"+wearable.getId()+"'>"+
							"</form>");
					pw.print("<form action='UpdateProduct' method='get' id='frmUpdateProductWEList"+wearable.getId()+"'> <a class='button' onclick='document.getElementById(\"frmUpdateProductWEList"+wearable.getId()+"\").submit();'>Update</a>" +
							"<input type='hidden' name='prodID' value='"+wearable.getId()+"'>"+
							"<input type='hidden' name='prodName' value='"+wearable.getName()+"'>"+
							"<input type='hidden' name='prodPrice' value='"+wearable.getPrice()+"'>"+
							"<input type='hidden' name='prodCondition' value='"+wearable.getCondition()+"'>"+
							"<input type='hidden' name='prodDiscount' value='"+wearable.getDiscount()+"'>"+
							"</form>");
				}
			}
			pw.print("</figure>");
			
			i++;
		}		
		pw.print("</div></div></article> </section>");	
        utility.printHtml("LeftNavigationBar.html");		
		utility.printHtml("Footer.html");
		
	}

}
