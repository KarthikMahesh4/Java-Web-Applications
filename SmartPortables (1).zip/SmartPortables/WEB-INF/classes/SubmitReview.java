import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/SubmitReview")

public class SubmitReview extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
	    Utilities utility= new Utilities(request, pw);
		storeReview(request, response);
	}
	protected void storeReview(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try
		{
			response.setContentType("text/html");
			PrintWriter pw = response.getWriter();
			Utilities utility = new Utilities(request,pw);
			if(!utility.isLoggedin()){
				HttpSession session = request.getSession(true);				
				session.setAttribute("login_msg", "Please Login to add items to cart");
				response.sendRedirect("Login");
				return;
			}
			String productname=request.getParameter("productname");		
			String producttype=request.getParameter("producttype");
			String productPrice=request.getParameter("productPrice");
			String retailerName=request.getParameter("retailerName");
			String retailerpin=request.getParameter("pin");
			String retailerCity=request.getParameter("retailerCity");
			String retailerState=request.getParameter("retailerState");
			String productOnSale=request.getParameter("productOnSale");
			String manufacturerName=request.getParameter("manufacturerName");
			String manufacturerRebate=request.getParameter("manufacturerRebate");
			String userAge=request.getParameter("userAge");
			String userGender=request.getParameter("userGender");
			String userOccupation=request.getParameter("userOccupation");
			//String productmaker=request.getParameter("productmaker");
			String reviewrating=request.getParameter("reviewrating");
			String reviewdate=request.getParameter("reviewdate");
			String reviewtext=request.getParameter("reviewtext");
			
			
			
			
			String message=utility.storeReview(productname,producttype,reviewrating,reviewdate,reviewtext,retailerpin,productPrice,retailerName,retailerCity,
			retailerState,productOnSale,manufacturerName,manufacturerRebate,userAge,userGender,userOccupation);				     
			utility.printHtml("Header.html");
			utility.printHtml("NAV.html");
			pw.print("<section id='content'>  <article>");
			pw.print("<h3 >Review Submitted</h3>");
			if(message.equals("Successfull"))
				pw.print("<h5 style='color:green' >Review for &nbsp"+productname+" Stored </h5>");
			else
				pw.print("<h5 style='color:red'>Mongo Db is not up and running </h5>");
			pw.print("</article> </section>");	
			utility.printHtml("LeftNavigationBar.html");
			utility.printHtml("Footer.html");         	
		}
		catch(Exception e)
		{
			 System.out.println(e.getMessage());
		}  			
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
    }
}
