import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.w3c.dom.*; 
import javax.xml.parsers.*; 
import javax.xml.transform.*; 
import javax.xml.transform.stream.*; 
import java.io.*;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload; 
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.FilenameUtils;
import java.util.List;
import javax.xml.transform.dom.DOMSource; 
import javax.xml.xpath.*;

@WebServlet("/DeleteProduct")

public class DeleteProduct extends HttpServlet {
	private String error_msg;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		Utilities utility = new Utilities(request, pw);
		User user=utility.getUser();
		System.out.println(user.getUsertype());
		if(user.getUsertype().equals("retailer"))
		{
			try
			{	
				MySqlDataStoreUtilities.deleteproducts((String)request.getParameter("prodID"));
				response.sendRedirect(request.getHeader("Referer"));
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}	
		}
		else 
		{
			utility.printHtml("Header.html");
			utility.printHtml("NAV.html");
			pw.print("<section id='content'>  <article>");
			pw.print("<h3>Not Authorized</h3>");
			pw.print("<div id='wrap'><div id='columns' class='columns_3'>");
			pw.print("</div></div></article> </section>");	
			utility.printHtml("LeftNavigationBar.html");		
			utility.printHtml("Footer.html");
		}
		
	}	
	
	private static void deleteElement(Document doc,String id) {
		try{
			XPathFactory factory = XPathFactory.newInstance();
			XPath xpath = factory.newXPath();
			XPathExpression expr = xpath.compile("//*[@id = '" + id + "']");
			Element deleteNode = (Element) expr.evaluate(doc, XPathConstants.NODE);
			if(deleteNode==null)
			{
				System.out.println("Null Element");
			}
			Node parent = deleteNode.getParentNode();
			parent.removeChild(deleteNode);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
    }
	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}
}
