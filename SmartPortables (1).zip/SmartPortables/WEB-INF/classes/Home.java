import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.*; 

@WebServlet("/Home")

/* 
	Home class uses the printHtml Function of Utilities class and prints the Header,LeftNavigationBar,
	Content,Footer of Game Speed Application.

*/

public class Home extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		
		Utilities utility = new Utilities(request,pw);
		User user=utility.getUser();
		boolean showButton=true;
		if(user!=null)
		{
			if(user.getUsertype().equals("retailer") || user.getUsertype().equals("manager"))
			{
				showButton=false;
			}
		}
		utility.printHtml("Header.html");
		utility.printHtml("NAV.html");
		String CategoryName=null;
		HashMap<String, Wearable> hmW = new HashMap<String, Wearable>();
		HashMap<String,Wearable> allWearable = new HashMap<String,Wearable> ();
		try{
		     allWearable = MySqlDataStoreUtilities.getWearables();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		hmW.putAll(allWearable);
		
		HashMap<String, Laptops> hmL = new HashMap<String, Laptops>();
		
		HashMap<String,Laptops> allLaptops = new HashMap<String,Laptops> ();
		try{
		     allLaptops = MySqlDataStoreUtilities.getLaptops();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		hmL.putAll(allLaptops);
		
		
		HashMap<String, Phones> hmP = new HashMap<String, Phones>();
		HashMap<String,Phones> allPhones = new HashMap<String,Phones> ();
		try{
		     allPhones = MySqlDataStoreUtilities.getPhones();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		hmP.putAll(allPhones);
		
		pw.print("<section id='content'>  <article>");
		pw.print("<h3>Committed to spectacular smart portable. </h3><div class='article-info'>We beat our competitors in all aspects. Price-Match Guaranteed</div><a href='#' class='button'>Read more</a>");
		pw.print("</article>");
		
		RequestDispatcher rd=request.getRequestDispatcher("DealMatches");
		rd.include(request,response);
		

		
		
		pw.print("<article>");
		pw.print("<div id='wrap'><div id='columns' class='columns_3'>");
		int i = 1; int size= hmW.size();
		for(Map.Entry<String, Wearable> entry : hmW.entrySet()){
			Wearable wearable = entry.getValue();
		    pw.print("<figure>");
			pw.print("<img src='images/wearables/"+wearable.getImage()+"' style='max-height: 200px !important;'>");
			pw.print("<figcaption>"+wearable.getName()+"</figcaption>");
			pw.print("<span class=price>$" + wearable.getPrice() + "</span>");
			if(showButton)
			{
				pw.print("<form action='Cart' method='post' id='frmwearablecart"+wearable.getId()+"'> <a class='button' onclick='document.getElementById(\"frmwearablecart"+wearable.getId()+"\").submit();'>Buy Now</a>" +
						"<input type='hidden' name='name' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='wearables'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
				pw.print("<form action='ProductView' method='post' id='frmwearablewriteReview"+wearable.getId()+"'> <a class='button' onclick='document.getElementById(\"frmwearablewriteReview"+wearable.getId()+"\").submit();'>View</a> "+
						"<input type='hidden' name='name' value='"+wearable.getName()+"'>"+
						"<input type='hidden' name='condition' value='"+wearable.getCondition()+"'>"+
						"<input type='hidden' name='price' value='"+wearable.getPrice()+"'>"+
						"<input type='hidden' name='discount' value='"+wearable.getDiscount()+"'>"+
						"<input type='hidden' name='imagepath' value='images/wearables/"+wearable.getImage()+"'>"+
						"<input type='hidden' name='key' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='wearables'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
				pw.print("<form action='WriteReview' method='post' id='frmwearableWRiview"+wearable.getId()+"'> <a class='button' onclick='document.getElementById(\"frmwearableWRiview"+wearable.getId()+"\").submit();'>Write Review</a>" +
						"<input type='hidden' name='name' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='wearables'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
			   	pw.print("<form action='ViewReview' method='post' id='frmwearableVRiview"+wearable.getId()+"'> <a class='button' onclick='document.getElementById(\"frmwearableVRiview"+wearable.getId()+"\").submit();'>View Review</a>" +
						"<input type='hidden' name='name' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='wearables'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
			}
			if(user!=null)
			{
				if(user.getUsertype().equals("manager"))
				{
					pw.print("<form action='DeleteProduct' method='post' id='frmdeleteWEList"+wearable.getId()+"'> <a class='button' onclick='document.getElementById(\"frmdeleteWEList"+wearable.getId()+"\").submit();'>Delete</a>" +
							"<input type='hidden' name='prodID' value='"+wearable.getId()+"'>"+
							"</form>");
					pw.print("<form action='UpdateProduct' method='get' id='frmUpdateProductWEList"+wearable.getId()+"'> <a class='button' onclick='document.getElementById(\"frmUpdateProductWEList"+wearable.getId()+"\").submit();'>Update</a>" +
							"<input type='hidden' name='prodID' value='"+wearable.getId()+"'>"+
							"<input type='hidden' name='prodName' value='"+wearable.getName()+"'>"+
							"<input type='hidden' name='prodPrice' value='"+wearable.getPrice()+"'>"+
							"<input type='hidden' name='prodCondition' value='"+wearable.getCondition()+"'>"+
							"<input type='hidden' name='prodDiscount' value='"+wearable.getDiscount()+"'>"+
							"</form>");
				}
			}
			
			pw.print("</figure>");
			
			i++;
		}	
		
		i = 1;  size= hmL.size();
		for(Map.Entry<String, Laptops> entry : hmL.entrySet()){
			Laptops laptops = entry.getValue();
		    pw.print("<figure>");
			pw.print("<img src='images/laptops/"+laptops.getImage()+"' style='max-height: 200px !important;'>");
			pw.print("<figcaption>"+laptops.getName()+"</figcaption>");
			pw.print("<span class=price>$" + laptops.getPrice() + "</span>");
			if(showButton)
			{
				pw.print("<form action='Cart' method='post' id='frmlaptopcart"+laptops.getId()+"'> <a class='button' onclick='document.getElementById(\"frmlaptopcart"+laptops.getId()+"\").submit();'>Buy Now</a>" +
						"<input type='hidden' name='name' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='laptops'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
				pw.print("<form action='ProductView' method='post' id='frmlaptopwriteReview"+laptops.getId()+"'> <a class='button' onclick='document.getElementById(\"frmlaptopwriteReview"+laptops.getId()+"\").submit();'>View</a> "+
						"<input type='hidden' name='name' value='"+laptops.getName()+"'>"+
						"<input type='hidden' name='condition' value='"+laptops.getCondition()+"'>"+
						"<input type='hidden' name='price' value='"+laptops.getPrice()+"'>"+
						"<input type='hidden' name='discount' value='"+laptops.getDiscount()+"'>"+
						"<input type='hidden' name='imagepath' value='images/laptops/"+laptops.getImage()+"'>"+
						"<input type='hidden' name='key' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='laptops'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
						
				pw.print("<form action='WriteReview' method='post' id='frmlaptopWRiview"+laptops.getId()+"'> <a class='button' onclick='document.getElementById(\"frmlaptopWRiview"+laptops.getId()+"\").submit();'>Write Review</a>" +
						"<input type='hidden' name='name' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='laptops'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
			   	pw.print("<form action='ViewReview' method='post' id='frmlaptopVRiview"+laptops.getId()+"'> <a class='button' onclick='document.getElementById(\"frmlaptopVRiview"+laptops.getId()+"\").submit();'>View Review</a>" +
						"<input type='hidden' name='name' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='laptops'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
			}
			if(user!=null)
			{
				if(user.getUsertype().equals("manager"))
				{
					pw.print("<form action='DeleteProduct' method='post' id='frmdeletelaptops"+laptops.getId()+"'> <a class='button' onclick='document.getElementById(\"frmdeletelaptops"+laptops.getId()+"\").submit();'>Delete</a>" +
							"<input type='hidden' name='prodID' value='"+laptops.getId()+"'>"+
							"</form>");
					pw.print("<form action='UpdateProduct' method='get' id='frmUpdateProductlaptops"+laptops.getId()+"'> <a class='button' onclick='document.getElementById(\"frmUpdateProductlaptops"+laptops.getId()+"\").submit();'>Update</a>" +
							"<input type='hidden' name='prodID' value='"+laptops.getId()+"'>"+
							"<input type='hidden' name='prodName' value='"+laptops.getName()+"'>"+
							"<input type='hidden' name='prodPrice' value='"+laptops.getPrice()+"'>"+
							"<input type='hidden' name='prodCondition' value='"+laptops.getCondition()+"'>"+
							"<input type='hidden' name='prodDiscount' value='"+laptops.getDiscount()+"'>"+
							"</form>");
				}
			}
			
			pw.print("</figure>");
			
			i++;
		}	
 
        i = 1;  size= hmP.size();
		for(Map.Entry<String, Phones> entry : hmP.entrySet()){
			Phones phones = entry.getValue();
		    pw.print("<figure>");
			pw.print("<img src='images/phones/"+phones.getImage()+"' style='max-height: 200px !important;'>");
			pw.print("<figcaption>"+phones.getName()+"</figcaption>");
			pw.print("<span class=price>$" + phones.getPrice() + "</span>");
			if(showButton)
			{
				pw.print("<form action='Cart' method='post' id='frmphonescart"+phones.getId()+"'> <a class='button' onclick='document.getElementById(\"frmphonescart"+phones.getId()+"\").submit();'>Buy Now</a>" +
						"<input type='hidden' name='name' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='phones'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
				pw.print("<form action='ProductView' method='post' id='frmphoneswriteReview"+phones.getId()+"'> <a class='button' onclick='document.getElementById(\"frmphoneswriteReview"+phones.getId()+"\").submit();'>View</a> "+
						"<input type='hidden' name='name' value='"+phones.getName()+"'>"+
						"<input type='hidden' name='condition' value='"+phones.getCondition()+"'>"+
						"<input type='hidden' name='price' value='"+phones.getPrice()+"'>"+
						"<input type='hidden' name='discount' value='"+phones.getDiscount()+"'>"+
						"<input type='hidden' name='imagepath' value='images/phones/"+phones.getImage()+"'>"+
						"<input type='hidden' name='key' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='phones'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
				pw.print("<form action='WriteReview' method='post' id='frmphonesWRiview"+phones.getId()+"'> <a class='button' onclick='document.getElementById(\"frmphonesWRiview"+phones.getId()+"\").submit();'>Write Review</a>" +
						"<input type='hidden' name='name' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='phones'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
			   	pw.print("<form action='ViewReview' method='post' id='frmphonesVRiview"+phones.getId()+"'> <a class='button' onclick='document.getElementById(\"frmphonesVRiview"+phones.getId()+"\").submit();'>View Review</a>" +
						"<input type='hidden' name='name' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='phones'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
			}
			if(user!=null)
			{
				if(user.getUsertype().equals("manager"))
				{
					pw.print("<form action='DeleteProduct' method='post' id='frmdeletephones"+phones.getId()+"'> <a class='button' onclick='document.getElementById(\"frmdeletephones"+phones.getId()+"\").submit();'>Delete</a>" +
							"<input type='hidden' name='prodID' value='"+phones.getId()+"'>"+
							"</form>");
					pw.print("<form action='UpdateProduct' method='get' id='frmUpdateProductphones"+phones.getId()+"'> <a class='button' onclick='document.getElementById(\"frmUpdateProductphones"+phones.getId()+"\").submit();'>Update</a>" +
							"<input type='hidden' name='prodID' value='"+phones.getId()+"'>"+
							"<input type='hidden' name='prodName' value='"+phones.getName()+"'>"+
							"<input type='hidden' name='prodPrice' value='"+phones.getPrice()+"'>"+
							"<input type='hidden' name='prodCondition' value='"+phones.getCondition()+"'>"+
							"<input type='hidden' name='prodDiscount' value='"+phones.getDiscount()+"'>"+
							"</form>");
				}
			}
			
			pw.print("</figure>");
			
			i++;
		}		
		
		pw.print("</div></div></article> </section>");	
		
		//utility.printHtml("Content.html");
		utility.printHtml("LeftNavigationBar.html");
		utility.printHtml("Footer.html");
				
	}

}
