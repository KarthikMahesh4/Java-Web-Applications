import java.io.IOException;
import java.io.*;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DealMatches")

public class DealMatches extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		Utilities utility = new Utilities(request,pw);
		User user=utility.getUser();
		boolean showButton=true; 
		if(user!=null)
		{
			if(user.getUsertype().equals("retailer") || user.getUsertype().equals("manager"))
			{
				showButton=false;
			}
		}
		pw.print("<article>");
		pw.print(" <h3>Deal Matches</h3>");
        HashMap<String,Product> selectedproducts=new HashMap<String,Product>();
		 try{
				String line=null;
				String TOMCAT_HOME = System.getProperty("catalina.home");
				HashMap<String,Product> productmap=MySqlDataStoreUtilities.getData();
				for(Map.Entry<String, Product> entry : productmap.entrySet())
				{	
					if(selectedproducts.size()<2 && !selectedproducts.containsKey(entry.getKey()))
					{			
						BufferedReader reader = new BufferedReader(new FileReader (new File(TOMCAT_HOME+"\\webapps\\SmartPortables\\DealMatches.txt")));
						line=reader.readLine().toLowerCase();
						if(line==null)
						{
							pw.print("<h5 style='color:red' align='center'>No Offers Found</h5>");
							break;
						}	
						else
						{	
						 do {	  
							  if(line.contains(entry.getKey()))
							  {
								pw.print("<p>");
								pw.print("<h4>"+line+"</h4>");
								pw.print("</p>");
								selectedproducts.put(entry.getKey(),entry.getValue());
								
								break;
							  }
							}while((line = reader.readLine()) != null);
						
						}
					}
				}
			}
			catch(Exception e)
			{
				pw.print("<h5 style='color:red' align='center'>No Offers Found</h5>");
			}
			
	;
		pw.print("<div id='wrap'><div id='columns' class='columns_3'>");
		if(selectedproducts.size()==0)
		{
			pw.print("<h2 align='center'>No Deals Found</h2>");	
		}
		else
		{
			
			//int i = 1; int size= hm.size();
			for(Map.Entry<String, Product> entry : selectedproducts.entrySet()){
				//Laptops laptops = entry.getValue();
				pw.print("<figure>");
				pw.print("<img src='images/"+entry.getValue().getType()+"/"+entry.getValue().getImage()+"' style='max-height: 200px !important;'>");
				pw.print("<figcaption>"+entry.getValue().getName()+"</figcaption>");
				pw.print("<span class=price>$" + entry.getValue().getPrice() + "</span>");
				if(showButton)
				{
					pw.print("<form action='Cart' method='post' id='frmlaptopcart"+entry.getValue().getId()+"'> <a class='button' onclick='document.getElementById(\"frmlaptopcart"+entry.getValue().getId()+"\").submit();'>Buy Now</a>" +
							"<input type='hidden' name='name' value='"+entry.getValue().getName()+"'>"+
							"<input type='hidden' name='type' value='"+entry.getValue().getType()+"'>"+
							"<input type='hidden' name='maker' value='"+entry.getValue().getRetailer()+"'>"+
							"<input type='hidden' name='access' value=''>"+
							"</form>");
					pw.print("<form action='ProductView' method='post' id='frmlaptopwriteReview"+entry.getValue().getId()+"'> <a class='button' onclick='document.getElementById(\"frmlaptopwriteReview"+entry.getValue().getId()+"\").submit();'>View</a> "+
							"<input type='hidden' name='name' value='"+entry.getValue().getName()+"'>"+
							"<input type='hidden' name='condition' value='"+entry.getValue().getCondition()+"'>"+
							"<input type='hidden' name='price' value='"+entry.getValue().getPrice()+"'>"+
							"<input type='hidden' name='discount' value='"+entry.getValue().getDiscount()+"'>"+
							"<input type='hidden' name='imagepath' value='images/"+entry.getValue().getType()+"/"+entry.getValue().getImage()+"'>"+
							"<input type='hidden' name='key' value='"+entry.getValue().getName()+"'>"+
							"<input type='hidden' name='type' value='"+entry.getValue().getType()+"'>"+
							"<input type='hidden' name='maker' value='"+entry.getValue().getRetailer()+"'>"+
							"<input type='hidden' name='access' value=''>"+
							"</form>");
					pw.print("<form action='WriteReview' method='post' id='frmlaptopWRiview"+entry.getValue().getId()+"'> <a class='button' onclick='document.getElementById(\"frmlaptopWRiview"+entry.getValue().getId()+"\").submit();'>Write Review</a>" +
							"<input type='hidden' name='name' value='"+entry.getValue().getName()+"'>"+
							"<input type='hidden' name='type' value='"+entry.getValue().getType()+"'>"+
							"<input type='hidden' name='maker' value='"+entry.getValue().getRetailer()+"'>"+
							"<input type='hidden' name='access' value=''>"+
							"</form>");
					pw.print("<form action='ViewReview' method='post' id='frmlaptopVRiview"+entry.getValue().getId()+"'> <a class='button' onclick='document.getElementById(\"frmlaptopVRiview"+entry.getValue().getId()+"\").submit();'>View Review</a>" +
							"<input type='hidden' name='name' value='"+entry.getValue().getName()+"'>"+
							"<input type='hidden' name='type' value='"+entry.getValue().getType()+"'>"+
							"<input type='hidden' name='maker' value='"+entry.getValue().getRetailer()+"'>"+
							"<input type='hidden' name='access' value=''>"+
							"</form>");
				}
				if(user!=null)
				{
					if(user.getUsertype().equals("manager"))
					{
						
						pw.print("<form action='DeleteProduct' method='post' id='frmdeletelaptop"+entry.getValue().getId()+"'> <a class='button' onclick='document.getElementById(\"frmdeletelaptop"+entry.getValue().getId()+"\").submit();'>Delete</a>" +
								"<input type='hidden' name='prodID' value='"+entry.getValue().getId()+"'>"+
								"</form>");
						pw.print("<form action='UpdateProduct' method='get' id='frmUpdatelaptop"+entry.getValue().getId()+"'> <a class='button' onclick='document.getElementById(\"frmUpdatelaptop"+entry.getValue().getId()+"\").submit();'>Update</a>" +
								"<input type='hidden' name='prodID' value='"+entry.getValue().getId()+"'>"+
								"<input type='hidden' name='prodName' value='"+entry.getValue().getName()+"'>"+
								"<input type='hidden' name='prodPrice' value='"+entry.getValue().getPrice()+"'>"+
								"<input type='hidden' name='prodCondition' value='"+entry.getValue().getCondition()+"'>"+
								"<input type='hidden' name='prodDiscount' value='"+entry.getValue().getDiscount()+"'>"+
								"</form>");
					}
				}
				pw.print("</figure>");
				
				//i++;
			}		
			pw.print("</div></div></article> ");	
		}
			
		/*pw.print("</div>");
		pw.print("</div>");
		pw.print("<div class='post'>");
		pw.print("<h2 class='title meta'>");
		pw.print("<a style='font-size: 24px;'>Deal Matches</a>");
		pw.print("</h2>");
		pw.print("<div class='entry'>");
		if(selectedproducts.size()==0)
		{
			pw.print("<h2 align='center'>No Deals Found</h2>");	
		}
		else
		{
		pw.print("<table id='bestseller'>");
		pw.print("<tr>");
		for(Map.Entry<String, Product> entry : selectedproducts.entrySet()){
			pw.print("<td><div id='shop_item'><h3>"+entry.getValue().getName()+"</h3>");
			pw.print("<strong>"+entry.getValue().getPrice()+"$</strong>");
			pw.print("<ul>");
			pw.print("<li id='item'><img src='images/"+entry.getValue().getType()+"/"+entry.getValue().getImage()+"' alt='' />");
			pw.print("</li><li>");
			pw.print("<form action='Cart' method='post'><input type='submit' class='btnbuy' value='Buy Now'>");
			pw.print("<input type='hidden' name='name' value='"+entry.getKey()+"'>");
			pw.print("<input type='hidden' name='type' value='"+entry.getValue().getType()+"'>");
			pw.print("<input type='hidden' name='maker' value='"+entry.getValue().getRetailer()+"'>");
			pw.print("<input type='hidden' name='access' value=''>");
			pw.print("</form></li><li>");
			pw.print("<form action='WriteReview' method='post'><input type='submit' class='btnreview' value='WriteReview'>");
			pw.print("<input type='hidden' name='name' value='"+entry.getValue().getId()+"'>");
			pw.print("<input type='hidden' name='type' value='"+entry.getValue().getType()+"'>");
			pw.print("<input type='hidden' name='maker' value='"+entry.getValue().getRetailer()+"'>");
			pw.print("<input type='hidden' name='price' value='"+entry.getValue().getPrice()+"'>");
			pw.print("</form></li>");
			pw.print("<li>");
			pw.print("<form action='ViewReview' method='post'><input type='submit' class='btnreview' value='ViewReview'>");
			pw.print("<input type='hidden' name='name' value='"+entry.getValue().getId()+"'>");
			pw.print("<input type='hidden' name='type' value='"+entry.getValue().getType()+"'>");
			pw.print("</form></li></ul></div></td>");
		}
		pw.print("</tr></table>");
		}
		pw.print("</div></div></div>");*/
		
	}
}
