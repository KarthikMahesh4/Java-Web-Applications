import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.*;
import java.io.*;
import java.sql.*;

@WebServlet("/Account")

public class Account extends HttpServlet {
	private String error_msg;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		Utilities utility = new Utilities(request, pw);
		User user=utility.getUser();
		System.out.println(user.getUsertype());
		if(user.getUsertype().equals("customer"))
		{
			response.setContentType("text/html");
			//PrintWriter pw = response.getWriter();
			displayAccount(request, response);
		}
		else if(user.getUsertype().equals("retailer")|| user.getUsertype().equals("manager"))
		{
			 request.getRequestDispatcher("/SalesManAccount").forward(request, response);
		}
		
	}

	/* Display Account Details of the Customer (Name and Usertype) */

	protected void displayAccount(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		Utilities utility = new Utilities(request, pw);
		try
         {  
           response.setContentType("text/html");
			if(!utility.isLoggedin())
			{
				HttpSession session = request.getSession(true);				
				session.setAttribute("login_msg", "Please Login to add items to cart");
				response.sendRedirect("Login");
				return;
			}
			HttpSession session=request.getSession(); 	
			utility.printHtml("Header.html");
		    utility.printHtml("NAV.html");
			pw.print("<section id='content'>  <article>");
			pw.print("<h3 >Account</h3>");
			User user=utility.getUser();
			pw.print("<p><label for='username'>User Name: </label>&nbsp; <span  name='username' >" +user.getName()+ "</span></p> ");
			if(user.getUsertype().equals("retailer"))
			   pw.print("<p><label for='usertype'>User Type: </label>&nbsp; <span  name='usertype' >Salesman</span></p> ");
		    else if(user.getUsertype().equals("manager"))
			   pw.print("<p><label for='usertype'>User Type: </label>&nbsp; <span  name='usertype' >Store Manager</span></p> ");
			else if(user.getUsertype().equals("customer")) 
			   pw.print("<p><label for='usertype'>User Type: </label>&nbsp; <span  name='usertype' >Customer</span></p> ");
			pw.print("<p>&nbsp;</p>");
			HashMap<Integer, ArrayList<OrderPayment>> orderPayments = new HashMap<Integer, ArrayList<OrderPayment>>();	
			try
		    {
				orderPayments=MySqlDataStoreUtilities.selectOrder();

			}
			catch(Exception e)
			{
			    e.printStackTrace();
			}
			
			int size=0;
			for(Map.Entry<Integer, ArrayList<OrderPayment>> entry : orderPayments.entrySet())
				{
					for(OrderPayment od:entry.getValue())	
					if(od.getUserName().equals(user.getName()))
					size= size+1;
				}
				
			if(size>0)
				{	
					pw.print("<fieldset><legend>Your Orders</legend> ");
					pw.print("<table cellspacing='0'>");
					pw.print("<tr><th></th>");
					pw.print("<th>Order Id</th>");
					pw.print("<th>UserName</th>");
					pw.print("<th>Product Ordered</th>");
					pw.print("<th>Product Price</th>");
					pw.print("<th>Order Date</th></tr>");
					for(Map.Entry<Integer, ArrayList<OrderPayment>> entry : orderPayments.entrySet())
					{
						for(OrderPayment oi:entry.getValue())	
						if(oi.getUserName().equals(user.getName())) 
						{
							pw.print("<form method='get' action='ViewOrder'>");
							pw.print("<tr>");			
							pw.print("<td><input type='radio' name='orderName' value='"+oi.getOrderName()+"'></td>");			
							pw.print("<td>"+oi.getOrderId()+".</td><td>"+oi.getUserName()+"</td><td>"+oi.getOrderName()+"</td><td>Price: "+oi.getOrderPrice()+"</td><td>"+oi.getOrderDate()+"</td>");
							pw.print("<td><input type='hidden' name='orderId' value='"+oi.getOrderId()+"'></td>");
							pw.print("<td><input type='submit' name='Order' value='CancelOrder' class='button'></td>");
							pw.print("</tr>");
							pw.print("</form>");
							
						}
					
					}
					
					pw.print("</table>");
				}
				else
				{
					pw.print("<h5 style='color:red'>You have not placed any order with this order id</h5>");
				}
			
				
				
				
						
			pw.print("</fieldset> </article> </section>");
            utility.printHtml("LeftNavigationBar.html");			
			utility.printHtml("Footer.html");	        	
		}
		catch(Exception e)
		{
		}		
	}
}
