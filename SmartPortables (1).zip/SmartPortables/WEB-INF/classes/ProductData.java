	
import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;


@WebServlet("/ProductData")
public class ProductData extends HttpServlet {
	
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{

PrintWriter pw= response.getWriter();
response.setContentType("text/html");			
 pw.println("<html>");
 pw.println("<body>");

		Utilities utility = new Utilities(request,pw);
		utility.printHtml("Header.html");
		utility.printHtml("NAV.html");
		pw.print("<section id='content'>  <article>");
		//pw.print("<h3 >"+name+"</h3>");
		Product data= (Product)request.getAttribute("data");
		User user=utility.getUser();
		boolean showButton=true;
		if(user!=null)
		{
			if(user.getUsertype().equals("retailer") || user.getUsertype().equals("manager"))
			{
				showButton=false;
			}
		}
		
		String imagepath="";
		pw.print("<fieldset><legend>Items Details</legend> ");
		pw.print("<figure>");
		pw.print("<img src='images/"+data.getType()+"/"+data.getImage()+"' style='max-height: 200px !important;'>");
		pw.print("<figcaption>"+data.getName()+"</figcaption>");
		pw.print("<span class=price>$" + data.getPrice() + "</span>");
		if(showButton)
		{
				pw.print("<form action='Cart' method='post' id='frmphonescart"+data.getId()+"'> <a class='button' style='max-width: 200px;' onclick='document.getElementById(\"frmphonescart"+data.getId()+"\").submit();'>Buy Now</a>" +
						"<input type='hidden' name='name' value='"+data.getId()+"'>"+
						"<input type='hidden' name='type' value='"+data.getType()+"'>"+
						"<input type='hidden' name='maker' value='"+data.getRetailer()+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
				pw.print("<form action='ProductView' method='post' id='frmphoneswriteReview"+data.getId()+"'> <a class='button' style='max-width: 200px;' onclick='document.getElementById(\"frmphoneswriteReview"+data.getId()+"\").submit();'>View</a> "+
						"<input type='hidden' name='name' value='"+data.getName()+"'>"+
						"<input type='hidden' name='condition' value='"+data.getCondition()+"'>"+
						"<input type='hidden' name='price' value='"+data.getPrice()+"'>"+
						"<input type='hidden' name='discount' value='"+data.getDiscount()+"'>"+
						"<input type='hidden' name='imagepath' value='images/"+data.getType()+"/"+data.getImage()+"'>"+
						"<input type='hidden' name='key' value='"+data.getId()+"'>"+
						"<input type='hidden' name='type' value='"+data.getType()+"'>"+
						"<input type='hidden' name='maker' value='"+data.getRetailer()+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
				pw.print("<form action='WriteReview' method='post' id='frmphonesWRiview"+data.getId()+"'> <a class='button' style='max-width: 200px;' onclick='document.getElementById(\"frmphonesWRiview"+data.getId()+"\").submit();'>Write Review</a>" +
						"<input type='hidden' name='name' value='"+data.getId()+"'>"+
						"<input type='hidden' name='type' value='"+data.getType()+"'>"+
						"<input type='hidden' name='maker' value='"+data.getRetailer()+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
			   	pw.print("<form action='ViewReview' method='post' id='frmphonesVRiview"+data.getId()+"'> <a class='button' style='max-width: 200px;' onclick='document.getElementById(\"frmphonesVRiview"+data.getId()+"\").submit();'>View Review</a>" +
						"<input type='hidden' name='name' value='"+data.getId()+"'>"+
						"<input type='hidden' name='type' value='"+data.getType()+"'>"+
						"<input type='hidden' name='maker' value='"+data.getRetailer()+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
			}
			if(user!=null)
			{
				if(user.getUsertype().equals("manager"))
				{
					pw.print("<form action='DeleteProduct' method='post' id='frmdeletePhone"+data.getId()+"'> <a class='button' style='max-width: 200px;' onclick='document.getElementById(\"frmdeletePhone"+data.getId()+"\").submit();'>Delete</a>" +
							"<input type='hidden' name='prodID' value='"+data.getId()+"'>"+
							"</form>");
					pw.print("<form action='UpdateProduct' method='get' id='frmUpdateProductPhone"+data.getId()+"'> <a class='button' style='max-width: 200px;' onclick='document.getElementById(\"frmUpdateProductPhone"+data.getId()+"\").submit();'>Update</a>" +
							"<input type='hidden' name='prodID' value='"+data.getId()+"'>"+
							"<input type='hidden' name='prodName' value='"+data.getName()+"'>"+
							"<input type='hidden' name='prodPrice' value='"+data.getPrice()+"'>"+
							"<input type='hidden' name='prodCondition' value='"+data.getCondition()+"'>"+
							"<input type='hidden' name='prodDiscount' value='"+data.getDiscount()+"'>"+
							"</form>");
				}
			}
		pw.print("</figure><fieldset>");
		pw.print("<article> </section>");	
        utility.printHtml("LeftNavigationBar.html");		
		utility.printHtml("Footer.html");
		
		}
		catch(Exception e)
		{
			
		}
	}
	
	public void destroy()	{
      // do nothing.
	}
	

}