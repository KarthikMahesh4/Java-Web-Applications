import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;

@WebServlet("/ProductView")

public class ProductView extends HttpServlet {
		
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/* From the HttpServletRequest variable name,type,maker and acessories information are obtained.*/
		String name = request.getParameter("name");
		String condition = request.getParameter("condition");
		double price = Double.parseDouble(request.getParameter("price"));
		double discount = Double.parseDouble(request.getParameter("discount"));
		String imagepath = request.getParameter("imagepath");
		String key = request.getParameter("key");
		String type = request.getParameter("type");
		String maker = request.getParameter("maker");
		String access = request.getParameter("access");
		//System.out.print("name" + name + "type" + type + "maker" + maker + "accesee" + access);

		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		Utilities utility = new Utilities(request,pw);
		//Carousel carousel = new Carousel();
		/*if(!utility.isLoggedin()){
			HttpSession session = request.getSession(true);				
			session.setAttribute("login_msg", "Please Login to add items to cart");
			response.sendRedirect("Login");
			return;
		}*/
		
		utility.printHtml("Header.html");
		utility.printHtml("NAV.html");
		pw.print("<section id='content'>  <article>");
		//pw.print("<h3 >"+name+"</h3>");
		
		pw.print("<fieldset><legend>Items Details</legend> ");
		pw.print("<table cellspacing='0'><tr>");
		pw.print("<td><img src='"+imagepath+"' style='max-height: 200px !important;'></td><td style='text-align:top;'>");
		pw.print("<h3 >"+name+"</h3>");
		pw.print("<form  id='frmProductView' action='Cart' method='post'>");
		pw.print("<p><label for='oPrice'>Actual Price: </label><span  name='oPrice' >" +price+ "</span></p> ");
		pw.print("<p><label for='ouPrice'>Our Price: </label><span  name='ouPrice' >" +(price-discount)+ "</span></p> ");
		pw.print("<p><label for='condition'>Condition: </label><span  name='condition' >" +condition+ "</span></p> ");
		pw.print("<p><a class='button' onclick='document.getElementById(\"frmProductView\").submit();'>Buy Now</a></p> ");
		pw.print("<input type='hidden' name='name' value='"+key+"' />"+
				 "<input type='hidden' name='type' value='"+type+"' />"+
				 "<input type='hidden' name='maker' value='"+maker+"' />"+
				 "<input type='hidden' name='access' value='"+access+"' />");
		pw.print("</form>");
		pw.print("</td></tr></table></fieldset>");	
		pw.print("</article> </section>");	
		utility.printHtml("LeftNavigationBar.html");			
		utility.printHtml("Footer.html");
	}
	


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		Utilities utility = new Utilities(request, pw);
		
		doPost(request, response);
	}
}
