import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/PhonesList")

public class PhonesList extends HttpServlet {

	/* Phones Page Displays all the Phones and their Information in phones */

	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();

		/* Checks the Phones type whether it is electronicArts or activision or takeTwoInteractive */
				
		String name = null;
		String CategoryName = request.getParameter("maker");
		HashMap<String, Phones> hm = new HashMap<String, Phones>();
		HashMap<String,Phones> allPhones = new HashMap<String,Phones> ();
		try{
		     allPhones = MySqlDataStoreUtilities.getPhones();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		if(CategoryName==null)
		{
			hm.putAll(allPhones);
			name = "";
		}
		else
		{
		  if(CategoryName.equals("apple"))
		  {
			for(Map.Entry<String,Phones> entry : allPhones.entrySet())
				{
				if(entry.getValue().getRetailer().equals("Apple"))
				 {
					 hm.put(entry.getValue().getId(),entry.getValue());
				 }
				}
			name = "Apple";
		  }
		  else if(CategoryName.equals("nokia"))
		  {
			for(Map.Entry<String,Phones> entry : allPhones.entrySet())
				{
				if(entry.getValue().getRetailer().equals("Nokia"))
				 {
					 hm.put(entry.getValue().getId(),entry.getValue());
				 }
				}	
			name = "Nokia";
		  }
		  else if(CategoryName.equals("samsung"))
		  {
			for(Map.Entry<String,Phones> entry : allPhones.entrySet())
				{
				if(entry.getValue().getRetailer().equals("Samsung"))
				 {
					 hm.put(entry.getValue().getId(),entry.getValue());
				 }
				}
			name = "Samsung";
		  }
		  else if(CategoryName.equals("lenovo"))
		  {
			for(Map.Entry<String,Phones> entry : allPhones.entrySet())
				{
				if(entry.getValue().getRetailer().equals("Lenovo"))
				 {
					 hm.put(entry.getValue().getId(),entry.getValue());
				 }
				}
			name = "Lenovo";
		  }
		  else if(CategoryName.equals("google"))
		  {
			for(Map.Entry<String,Phones> entry : allPhones.entrySet())
				{
				if(entry.getValue().getRetailer().equals("Google"))
				 {
					 hm.put(entry.getValue().getId(),entry.getValue());
				 }
				}
			name = "Google";
		  }
		}

		/* Header is Printed.

		All the Laptops and Laptops information are dispalyed in the Content Section

		and then Left Navigation Bar,Footer is Printed*/
		
		Utilities utility = new Utilities(request,pw);
		User user=utility.getUser();
		boolean showButton=true;
		if(user!=null)
		{
			if(user.getUsertype().equals("retailer") || user.getUsertype().equals("manager"))
			{
				showButton=false;
			}
		}
		utility.printHtml("Header.html");
		utility.printHtml("NAV.html");
		pw.print("<section id='content'>  <article>");
		pw.print(" <h3>"+name+" Phones</h3>");
		pw.print("<div id='wrap'><div id='columns' class='columns_3'>");
		int i = 1; int size= hm.size();
		for(Map.Entry<String, Phones> entry : hm.entrySet()){
			Phones phones = entry.getValue();
		    pw.print("<figure>");
			pw.print("<img src='images/phones/"+phones.getImage()+"' style='max-height: 200px !important;'>");
			pw.print("<figcaption>"+phones.getName()+"</figcaption>");
			pw.print("<span class=price>$" + phones.getPrice() + "</span>");
			if(showButton)
			{
				pw.print("<form action='Cart' method='post' id='frmphonescart"+phones.getId()+"'> <a class='button' onclick='document.getElementById(\"frmphonescart"+phones.getId()+"\").submit();'>Buy Now</a>" +
						"<input type='hidden' name='name' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='phones'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
				pw.print("<form action='ProductView' method='post' id='frmphoneswriteReview"+phones.getId()+"'> <a class='button' onclick='document.getElementById(\"frmphoneswriteReview"+phones.getId()+"\").submit();'>View</a> "+
						"<input type='hidden' name='name' value='"+phones.getName()+"'>"+
						"<input type='hidden' name='condition' value='"+phones.getCondition()+"'>"+
						"<input type='hidden' name='price' value='"+phones.getPrice()+"'>"+
						"<input type='hidden' name='discount' value='"+phones.getDiscount()+"'>"+
						"<input type='hidden' name='imagepath' value='images/phones/"+phones.getImage()+"'>"+
						"<input type='hidden' name='key' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='phones'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
				pw.print("<form action='WriteReview' method='post' id='frmphonesWRiview"+phones.getId()+"'> <a class='button' onclick='document.getElementById(\"frmphonesWRiview"+phones.getId()+"\").submit();'>Write Review</a>" +
						"<input type='hidden' name='name' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='phones'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
			   	pw.print("<form action='ViewReview' method='post' id='frmphonesVRiview"+phones.getId()+"'> <a class='button' onclick='document.getElementById(\"frmphonesVRiview"+phones.getId()+"\").submit();'>View Review</a>" +
						"<input type='hidden' name='name' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='phones'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
			}
			if(user!=null)
			{
				if(user.getUsertype().equals("manager"))
				{
					pw.print("<form action='DeleteProduct' method='post' id='frmdeletePhone"+phones.getId()+"'> <a class='button' onclick='document.getElementById(\"frmdeletePhone"+phones.getId()+"\").submit();'>Delete</a>" +
							"<input type='hidden' name='prodID' value='"+phones.getId()+"'>"+
							"</form>");
					pw.print("<form action='UpdateProduct' method='get' id='frmUpdateProductPhone"+phones.getId()+"'> <a class='button' onclick='document.getElementById(\"frmUpdateProductPhone"+phones.getId()+"\").submit();'>Update</a>" +
							"<input type='hidden' name='prodID' value='"+phones.getId()+"'>"+
							"<input type='hidden' name='prodName' value='"+phones.getName()+"'>"+
							"<input type='hidden' name='prodPrice' value='"+phones.getPrice()+"'>"+
							"<input type='hidden' name='prodCondition' value='"+phones.getCondition()+"'>"+
							"<input type='hidden' name='prodDiscount' value='"+phones.getDiscount()+"'>"+
							"</form>");
				}
			}
			pw.print("</figure>");
			
			i++;
		}		
		pw.print("</div></div></article> </section>");	
        utility.printHtml("LeftNavigationBar.html");		
		utility.printHtml("Footer.html");
		
	}

}
