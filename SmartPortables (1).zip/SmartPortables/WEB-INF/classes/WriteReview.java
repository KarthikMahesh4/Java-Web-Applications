

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/WriteReview")
	//once the user clicks writereview button from products page he will be directed
 	//to write review page where he can provide reqview for item rating reviewtext	
	
public class WriteReview extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
	    Utilities utility= new Utilities(request, pw);
		review(request, response);
	}
	
	protected void review(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			try
			{
			   
				response.setContentType("text/html");
				PrintWriter pw = response.getWriter();
				Utilities utility = new Utilities(request,pw);
				if(!utility.isLoggedin()){
					HttpSession session = request.getSession(true);				
					session.setAttribute("login_msg", "Please Login to Write a Review");
					response.sendRedirect("Login");
					return;
				}
				String productname=request.getParameter("name");		
				String producttype=request.getParameter("type");
				String productmaker=request.getParameter("maker");
				  
	 
				utility.printHtml("Header.html");
				utility.printHtml("NAV.html");
				pw.print("<section id='content'>  <article>");
				pw.print("<h3 >Review</h3>");
				pw.print("<fieldset><legend>Write Review</legend> <form method='post' action='SubmitReview' name='WriteReview'>");
                pw.print("<p><label for='productName'>Product Model Name: </label><span name='productName' >"+productname+"</span></p>");
				pw.print("<input type='hidden' name='productname' value='"+productname+"'>");
				pw.print("<p><label for='productType'>Product Category: </label><span name='productType' >"+producttype+"</span></p>");
				pw.print("<input type='hidden' name='producttype' value='"+producttype+"'>");
				pw.print("<p><label for='productPrice'>Product Price: </label><input type='text' name='productPrice' required></input></p>");
				pw.print("<p><label for='retailerName'>Retailer Name: </label><input type='text' name='retailerName' required></input></p>");
				pw.print("<p><label for='pin'>Retailer Zip: </label><input type='text' name='pin' maxlength='5' required></input></p>");
				pw.print("<p><label for='retailerCity'>Retailer City: </label><input type='text' name='retailerCity' required></input></p>");
				pw.print("<p><label for='retailerState'>Retailer State: </label><input type='text' name='retailerState' required></input></p>");
				pw.print("<p><label for='productOnSale'>Product On Sale: </label>");
				pw.print("<select name='productOnSale'>");
				pw.print("<option value='Yes' selected>Yes</option>");
				pw.print("<option value='No'>No</option>");
				pw.print("</select></p>");  
				pw.print("<p><label for='manufacturerName'>Manufacturer Name: </label><input type='text' name='manufacturerName' required></input></p>");
				pw.print("<p><label for='manufacturerRebate'>Manufacturer Rebate: </label>");
				pw.print("<select name='manufacturerRebate'>");
				pw.print("<option value='Yes' selected>Yes</option>");
				pw.print("<option value='No'>No</option>");
				pw.print("</select></p>"); 
				pw.print("<p><label for='userAge'>User Age: </label><input type='text' name='userAge' required></input></p>");
				pw.print("<p><label for='userGender'>User Gender: </label>");
				pw.print("<select name='userGender'>");
				pw.print("<option value='Male' selected>Male</option>");
				pw.print("<option value='Female'>Female</option>");
				pw.print("<option value='Other'>Other</option>");
				pw.print("</select></p>");
				pw.print("<p><label for='userOccupation'>User Occupation: </label><input type='text' name='userOccupation' required></input></p>");
				//pw.print("<p><label for='productMaker'>Product Maker: </label><span name='productMaker' >"+productmaker+"</span></p>");
				//pw.print("<input type='hidden' name='productmaker' value='"+productmaker+"'>");
				pw.print("<p><label for='reviewrating'>Review Rating: </label>");
				pw.print("<select name='reviewrating'>");
				pw.print("<option value='1' selected>1</option>");
				pw.print("<option value='2'>2</option>");
				pw.print("<option value='3'>3</option>");
				pw.print("<option value='4'>4</option>");
				pw.print("<option value='5'>5</option></select></p>");  
				pw.print("<p><label for='reviewdate'>Review Date: </label><input type='date' name='reviewdate'required></input></p>");
				pw.print("<p><label for='reviewtext'>Review Text: </label><textarea rows='4' cols='50' name='reviewtext' required> </textarea></p>");
				pw.print("<p><input type='submit' class='formbutton' name='SubmitReview' value='SubmitReview'></p>");
				pw.print("</form>" + "</fieldset></article> </section>");		
				utility.printHtml("LeftNavigationBar.html");
				utility.printHtml("Footer.html");
						
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}  			
		}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
    }
}
