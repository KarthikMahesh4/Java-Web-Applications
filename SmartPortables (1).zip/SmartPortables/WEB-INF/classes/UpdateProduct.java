import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.w3c.dom.*; 
import javax.xml.parsers.*; 
import javax.xml.transform.*; 
import javax.xml.transform.stream.*; 
import java.io.*;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload; 
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.FilenameUtils;
import java.util.List;
import javax.xml.transform.dom.DOMSource; 
import javax.xml.xpath.*;

@WebServlet("/UpdateProduct")

public class UpdateProduct extends HttpServlet {
	private String error_msg;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		displayRegistration(request, response, pw, false);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException  {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		Utilities utility = new Utilities(request, pw);

		/*String username = request.getParameter("username");
		String password = request.getParameter("password");
		String repassword = request.getParameter("repassword");
		String usertype = "customer";*/
		String TOMCAT_HOME = System.getProperty("catalina.home");			
		try
		{		
			DiskFileItemFactory factory = new DiskFileItemFactory();
			ServletFileUpload sfu = new ServletFileUpload(factory);

			if (!ServletFileUpload.isMultipartContent(request)) {
				System.out.println("sorry. No file uploaded");
				return;
			}
			List items = sfu.parseRequest(request);
			FileItem id = (FileItem) items.get(0);
			String productID = id.getString();
			System.out.println(productID);
			
			FileItem name = (FileItem) items.get(1);
			String productName = name.getString();
			
			FileItem price = (FileItem) items.get(2);
			String priceDesc = price.getString();
			
			// get uploaded file
			FileItem file = (FileItem) items.get(3);
			
			FileItem codn = (FileItem) items.get(4);
			String condi= codn.getString();
			
			FileItem ptype = (FileItem) items.get(5);
			String productType= ptype.getString();
			
			FileItem pstype = (FileItem) items.get(6);
			String productSubType= pstype.getString();
			
			FileItem dis = (FileItem) items.get(7);
			String disc= dis.getString();
			
			FileItem ref = (FileItem) items.get(8);
			String refer= ref.getString();
			
			FileItem iCount = (FileItem) items.get(9);
			int iTemCount= Integer.parseInt(iCount.getString());
			
		
			
			File imagefile=null;
			
			/*DocumentBuilderFactory dbf=DocumentBuilderFactory.newInstance(); 
			DocumentBuilder db =dbf.newDocumentBuilder(); 
			// Read books.xml file 
			Document doc=db.parse(TOMCAT_HOME+"\\webapps\\SmartPortables\\ProductCatalog.xml"); 
			
			// Root Element
			//Element rootElement = document.getDocumentElement();
			Element root = doc.getDocumentElement();
			Element rootElement = doc.getDocumentElement();
			
			Element productTag =  (Element) rootElement.getElementsByTagName(productType).item(0);
			
			Element newConsole=null;
			if(productType.equals("ConsoleCatalog"))
			{
			  newConsole = doc.createElement("console");
			  imagefile=new File(TOMCAT_HOME+"\\webapps\\SmartPortables\\images\\consoles\\"+FilenameUtils.getName(file.getName()));
			}
			if(productType.equals("AccessoryCatalog"))
			{
			  newConsole = doc.createElement("accessory");
			  imagefile=new File(TOMCAT_HOME+"\\webapps\\SmartPortables\\images\\accessories\\"+FilenameUtils.getName(file.getName()));
			}
			if(productType.equals("PhonesCatalog"))
			{
			  newConsole = doc.createElement("phone");
			  imagefile=new File(TOMCAT_HOME+"\\webapps\\SmartPortables\\images\\phones\\"+FilenameUtils.getName(file.getName()));
			}
		    if(productType.equals("WearablesCatalog"))
			{
			  newConsole = doc.createElement("wearable");
			  imagefile=new File(TOMCAT_HOME+"\\webapps\\SmartPortables\\images\\wearables\\"+FilenameUtils.getName(file.getName()));
			}
			if(productType.equals("SmartAssistanceCatalog"))
			{
			  newConsole = doc.createElement("smartassistance");
			  imagefile=new File(TOMCAT_HOME+"\\webapps\\SmartPortables\\images\\smartassistances\\"+FilenameUtils.getName(file.getName()));
			}
			if(productType.equals("LaptopsCatalog"))
			{
			  newConsole = doc.createElement("laptop");
			  imagefile=new File(TOMCAT_HOME+"\\webapps\\SmartPortables\\images\\laptops\\"+FilenameUtils.getName(file.getName()));
			}
			
			deleteElement(doc,productID);
			
			newConsole.setAttribute("id", productID);  
			Element Name = doc.createElement("name");
			Name.setTextContent(productName);
			newConsole.appendChild(Name);
			
			Element priceEL = doc.createElement("price");
			priceEL.setTextContent(priceDesc);
			newConsole.appendChild(priceEL);
			
			Element image = doc.createElement("image");
			image.setTextContent(FilenameUtils.getName(file.getName()));
			newConsole.appendChild(image);
			
			Element manufacturer = doc.createElement("manufacturer");
			manufacturer.setTextContent(productSubType);
			newConsole.appendChild(manufacturer);
			
			Element condition = doc.createElement("condition");
			condition.setTextContent(condi);
			newConsole.appendChild(condition);
			
			Element discount = doc.createElement("discount");
			discount.setTextContent(disc);
			newConsole.appendChild(discount);
			
			productTag.appendChild(newConsole);
			rootElement.appendChild(productTag);

			DOMSource source = new DOMSource(doc);

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			StreamResult result = new StreamResult(TOMCAT_HOME+"\\webapps\\SmartPortables\\ProductCatalog.xml");
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.transform(source, result);*/
			
			if(productType.equals("ConsoleCatalog"))
			{
			  imagefile=new File(TOMCAT_HOME+"\\webapps\\SmartPortables\\images\\consoles\\"+FilenameUtils.getName(file.getName()));
			}
			if(productType.equals("AccessoryCatalog"))
			{
			  imagefile=new File(TOMCAT_HOME+"\\webapps\\SmartPortables\\images\\accessories\\"+FilenameUtils.getName(file.getName()));
			}
			if(productType.equals("PhonesCatalog"))
			{
			  imagefile=new File(TOMCAT_HOME+"\\webapps\\SmartPortables\\images\\phones\\"+FilenameUtils.getName(file.getName()));
			}
		    if(productType.equals("WearablesCatalog"))
			{
			  imagefile=new File(TOMCAT_HOME+"\\webapps\\SmartPortables\\images\\wearables\\"+FilenameUtils.getName(file.getName()));
			}
			if(productType.equals("SmartAssistanceCatalog"))
			{
			  imagefile=new File(TOMCAT_HOME+"\\webapps\\SmartPortables\\images\\smartassistances\\"+FilenameUtils.getName(file.getName()));
			}
			if(productType.equals("LaptopsCatalog"))
			{
			  imagefile=new File(TOMCAT_HOME+"\\webapps\\SmartPortables\\images\\laptops\\"+FilenameUtils.getName(file.getName()));
			}
			
			OutputStream outputStream = new FileOutputStream(imagefile);
			IOUtils.copy(file.getInputStream(), outputStream);
			outputStream.close();
			MySqlDataStoreUtilities.updateproducts(productType,productID,productName,Double.parseDouble(priceDesc),FilenameUtils.getName(file.getName()),productSubType,condi,Double.parseDouble(disc),iTemCount);
			//SaxParserDataStore.addHashmap();
			//System.out.println(refer);
			response.sendRedirect(refer);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}	
		
		//displayRegistration(request, response, pw, true);
		
	}

	/*  displayRegistration function displays the Registration page of New User */
	
	protected void displayRegistration(HttpServletRequest request,
			HttpServletResponse response, PrintWriter pw, boolean error)
			throws ServletException, IOException {
		Utilities utility = new Utilities(request, pw);
		User user=utility.getUser();
		System.out.println(user.getUsertype());
		
		if(user.getUsertype().equals("retailer"))
		{
			try
			{
				/*String TOMCAT_HOME = System.getProperty("catalina.home");
				File xmlFile = new File(TOMCAT_HOME+"\\webapps\\SmartPortables\\ProductCatalog.xml");
				DocumentBuilderFactory dbf=DocumentBuilderFactory.newInstance(); 
				DocumentBuilder db =dbf.newDocumentBuilder(); 
				// Read books.xml file 
				Document doc=db.parse(xmlFile); 
				doc.getDocumentElement().normalize();
				XPathFactory factory = XPathFactory.newInstance();
				XPath xpath = factory.newXPath();
				String id=(String)request.getParameter("prodID");
				XPathExpression expr = xpath.compile("//*[@id = '" + id + "']");
				Element eElement = (Element) expr.evaluate(doc, XPathConstants.NODE);*/
				utility.printHtml("Header.html");
				utility.printHtml("NAV.html");
				pw.print("<section id='content'>  <article>");
				pw.print("<h3 >Update Product</h3>");
						
				if (error)
				{	
				   pw.print("<h5 style='color:green'>Product updated Successfully</h5>");
				}
				pw.print("<fieldset><legend>Enter Product Details</legend> <form method='post' action='UpdateProduct' enctype='multipart/form-data'>"
						+ "<p><label for='productID'>Product ID: </label><input type='text' name='productID' value='"+((String)request.getParameter("prodID"))+"' ></input></p>"
						+ "<p><label for='productName'>Product Name: </label><input type='text' name='productName' value='"+((String)request.getParameter("prodName"))+"' required></input> </p>"
						+ "<p><label for='productPrice'>Product Price: </label><input type='text' name='productPrice' value='"+((String)request.getParameter("prodPrice"))+"' required></input> </p>"
						+ "<p><label for='prodimg'>Product Image: </label><input type=file name=prodimg required></p>"
						+ "<p><label for='condition'>Condition: </label><input type='text' name='condition' value='"+((String)request.getParameter("prodCondition"))+"' required></input></p>"
						+ "<p><label for='productType'>Product Type:</label><select name='productType' required><option value='' selected>Please Select</option><option value='ConsoleCatalog'>Consoles</option><option value='WearablesCatalog'>Wearable Technology</option><option value='PhonesCatalog'>Phones</option><option value='LaptopsCatalog'>Laptops</option><option value='SmartAssistanceCatalog'>Voice Assistants</option><option value='AccessoryCatalog'>Accessories</option></select></p>"
						
						+ "<p><label for='subProductType'>Sub Product Type:</label><select name='subProductType' required><option value='' selected>Please Select</option>"
						+"<option value='Microsoft'>Microsoft</option>"
						+"<option value='Sony'>Sony</option>"
						+"<option value='Nintendo'>Nintendo</option>"
						+"<option value='Fitness Watches'>Fitness Watches</option>"
						+"<option value='Smart Watches'>Smart Watches</option>"
						+"<option value='Headphones'>Headphones</option>"
						+"<option value='Virtual Reality'>Virtual Reality</option>"
						+"<option value='Pet Tracker'>Pet Tracker</option>"
						+"<option value='Samsung'>Samsung</option>"
						+"<option value='Nokia'>Nokia</option>"
						+"<option value='Google'>Google</option>"
						+"<option value='Apple'>Apple</option>"
						+"<option value='Lenovo'>Lenovo</option>"
						+"<option value='HP'>HP</option>"
						+"<option value='Dell'>Dell</option>"
						+"<option value='Harman'>Harman</option>"
						+"<option value='Amazon'>Amazon</option>"
						+"<option value='MI'>MI</option>"
						+"</select></p>"
						+ "<p><label for='discount'>Discount: </label><input type='text' name='discount' value='"+((String)request.getParameter("prodDiscount"))+"' required></input></p>"
						+ "<p><input type='text' style='display:none' name='Referer' value='"+request.getHeader("Referer")+"' ></input></p>"
						+ "<p><label for='itemCount'>Item Count: </label><input type='text' name='itemCount' value='' required></input></p>"
						+ "<p><input name='submit' style='margin-left: 150px;'  class='formbutton' value='Submit' type='submit' /></p>"
						+ "</form>" + "</fieldset></article> </section>");
				utility.printHtml("LeftNavigationBar.html");
				utility.printHtml("Footer.html");
				//doc.getDocumentElement().normalize();
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}	
		}
		else 
		{
			utility.printHtml("Header.html");
			utility.printHtml("NAV.html");
			pw.print("<section id='content'>  <article>");
			pw.print("<h3>Not Authorized</h3>");
			pw.print("<div id='wrap'><div id='columns' class='columns_3'>");
			pw.print("</div></div></article> </section>");	
			utility.printHtml("LeftNavigationBar.html");		
			utility.printHtml("Footer.html");
		}
		
		
	}
	
	private static void deleteElement(Document doc,String id) {
		try{
			XPathFactory factory = XPathFactory.newInstance();
			XPath xpath = factory.newXPath();
			XPathExpression expr = xpath.compile("//*[@id = '" + id + "']");
			Element deleteNode = (Element) expr.evaluate(doc, XPathConstants.NODE);
			if(deleteNode==null)
			{
				System.out.println("Null Element");
			}
			Node parent = deleteNode.getParentNode();
			parent.removeChild(deleteNode);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
    }
}
