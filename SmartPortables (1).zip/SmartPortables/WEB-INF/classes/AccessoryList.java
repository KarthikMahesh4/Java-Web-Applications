import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/AccessoryList")

public class AccessoryList extends HttpServlet {

	/* Accessory Page Displays all the Accessories and their Information in Game Speed */

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();

		/* Checks the Console maker whether it is microsft or sony or nintendo 
		   Add the respective product value to hashmap  */

		String CategoryName = request.getParameter("maker");
//		String ConsoleName = request.getParameter("console");
		HashMap<String, Console> hm = new HashMap<String, Console>();
			if(CategoryName.equals("microsoft"))
			{
				for(Map.Entry<String,Console> entry : SaxParserDataStore.consoles.entrySet())
				{	
					if(entry.getValue().getRetailer().equals("Microsoft"))
					{
					 hm.put(entry.getValue().getId(),entry.getValue());
					}
				}
				
			}
			else if(CategoryName.equals("sony"))
			{	
				for(Map.Entry<String,Console> entry : SaxParserDataStore.consoles.entrySet())
				{	
				  if(entry.getValue().getRetailer().equals("Sony"))
				 { 
					hm.put(entry.getValue().getId(),entry.getValue());
				 }
				}
			}
			else if(CategoryName.equals("nintendo"))
			{
				for(Map.Entry<String,Console> entry : SaxParserDataStore.consoles.entrySet())
				{
				  if(entry.getValue().getRetailer().equals("Nintendo"))
				 {
					 hm.put(entry.getValue().getId(),entry.getValue());
				 }
				}	
			}
			
//		Console console = hm.get(ConsoleName);
				
		/* Header, Left Navigation Bar are Printed.

		All the Accessories and Accessories information are dispalyed in the Content Section

		and then Footer is Printed*/

		
		Utilities utility = new Utilities(request,pw);
		User user=utility.getUser();
		boolean showButton=true;
		if(user!=null)
		{
			if(user.getUsertype().equals("retailer") || user.getUsertype().equals("manager"))
			{
				showButton=false;
			}
		}
		utility.printHtml("Header.html");
		utility.printHtml("NAV.html");
		pw.print("<section id='content'>  <article>");
		pw.print(" <h3>"+CategoryName+": Accessories</h3>");
		pw.print("<div id='wrap'><div id='columns' class='columns_3'>");
		
		int i = 1; int size= 2;
		for(Map.Entry<String, Console> entry : hm.entrySet())
		{
			Console console = entry.getValue();
			for(Map.Entry<String, String> acc:console.getAccessories().entrySet())
			{
		        
				Accessory accessory= SaxParserDataStore.accessories.get(acc.getValue());
				
				
				
				pw.print("<figure>");
				pw.print("<img src='images/accessories/"+accessory.getImage()+"' style='max-height: 200px !important;'>");
				pw.print("<figcaption>"+accessory.getName()+"</figcaption>");
				pw.print("<span class=price>$" + accessory.getPrice() + "</span>");

				if(showButton)
				{
					pw.print("<form action='Cart' method='post' id='frmassocart"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmassocart"+accessory.getId()+"\").submit();'>Buy Now</a>" +
						"<input type='hidden' name='name' value='"+acc.getValue()+"'>"+
						"<input type='hidden' name='type' value='accessories'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value='"+console.getName()+"'>"+
						"</form>");
					pw.print("<form action='ProductView' method='post' id='frmassowriteReview"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmassowriteReview"+accessory.getId()+"\").submit();'>View</a> "+
							"<input type='hidden' name='name' value='"+console.getName()+"'>"+
							"<input type='hidden' name='condition' value='"+accessory.getCondition()+"'>"+
							"<input type='hidden' name='price' value='"+accessory.getPrice()+"'>"+
							"<input type='hidden' name='discount' value='"+accessory.getDiscount()+"'>"+
							"<input type='hidden' name='imagepath' value='images/accessories/"+accessory.getImage()+"'>"+
							"<input type='hidden' name='key' value='"+acc.getValue()+"'>"+
							"<input type='hidden' name='type' value='accessories'>"+
							"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
							"<input type='hidden' name='access' value='"+console.getName()+"'>"+
							"</form>");
				}
				if(user!=null)
				{
					if(user.getUsertype().equals("retailer"))
					{
						pw.print("<form action='DeleteProduct' method='post' id='frmdeleteass"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmdeleteass"+accessory.getId()+"\").submit();'>Delete</a>" +
								"<input type='hidden' name='prodID' value='"+accessory.getId()+"'>"+
								"</form>");
						pw.print("<form action='UpdateProduct' method='get' id='frmdUpdateProductass"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmdUpdateProductass"+accessory.getId()+"\").submit();'>Update</a>" +
								"<input type='hidden' name='prodID' value='"+accessory.getId()+"'>"+
								"</form>");
					}
				}

				pw.print("</figure>");
				i++;
				
			}	
		}	
		pw.print("</div></div></article> </section>");	
        utility.printHtml("LeftNavigationBar.html");		
		utility.printHtml("Footer.html");
	}
}
