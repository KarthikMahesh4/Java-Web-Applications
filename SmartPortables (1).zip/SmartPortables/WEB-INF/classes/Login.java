import java.io.*;
import java.io.PrintWriter;
import java.util.HashMap;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/Login")

public class Login extends HttpServlet {

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();

		/* User Information(username,password,usertype) is obtained from HttpServletRequest,
		Based on the Type of user(customer,retailer,manager) respective hashmap is called and the username and 
		password are validated and added to session variable and display Login Function is called */

		String username = request.getParameter("username");
		String password = request.getParameter("password");
		//String usertype = request.getParameter("usertype");
		HashMap<String, User> hm=new HashMap<String, User>();
		try
		{	
			hm=MySqlDataStoreUtilities.selectUser();
		}
		catch(Exception e)
		{
			e.printStackTrace();	
		}
		User user = hm.get(username);
		if(user!=null)
		{
		 String user_password = user.getPassword();
		 if (password.equals(user_password)) 
			{
			HttpSession session = request.getSession(true);
			session.setAttribute("username", user.getName());
			session.setAttribute("usertype", user.getUsertype());
			response.sendRedirect("Home");
			return;
			}
		}
		displayLogin(request, response, pw, true);
	}

	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		displayLogin(request, response, pw, false);
	}


	/*  Login Screen is Displayed, Registered User specifies credentials and logins into the Game Speed Application. */
	protected void displayLogin(HttpServletRequest request,
			HttpServletResponse response, PrintWriter pw, boolean error)
			throws ServletException, IOException {

		Utilities utility = new Utilities(request, pw);
		utility.printHtml("Header.html");
		utility.printHtml("NAV.html");
		pw.print("<section id='content'>  <article>");
		pw.print("<h3 >Login</h3>");
				
		if (error)
			pw.print("<h5 style='color:red'>Please check your username, password and user type!</h5>");
		HttpSession session = request.getSession(true);
		if(session.getAttribute("login_msg")!=null){			
			pw.print("<h5 style='color:red'>"+session.getAttribute("login_msg")+"</h5>");
			session.removeAttribute("login_msg");
		}
		pw.print("<fieldset><legend>Enter Login Details</legend><form method='post' action='Login'>"
				+ "<p><label for='username'>Username:</label><input type='text' name='username' value='' required></input></p>"
				+ "<p><label for='password'>Password:</label><input type='password' name='password' value='' required></p>"
				//+ "<p><label for='usertype'>User Type:</label><select name='usertype' class='input'><option value='customer' selected>Customer</option><option value='retailer'>Store Manager</option><option value='manager'>Salesman</option></select></p>"
				+ "</td></tr><tr><td style='border:none;'></td><td style='border:none;'>"
				+ "<p><input name='send' style='margin-left: 150px;' class='formbutton' value='Login' type='submit' /></p>"
				+ "<p><a href='Registration' style='padding-right: 5px;float: right;'>New User? Register here!</a> </p> "
				+ "</form>" + "  </fieldset></article> </section>");
		utility.printHtml("LeftNavigationBar.html");
		utility.printHtml("Footer.html");
	}

}
