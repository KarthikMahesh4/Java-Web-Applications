/* This code is used to implement carousel feature in Website. Carousels are used to implement slide show feature. This  code is used to display 
all the accessories related to a particular product. This java code is getting called from cart.java. The product which is added to cart, all the 
accessories related to product will get displayed in the carousel.*/
  

import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;			
			
			
public class Carousel{
			
	public String  carouselfeature(Utilities utility){
				
		try
		{		
		
		
		ProductRecommenderUtility prodRecUtility = new ProductRecommenderUtility();
		HashMap<String,String> prodRecmMap = new HashMap<String,String>();
		prodRecmMap = prodRecUtility.readOutputFile();
		
		User user=utility.getUser();
		boolean showButton=true;
		if(user!=null)
		{
			if(user.getUsertype().equals("retailer") || user.getUsertype().equals("manager"))
			{
				showButton=false;
			}
		}
		
		HashMap<String, Console> hm = new HashMap<String, Console>();
		HashMap<String, Laptops> hmL = new HashMap<String, Laptops>();
		HashMap<String, Phones> hmP = new HashMap<String, Phones>();
		HashMap<String, Wearable> hmW = new HashMap<String, Wearable>();
		HashMap<String, SmartAssistance> hmSA = new HashMap<String, SmartAssistance>();
		HashMap<String,Accessory> allAccessory=new HashMap<String,Accessory>();
		StringBuilder sb = new StringBuilder();
		String myCarousel = null;
			
		String name = null;
		String CategoryName = null;
		if(CategoryName==null){
			HashMap<String, Console> allConsole = new HashMap<String, Console>();
			HashMap<String, Laptops> allLaptops = new HashMap<String, Laptops>();
			HashMap<String, Phones> allPhones = new HashMap<String, Phones>();
			HashMap<String, Wearable> allWearable = new HashMap<String, Wearable>();
			HashMap<String, SmartAssistance> allSmartAssistance = new HashMap<String, SmartAssistance>();
			try{
				 allConsole = MySqlDataStoreUtilities.getConsoles();
				 allLaptops = MySqlDataStoreUtilities.getLaptops();
				 allPhones = MySqlDataStoreUtilities.getPhones();
				 allSmartAssistance = MySqlDataStoreUtilities.getSmartAssistances();
				 allWearable = MySqlDataStoreUtilities.getWearables();
				 allAccessory = MySqlDataStoreUtilities.getAccessories();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			hm.putAll(allConsole);
			hmL.putAll(allLaptops);
			hmP.putAll(allPhones);
			hmW.putAll(allWearable);
			hmSA.putAll(allSmartAssistance);
			name = "";
		}
		int l =0;
		//System.out.println("");
		//System.out.println(hm.size());
		//System.out.println(hmL.size());
		/*for(Map.Entry<String, Laptops> entry : hmL.entrySet())
		{
			System.out.println(entry.getKey());
		}
		for(Map.Entry<String, Phones> entry : hmP.entrySet())
		{
			System.out.println(entry.getKey());
		}
		for(Map.Entry<String, Wearable> entry : hmW.entrySet())
		{
			System.out.println(entry.getKey());
		}
		for(Map.Entry<String, SmartAssistance> entry : hmSA.entrySet())
		{
			System.out.println(entry.getKey());
		}*/
		int P=0;
		for(String users: prodRecmMap.keySet())
		{
			if(users.equals(utility.username()))
			{
				String products = prodRecmMap.get(users);
				products=products.replace("[","");
				products=products.replace("]","");
				products=products.replace("\"", " ");
				ArrayList<String> productsList = new ArrayList<String>(Arrays.asList(products.split(",")));
				
				//System.out.println(hm.get(oi.getName()));
		        myCarousel = "myCarouselRecomender"+P;
				//System.out.println("Enter here2");	
				sb.append("<h3 >Recommended Products</h3>");
				sb.append("<div class='container'>");
				/* Carousels require the use of an id (in this case id="myCarousel") for carousel controls to function properly.
				The .slide class adds a CSS transition and animation effect, which makes the items slide when showing a new item.
				Omit this class if you do not want this effect. 
				The data-ride="carousel" attribute tells Bootstrap to begin animating the carousel immediately when the page loads. 
		 
				*/
				sb.append("<div class='carousel slide' id='"+myCarousel+"' data-ride='carousel'>");
				
				/*The slides are specified in a <div> with class .carousel-inner.
				The content of each slide is defined in a <div> with class .item. This can be text or images.
				The .active class needs to be added to one of the slides. Otherwise, the carousel will not be visible.
				*/
				sb.append("<div class='carousel-inner'>");
						
				int k = 0;
			
				for(String prod : productsList){
					prod= prod.replace("'", "");
					Product data = new Product();
					data = ProductRecommenderUtility.getProduct(prod.trim());
					if (k==0 )
					{
						sb.append("<div class='item active'><div class='col-md-6' >");
					}
					else
					{
						sb.append("<div class='item'><div class='col-md-6'  >");
					}
					
					
					sb.append("<figure>");
					sb.append("<img src='images/"+data.getType()+"/"+data.getImage()+"' style='max-height: 200px !important;'>");
					sb.append("<figcaption>"+data.getName()+"</figcaption>");
					sb.append("<span class=price>$" + data.getPrice() + "</span>");
					if(showButton)
					{
						sb.append("<form action='Cart' method='post' id='frmphonescart"+data.getId()+"'> <a class='button'  onclick='document.getElementById(\"frmphonescart"+data.getId()+"\").submit();'>Buy Now</a>" +
								"<input type='hidden' name='name' value='"+data.getId()+"'>"+
								"<input type='hidden' name='type' value='"+data.getType()+"'>"+
								"<input type='hidden' name='maker' value='"+data.getRetailer()+"'>"+
								"<input type='hidden' name='access' value=''>"+
								"</form>");
						sb.append("<form action='ProductView' method='post' id='frmphoneswriteReview"+data.getId()+"'> <a class='button'  onclick='document.getElementById(\"frmphoneswriteReview"+data.getId()+"\").submit();'>View</a> "+
								"<input type='hidden' name='name' value='"+data.getName()+"'>"+
								"<input type='hidden' name='condition' value='"+data.getCondition()+"'>"+
								"<input type='hidden' name='price' value='"+data.getPrice()+"'>"+
								"<input type='hidden' name='discount' value='"+data.getDiscount()+"'>"+
								"<input type='hidden' name='imagepath' value='images/"+data.getType()+"/"+data.getImage()+"'>"+
								"<input type='hidden' name='key' value='"+data.getId()+"'>"+
								"<input type='hidden' name='type' value='"+data.getType()+"'>"+
								"<input type='hidden' name='maker' value='"+data.getRetailer()+"'>"+
								"<input type='hidden' name='access' value=''>"+
								"</form>");
						sb.append("<form action='WriteReview' method='post' id='frmphonesWRiview"+data.getId()+"'> <a class='button'  onclick='document.getElementById(\"frmphonesWRiview"+data.getId()+"\").submit();'>Write Review</a>" +
								"<input type='hidden' name='name' value='"+data.getId()+"'>"+
								"<input type='hidden' name='type' value='"+data.getType()+"'>"+
								"<input type='hidden' name='maker' value='"+data.getRetailer()+"'>"+
								"<input type='hidden' name='access' value=''>"+
								"</form>");
						sb.append("<form action='ViewReview' method='post' id='frmphonesVRiview"+data.getId()+"'> <a class='button'  onclick='document.getElementById(\"frmphonesVRiview"+data.getId()+"\").submit();'>View Review</a>" +
								"<input type='hidden' name='name' value='"+data.getId()+"'>"+
								"<input type='hidden' name='type' value='"+data.getType()+"'>"+
								"<input type='hidden' name='maker' value='"+data.getRetailer()+"'>"+
								"<input type='hidden' name='access' value=''>"+
								"</form>");
					}
					if(user!=null)
					{
						if(user.getUsertype().equals("manager"))
						{
							sb.append("<form action='DeleteProduct' method='post' id='frmdeletePhone"+data.getId()+"'> <a class='button'  onclick='document.getElementById(\"frmdeletePhone"+data.getId()+"\").submit();'>Delete</a>" +
									"<input type='hidden' name='prodID' value='"+data.getId()+"'>"+
									"</form>");
							sb.append("<form action='UpdateProduct' method='get' id='frmUpdateProductPhone"+data.getId()+"'> <a class='button'  onclick='document.getElementById(\"frmUpdateProductPhone"+data.getId()+"\").submit();'>Update</a>" +
									"<input type='hidden' name='prodID' value='"+data.getId()+"'>"+
									"<input type='hidden' name='prodName' value='"+data.getName()+"'>"+
									"<input type='hidden' name='prodPrice' value='"+data.getPrice()+"'>"+
									"<input type='hidden' name='prodCondition' value='"+data.getCondition()+"'>"+
									"<input type='hidden' name='prodDiscount' value='"+data.getDiscount()+"'>"+
									"</form>");
						}
					}
					sb.append("</figure>");
					sb.append("</div></div>");
					k++;
				}
			
				sb.append("</div>");
				/*		The "Left and right controls" part:
					This code adds "left" and "right" buttons that allows the user to go back and forth between the slides manually.
				The data-slide attribute accepts the keywords "prev" or "next", which alters the slide position relative to its current position.
				*/
				sb.append("<a class='left carousel-control' href='#"+myCarousel+"' data-slide='prev' style = 'width: 4%;opacity: 1;'>"+
						"<span class='glyphicon glyphicon-chevron-left' style = 'color :red'></span>"+
						"<span class='sr-only'>Previous</span>"+
						"</a>");
				sb.append("<a class='right carousel-control' href='#"+myCarousel+"' data-slide='next' style = 'width: 4%;opacity: 1;'>"+
						"<span class='glyphicon glyphicon-chevron-right' style = 'color :red'></span>"+

							"<span class='sr-only'>Next</span>"+
							"</a>");

			
				sb.append("</div>");
				sb.append("</div>");
				P++;
			}
			
		}
		
		
		for (OrderItem oi : utility.getCustomerOrders())
		{
			//System.out.println("Enter here1");
			//System.out.println(oi.getName());
			if (hm.containsKey(oi.getName()))
			{	//System.out.println(hm.get(oi.getName()));
		        myCarousel = "myCarousel"+l;
				//System.out.println("Enter here2");	
				sb.append("<h3 >"+oi.getName()+" Accessories</h3>");
				sb.append("<div class='container'>");
				/* Carousels require the use of an id (in this case id="myCarousel") for carousel controls to function properly.
				The .slide class adds a CSS transition and animation effect, which makes the items slide when showing a new item.
				Omit this class if you do not want this effect. 
				The data-ride="carousel" attribute tells Bootstrap to begin animating the carousel immediately when the page loads. 
		 
				*/
				sb.append("<div class='carousel slide' id='"+myCarousel+"' data-ride='carousel'>");
				
				/*The slides are specified in a <div> with class .carousel-inner.
				The content of each slide is defined in a <div> with class .item. This can be text or images.
				The .active class needs to be added to one of the slides. Otherwise, the carousel will not be visible.
				*/
				sb.append("<div class='carousel-inner'>");
						
				Console console1 = hm.get(oi.getName());
				//System.out.println(oi.getName());
				int k = 0; int size= hm.size();
			
				for(Map.Entry<String, String> acc:console1.getAccessories().entrySet())
				{
				
					Accessory accessory= allAccessory.get(acc.getValue());
					if (k==0 )
					{
						sb.append("<div class='item active'><div class='col-md-6' >");
					}
					else
					{
						sb.append("<div class='item'><div class='col-md-6'  >");
					}
					
					
					sb.append("<figure>");
					sb.append("<img src='images/accessories/"+accessory.getImage()+"' style='max-height: 200px !important;'>");
					sb.append("<figcaption>"+accessory.getName()+"</figcaption>");
					sb.append("<span class=price>$" + accessory.getPrice() + "</span>");
					if(showButton)
					{
						sb.append("<form action='Cart' method='post' id='frmassocart"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmassocart"+accessory.getId()+"\").submit();'>Buy Now</a>" +
						"<input type='hidden' name='name' value='"+acc.getValue()+"'>"+
						"<input type='hidden' name='type' value='accessories'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value='"+oi.getName()+"'>"+
						"</form>");
						sb.append("<form action='ProductView' method='post' id='frmassowriteReview"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmassowriteReview"+accessory.getId()+"\").submit();'>View</a> "+
							"<input type='hidden' name='name' value='"+accessory.getName()+"'>"+
							"<input type='hidden' name='condition' value='"+accessory.getCondition()+"'>"+
							"<input type='hidden' name='price' value='"+accessory.getPrice()+"'>"+
							"<input type='hidden' name='discount' value='"+accessory.getDiscount()+"'>"+
							"<input type='hidden' name='imagepath' value='images/accessories/"+accessory.getImage()+"'>"+
							"<input type='hidden' name='key' value='"+acc.getValue()+"'>"+
							"<input type='hidden' name='type' value='accessories'>"+
							"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
							"<input type='hidden' name='access' value='"+oi.getName()+"'>"+
							"</form>");
					}
					if(user!=null)
					{
						if(user.getUsertype().equals("manager"))
						{
							
							sb.append("<form action='DeleteProduct' method='post' id='frmdeletelaptop"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmdeletelaptop"+accessory.getId()+"\").submit();'>Delete</a>" +
									"<input type='hidden' name='prodID' value='"+accessory.getId()+"'>"+
									"</form>");
							sb.append("<form action='UpdateProduct' method='get' id='frmUpdatelaptop"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmUpdatelaptop"+accessory.getId()+"\").submit();'>Update</a>" +
									"<input type='hidden' name='prodID' value='"+accessory.getId()+"'>"+
									"<input type='hidden' name='prodName' value='"+accessory.getName()+"'>"+
									"<input type='hidden' name='prodPrice' value='"+accessory.getPrice()+"'>"+
									"<input type='hidden' name='prodCondition' value='"+accessory.getCondition()+"'>"+
									"<input type='hidden' name='prodDiscount' value='"+accessory.getDiscount()+"'>"+
									"</form>");
						}
					}
					sb.append("</figure>");
					sb.append("</div></div>");
					k++;
				}
			
				sb.append("</div>");
				/*		The "Left and right controls" part:
					This code adds "left" and "right" buttons that allows the user to go back and forth between the slides manually.
				The data-slide attribute accepts the keywords "prev" or "next", which alters the slide position relative to its current position.
				*/
				sb.append("<a class='left carousel-control' href='#"+myCarousel+"' data-slide='prev' style = 'width: 4%;opacity: 1;'>"+
						"<span class='glyphicon glyphicon-chevron-left' style = 'color :red'></span>"+
						"<span class='sr-only'>Previous</span>"+
						"</a>");
				sb.append("<a class='right carousel-control' href='#"+myCarousel+"' data-slide='next' style = 'width: 4%;opacity: 1;'>"+
						"<span class='glyphicon glyphicon-chevron-right' style = 'color :red'></span>"+

							"<span class='sr-only'>Next</span>"+
							"</a>");

			
				sb.append("</div>");
				sb.append("</div>");
				l++;
			
			}
			
			if (hmL.containsKey(oi.getName()))
			{	//System.out.println("Enter here4");	
		        myCarousel = "myCarouselLaptop"+l;
					
				sb.append("<h3 >"+oi.getName()+" Accessories</h3>");
				sb.append("<div class='container'>");
				
				sb.append("<div class='carousel slide' id='"+myCarousel+"' data-ride='carousel'>");
				
			
				sb.append("<div class='carousel-inner'>");
						
				Laptops laptop1 = hmL.get(oi.getName());
				//System.out.println(oi.getName());
				int k = 0; int size= hmL.size();
			
				for(Map.Entry<String, String> acc:laptop1.getAccessories().entrySet())
				{
				  
					Accessory accessory= allAccessory.get(acc.getValue());
					
					if (k==0 )
					{
						sb.append("<div class='item active'><div class='col-md-6' >");
					}
					else
					{
						sb.append("<div class='item'><div class='col-md-6'  >");
					}
					
					
					sb.append("<figure>");
					sb.append("<img src='images/accessories/"+accessory.getImage()+"' style='max-height: 200px !important;'>");
					sb.append("<figcaption>"+accessory.getName()+"</figcaption>");
					sb.append("<span class=price>$" + accessory.getPrice() + "</span>");
					if(showButton)
					{
						sb.append("<form action='Cart' method='post' id='frmassocart"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmassocart"+accessory.getId()+"\").submit();'>Buy Now</a>" +
						"<input type='hidden' name='name' value='"+acc.getValue()+"'>"+
						"<input type='hidden' name='type' value='accessories'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value='"+oi.getName()+"'>"+
						"</form>");
						sb.append("<form action='ProductView' method='post' id='frmassowriteReview"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmassowriteReview"+accessory.getId()+"\").submit();'>View</a> "+
							"<input type='hidden' name='name' value='"+accessory.getName()+"'>"+
							"<input type='hidden' name='condition' value='"+accessory.getCondition()+"'>"+
							"<input type='hidden' name='price' value='"+accessory.getPrice()+"'>"+
							"<input type='hidden' name='discount' value='"+accessory.getDiscount()+"'>"+
							"<input type='hidden' name='imagepath' value='images/accessories/"+accessory.getImage()+"'>"+
							"<input type='hidden' name='key' value='"+acc.getValue()+"'>"+
							"<input type='hidden' name='type' value='accessories'>"+
							"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
							"<input type='hidden' name='access' value='"+oi.getName()+"'>"+
							"</form>");
						sb.append("<form action='WriteReview' method='post' id='frmlaptopWRiview"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmlaptopWRiview"+accessory.getId()+"\").submit();'>Write Review</a>" +
							"<input type='hidden' name='name' value='"+accessory.getName()+"'>"+
							"<input type='hidden' name='type' value='laptops'>"+
							"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
							"<input type='hidden' name='access' value=''>"+
							"</form>");
						sb.append("<form action='ViewReview' method='post' id='frmlaptopVRiview"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmlaptopVRiview"+accessory.getId()+"\").submit();'>View Review</a>" +
							"<input type='hidden' name='name' value='"+accessory.getName()+"'>"+
							"<input type='hidden' name='type' value='laptops'>"+
							"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
							"<input type='hidden' name='access' value=''>"+
							"</form>");
					}
					if(user!=null)
					{
						if(user.getUsertype().equals("manager"))
						{
							
							sb.append("<form action='DeleteProduct' method='post' id='frmdeletelaptop"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmdeletelaptop"+accessory.getId()+"\").submit();'>Delete</a>" +
									"<input type='hidden' name='prodID' value='"+accessory.getId()+"'>"+
									"</form>");
							sb.append("<form action='UpdateProduct' method='get' id='frmUpdatelaptop"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmUpdatelaptop"+accessory.getId()+"\").submit();'>Update</a>" +
									"<input type='hidden' name='prodID' value='"+accessory.getId()+"'>"+
									"<input type='hidden' name='prodName' value='"+accessory.getName()+"'>"+
									"<input type='hidden' name='prodPrice' value='"+accessory.getPrice()+"'>"+
									"<input type='hidden' name='prodCondition' value='"+accessory.getCondition()+"'>"+
									"<input type='hidden' name='prodDiscount' value='"+accessory.getDiscount()+"'>"+
									"</form>");
						}
					}
					sb.append("</figure>");
					sb.append("</div></div>");
					k++;
				}
			
				sb.append("</div>");

				sb.append("<a class='left carousel-control' href='#"+myCarousel+"' data-slide='prev' style = 'width: 4%;opacity: 1;'>"+
						"<span class='glyphicon glyphicon-chevron-left' style = 'color :red'></span>"+
						"<span class='sr-only'>Previous</span>"+
						"</a>");
				sb.append("<a class='right carousel-control' href='#"+myCarousel+"' data-slide='next' style = 'width: 4%;opacity: 1;'>"+
						"<span class='glyphicon glyphicon-chevron-right' style = 'color :red'></span>"+

							"<span class='sr-only'>Next</span>"+
							"</a>");

			
				sb.append("</div>");
				sb.append("</div>");
				l++;
			}
			
			if (hmP.containsKey(oi.getName()))
			{	//System.out.println("Enter here4");	
		        myCarousel = "myCarouselPhones"+l;
					
				sb.append("<h3 >"+oi.getName()+" Accessories</h3>");
				sb.append("<div class='container'>");
				
				sb.append("<div class='carousel slide' id='"+myCarousel+"' data-ride='carousel'>");
				
			
				sb.append("<div class='carousel-inner'>");
						
				Phones phones1 = hmP.get(oi.getName());
				//System.out.println(oi.getName());
				int k = 0; int size= hmP.size();
			
				for(Map.Entry<String, String> acc:phones1.getAccessories().entrySet())
				{
				
					Accessory accessory= allAccessory.get(acc.getValue());
					if (k==0 )
					{
						sb.append("<div class='item active'><div class='col-md-6' >");
					}
					else
					{
						sb.append("<div class='item'><div class='col-md-6'  >");
					}
					
					
					sb.append("<figure>");
					sb.append("<img src='images/accessories/"+accessory.getImage()+"' style='max-height: 200px !important;'>");
					sb.append("<figcaption>"+accessory.getName()+"</figcaption>");
					sb.append("<span class=price>$" + accessory.getPrice() + "</span>");
					if(showButton)
					{
						sb.append("<form action='Cart' method='post' id='frmassocart"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmassocart"+accessory.getId()+"\").submit();'>Buy Now</a>" +
						"<input type='hidden' name='name' value='"+acc.getValue()+"'>"+
						"<input type='hidden' name='type' value='accessories'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value='"+oi.getName()+"'>"+
						"</form>");
						sb.append("<form action='ProductView' method='post' id='frmassowriteReview"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmassowriteReview"+accessory.getId()+"\").submit();'>View</a> "+
							"<input type='hidden' name='name' value='"+accessory.getName()+"'>"+
							"<input type='hidden' name='condition' value='"+accessory.getCondition()+"'>"+
							"<input type='hidden' name='price' value='"+accessory.getPrice()+"'>"+
							"<input type='hidden' name='discount' value='"+accessory.getDiscount()+"'>"+
							"<input type='hidden' name='imagepath' value='images/accessories/"+accessory.getImage()+"'>"+
							"<input type='hidden' name='key' value='"+acc.getValue()+"'>"+
							"<input type='hidden' name='type' value='accessories'>"+
							"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
							"<input type='hidden' name='access' value='"+oi.getName()+"'>"+
							"</form>");
						sb.append("<form action='WriteReview' method='post' id='frmphonesWRiview"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmphonesWRiview"+accessory.getId()+"\").submit();'>Write Review</a>" +
							"<input type='hidden' name='name' value='"+accessory.getName()+"'>"+
							"<input type='hidden' name='type' value='phones'>"+
							"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
							"<input type='hidden' name='access' value=''>"+
							"</form>");
						sb.append("<form action='ViewReview' method='post' id='frmphonesVRiview"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmphonesVRiview"+accessory.getId()+"\").submit();'>View Review</a>" +
							"<input type='hidden' name='name' value='"+accessory.getName()+"'>"+
							"<input type='hidden' name='type' value='phones'>"+
							"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
							"<input type='hidden' name='access' value=''>"+
							"</form>");
					}
					if(user!=null)
					{
						if(user.getUsertype().equals("manager"))
						{
							sb.append("<form action='DeleteProduct' method='post' id='frmdeletePhone"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmdeletePhone"+accessory.getId()+"\").submit();'>Delete</a>" +
									"<input type='hidden' name='prodID' value='"+accessory.getId()+"'>"+
									"</form>");
							sb.append("<form action='UpdateProduct' method='get' id='frmUpdateProductPhone"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmUpdateProductPhone"+accessory.getId()+"\").submit();'>Update</a>" +
									"<input type='hidden' name='prodID' value='"+accessory.getId()+"'>"+
									"<input type='hidden' name='prodName' value='"+accessory.getName()+"'>"+
									"<input type='hidden' name='prodPrice' value='"+accessory.getPrice()+"'>"+
									"<input type='hidden' name='prodCondition' value='"+accessory.getCondition()+"'>"+
									"<input type='hidden' name='prodDiscount' value='"+accessory.getDiscount()+"'>"+
									"</form>");
						}
					}
					sb.append("</figure>");
					sb.append("</div></div>");
					k++;
				}
			
				sb.append("</div>");

				sb.append("<a class='left carousel-control' href='#"+myCarousel+"' data-slide='prev' style = 'width: 4%;opacity: 1;'>"+
						"<span class='glyphicon glyphicon-chevron-left' style = 'color :red'></span>"+
						"<span class='sr-only'>Previous</span>"+
						"</a>");
				sb.append("<a class='right carousel-control' href='#"+myCarousel+"' data-slide='next' style = 'width: 4%;opacity: 1;'>"+
						"<span class='glyphicon glyphicon-chevron-right' style = 'color :red'></span>"+

							"<span class='sr-only'>Next</span>"+
							"</a>");

			
				sb.append("</div>");
				sb.append("</div>");
				l++;
			}
			
			if (hmW.containsKey(oi.getName()))
			{	//System.out.println("Enter here4");	
		        myCarousel = "myCarouselwearable"+l;
					
				sb.append("<h3 >"+oi.getName()+" Accessories</h3>");
				sb.append("<div class='container'>");
				
				sb.append("<div class='carousel slide' id='"+myCarousel+"' data-ride='carousel'>");
				
			
				sb.append("<div class='carousel-inner'>");
						
				Wearable wearable1 = hmW.get(oi.getName());
				//System.out.println(oi.getName());
				int k = 0; int size= hmW.size();
			
				for(Map.Entry<String, String> acc:wearable1.getAccessories().entrySet())
				{
				
					Accessory accessory= allAccessory.get(acc.getValue());
					if (k==0 )
					{
						sb.append("<div class='item active'><div class='col-md-6' >");
					}
					else
					{
						sb.append("<div class='item'><div class='col-md-6'  >");
					}
					
					
					sb.append("<figure>");
					sb.append("<img src='images/accessories/"+accessory.getImage()+"' style='max-height: 200px !important;'>");
					sb.append("<figcaption>"+accessory.getName()+"</figcaption>");
					sb.append("<span class=price>$" + accessory.getPrice() + "</span>");
					if(showButton)
					{
						sb.append("<form action='Cart' method='post' id='frmassocart"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmassocart"+accessory.getId()+"\").submit();'>Buy Now</a>" +
						"<input type='hidden' name='name' value='"+acc.getValue()+"'>"+
						"<input type='hidden' name='type' value='accessories'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value='"+oi.getName()+"'>"+
						"</form>");
						sb.append("<form action='ProductView' method='post' id='frmassowriteReview"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmassowriteReview"+accessory.getId()+"\").submit();'>View</a> "+
							"<input type='hidden' name='name' value='"+accessory.getName()+"'>"+
							"<input type='hidden' name='condition' value='"+accessory.getCondition()+"'>"+
							"<input type='hidden' name='price' value='"+accessory.getPrice()+"'>"+
							"<input type='hidden' name='discount' value='"+accessory.getDiscount()+"'>"+
							"<input type='hidden' name='imagepath' value='images/accessories/"+accessory.getImage()+"'>"+
							"<input type='hidden' name='key' value='"+acc.getValue()+"'>"+
							"<input type='hidden' name='type' value='accessories'>"+
							"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
							"<input type='hidden' name='access' value='"+oi.getName()+"'>"+
							"</form>");
						sb.append("<form action='WriteReview' method='post' id='frmwearableWRiview"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmwearableWRiview"+accessory.getId()+"\").submit();'>Write Review</a>" +
							"<input type='hidden' name='name' value='"+accessory.getName()+"'>"+
							"<input type='hidden' name='type' value='wearables'>"+
							"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
							"<input type='hidden' name='access' value=''>"+
							"</form>");
						sb.append("<form action='ViewReview' method='post' id='frmwearableVRiview"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmwearableVRiview"+accessory.getId()+"\").submit();'>View Review</a>" +
							"<input type='hidden' name='name' value='"+accessory.getName()+"'>"+
							"<input type='hidden' name='type' value='wearables'>"+
							"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
							"<input type='hidden' name='access' value=''>"+
							"</form>");
					}
					if(user!=null)
					{
						if(user.getUsertype().equals("manager"))
						{
							sb.append("<form action='DeleteProduct' method='post' id='frmdeleteWEList"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmdeleteWEList"+accessory.getId()+"\").submit();'>Delete</a>" +
									"<input type='hidden' name='prodID' value='"+accessory.getId()+"'>"+
									"</form>");
							sb.append("<form action='UpdateProduct' method='get' id='frmUpdateProductWEList"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmUpdateProductWEList"+accessory.getId()+"\").submit();'>Update</a>" +
									"<input type='hidden' name='prodID' value='"+accessory.getId()+"'>"+
									"<input type='hidden' name='prodName' value='"+accessory.getName()+"'>"+
									"<input type='hidden' name='prodPrice' value='"+accessory.getPrice()+"'>"+
									"<input type='hidden' name='prodCondition' value='"+accessory.getCondition()+"'>"+
									"<input type='hidden' name='prodDiscount' value='"+accessory.getDiscount()+"'>"+
									"</form>");
						}
					}
					sb.append("</figure>");
					sb.append("</div></div>");
					k++;
				}
			
				sb.append("</div>");

				sb.append("<a class='left carousel-control' href='#"+myCarousel+"' data-slide='prev' style = 'width: 4%;opacity: 1;'>"+
						"<span class='glyphicon glyphicon-chevron-left' style = 'color :red'></span>"+
						"<span class='sr-only'>Previous</span>"+
						"</a>");
				sb.append("<a class='right carousel-control' href='#"+myCarousel+"' data-slide='next' style = 'width: 4%;opacity: 1;'>"+
						"<span class='glyphicon glyphicon-chevron-right' style = 'color :red'></span>"+

							"<span class='sr-only'>Next</span>"+
							"</a>");

			
				sb.append("</div>");
				sb.append("</div>");
				l++;
			}
			
			if (hmSA.containsKey(oi.getName()))
			{	//System.out.println("Enter here4");	
		        myCarousel = "myCarouselwearable"+l;
					
				sb.append("<h3 >"+oi.getName()+" Accessories</h3>");
				sb.append("<div class='container'>");
				
				sb.append("<div class='carousel slide' id='"+myCarousel+"' data-ride='carousel'>");
				
			
				sb.append("<div class='carousel-inner'>");
						
				SmartAssistance smartAssistance1 = hmSA.get(oi.getName());
				//System.out.println(oi.getName());
				int k = 0; int size= hmSA.size();
			
				for(Map.Entry<String, String> acc:smartAssistance1.getAccessories().entrySet())
				{
				
					Accessory accessory= allAccessory.get(acc.getValue());
					if (k==0 )
					{
						sb.append("<div class='item active'><div class='col-md-6' >");
					}
					else
					{
						sb.append("<div class='item'><div class='col-md-6'  >");
					}
					
					
					sb.append("<figure>");
					sb.append("<img src='images/accessories/"+accessory.getImage()+"' style='max-height: 200px !important;'>");
					sb.append("<figcaption>"+accessory.getName()+"</figcaption>");
					sb.append("<span class=price>$" + accessory.getPrice() + "</span>");
					if(showButton)
					{
						sb.append("<form action='Cart' method='post' id='frmassocart"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmassocart"+accessory.getId()+"\").submit();'>Buy Now</a>" +
						"<input type='hidden' name='name' value='"+acc.getValue()+"'>"+
						"<input type='hidden' name='type' value='accessories'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value='"+oi.getName()+"'>"+
						"</form>");
						sb.append("<form action='ProductView' method='post' id='frmassowriteReview"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmassowriteReview"+accessory.getId()+"\").submit();'>View</a> "+
							"<input type='hidden' name='name' value='"+accessory.getName()+"'>"+
							"<input type='hidden' name='condition' value='"+accessory.getCondition()+"'>"+
							"<input type='hidden' name='price' value='"+accessory.getPrice()+"'>"+
							"<input type='hidden' name='discount' value='"+accessory.getDiscount()+"'>"+
							"<input type='hidden' name='imagepath' value='images/accessories/"+accessory.getImage()+"'>"+
							"<input type='hidden' name='key' value='"+acc.getValue()+"'>"+
							"<input type='hidden' name='type' value='accessories'>"+
							"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
							"<input type='hidden' name='access' value='"+oi.getName()+"'>"+
							"</form>");
						sb.append("<form action='WriteReview' method='post' id='frmsmartassistanceWRiview"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmsmartassistanceWRiview"+accessory.getId()+"\").submit();'>Write Review</a>" +
							"<input type='hidden' name='name' value='"+accessory.getName()+"'>"+
							"<input type='hidden' name='type' value='smartassistances'>"+
							"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
							"<input type='hidden' name='access' value=''>"+
							"</form>");
						sb.append("<form action='ViewReview' method='post' id='frmsmartassistanceVRiview"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmsmartassistanceVRiview"+accessory.getId()+"\").submit();'>View Review</a>" +
							"<input type='hidden' name='name' value='"+accessory.getName()+"'>"+
							"<input type='hidden' name='type' value='smartassistances'>"+
							"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
							"<input type='hidden' name='access' value=''>"+
							"</form>");
					}
					if(user!=null)
					{
						if(user.getUsertype().equals("manager"))
						{
							sb.append("<form action='DeleteProduct' method='post' id='frmdeleteVAList"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmdeleteVAList"+accessory.getId()+"\").submit();'>Delete</a>" +
									"<input type='hidden' name='prodID' value='"+accessory.getId()+"'>"+
									"</form>");
							sb.append("<form action='UpdateProduct' method='get' id='frmUpdateProductVAList"+accessory.getId()+"'> <a class='button' onclick='document.getElementById(\"frmUpdateProductVAList"+accessory.getId()+"\").submit();'>Update</a>" +
									"<input type='hidden' name='prodID' value='"+accessory.getId()+"'>"+
									"<input type='hidden' name='prodName' value='"+accessory.getName()+"'>"+
									"<input type='hidden' name='prodPrice' value='"+accessory.getPrice()+"'>"+
									"<input type='hidden' name='prodCondition' value='"+accessory.getCondition()+"'>"+
									"<input type='hidden' name='prodDiscount' value='"+accessory.getDiscount()+"'>"+
									"</form>");
						}
					}
					sb.append("</figure>");
					sb.append("</div></div>");
					k++;
				}
			
				sb.append("</div>");

				sb.append("<a class='left carousel-control' href='#"+myCarousel+"' data-slide='prev' style = 'width: 4%;opacity: 1;'>"+
						"<span class='glyphicon glyphicon-chevron-left' style = 'color :red'></span>"+
						"<span class='sr-only'>Previous</span>"+
						"</a>");
				sb.append("<a class='right carousel-control' href='#"+myCarousel+"' data-slide='next' style = 'width: 4%;opacity: 1;'>"+
						"<span class='glyphicon glyphicon-chevron-right' style = 'color :red'></span>"+

							"<span class='sr-only'>Next</span>"+
							"</a>");

			
				sb.append("</div>");
				sb.append("</div>");
				l++;
			}
			
		}
	    return sb.toString();
		}
		catch(Exception ex)
		{
			ex.printStackTrace(); 
            // Prints what exception has been thrown 
            System.out.println(ex); 
			System.out.println(ex.toString()); 
			return  "";
		}
	  }
	 
	}
	