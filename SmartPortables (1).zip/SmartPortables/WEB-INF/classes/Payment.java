import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.Random;
import java.util.HashMap;
import java.util.Map;

@WebServlet("/Payment")

public class Payment extends HttpServlet {
	
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		String msg = "good";
		String Customername= "";
		HttpSession session = request.getSession(true);

		Utilities utility = new Utilities(request, pw);
		if(!utility.isLoggedin())
		{
			session = request.getSession(true);				
			session.setAttribute("login_msg", "Please Login to Pay");
			response.sendRedirect("Login");
			return;
		}
		// get the payment details like credit card no address processed from cart servlet	

		String userAddress=request.getParameter("userAddress");
		String creditCardNo=request.getParameter("creditCardNo");
		if(session.getAttribute("usertype").equals("retailer")){
			Customername =request.getParameter("customername");
			try{
				HashMap<String,User> hm=new HashMap<String,User>();
				hm=MySqlDataStoreUtilities.selectUser();
				if(hm.containsKey(Customername)){
					if(hm.get(Customername).getUsertype().equals("customer")){
						msg ="good";
					}else {msg ="bad";}
						
				}else {msg ="bad";}
				
			}catch(Exception e)
			{
				
			}
		}

		String message=MySqlDataStoreUtilities.getConnection();
		
		
		if(message.equals("Successfull"))
		{
				
			if (msg.equals("good"))
			{
				
				if(!userAddress.isEmpty() && !creditCardNo.isEmpty() )
				{
					int orderId=utility.getOrderPaymentSize()+1;
					//iterate through each order

					for (OrderItem oi : utility.getCustomerOrders())
					{
						utility.storePayment(orderId,oi.getName(),oi.getPrice(),userAddress,creditCardNo,Customername);
					}
					OrdersHashMap.orders.remove(utility.username());
					//remove the order details from cart after processing
					
					OrdersHashMap.orders.remove(utility.username());	
					utility.printHtml("Header.html");
					utility.printHtml("NAV.html");
					pw.print("<section id='content'>  <article>");
					pw.print("<h3 >Order</h3>");
					pw.print("<fieldset><legend>You order has been placed successfully.</legend> ");

					pw.print("<h5 style='color:green'>Your Order No is "+(orderId)+"</h5>");
					pw.print(" </fieldset> </article> </section>");
					utility.printHtml("LeftNavigationBar.html");			
					utility.printHtml("Footer.html");	
				}
				else
				{
					utility.printHtml("Header.html");
					utility.printHtml("NAV.html");
					pw.print("<section id='content'>  <article>");
					pw.print("<h3 >Order</h3>");
					pw.print("<fieldset><legend>Please verify your order.</legend> ");

					pw.print("<h5 style='color:red'>Please enter valid address and creditcard number</h5>");
					pw.print(" </fieldset> </article> </section>");
					utility.printHtml("LeftNavigationBar.html");			
					utility.printHtml("Footer.html");	
					
				}
			}
			else 
			{
				utility.printHtml("Header.html");
				utility.printHtml("NAV.html");
				pw.print("<section id='content'>  <article>");
				pw.print("<h3 >Order</h3>");
				pw.print("<fieldset><legend>Something went wrong.</legend> ");
				pw.print("<h5 style='color:red'>Customer does not exits</h5>");
				pw.print(" </fieldset> </article> </section>");
				utility.printHtml("LeftNavigationBar.html");			
				utility.printHtml("Footer.html");	
			}		
		}
		else
		{
			utility.printHtml("Header.html");
			utility.printHtml("NAV.html");
			pw.print("<section id='content'>  <article>");
			pw.print("<h3 >Order</h3>");
            pw.print("<fieldset><legend>Please verify your order.</legend> ");

			pw.print("<h5 style='color:red'>My Sql server is not up and running</h5>");
			pw.print(" </fieldset> </article> </section>");
			utility.printHtml("LeftNavigationBar.html");			
			utility.printHtml("Footer.html");	
		}
		
		
		
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		Utilities utility = new Utilities(request, pw);
	}
}
