import com.google.gson.Gson;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.mongodb.MongoClient;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.DBCursor;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
import com.mongodb.AggregationOutput;


@WebServlet("/ProductOnSaleReport")
public class ProductOnSaleReport extends HttpServlet {

   protected void doGet(HttpServletRequest request,
		HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		Utilities utility = new Utilities(request, pw);
		if(!utility.isLoggedin())
		{
		    request.getRequestDispatcher("/Login").forward(request, response);
			return;
		}
		ArrayList<Bestrating> hm = MongoDBDataStoreUtilities.productOnSale();
		

		

		String name = "Invntory Detail";
		

		
		utility.printHtml("Header.html");
		utility.printHtml("NAV.html");
		pw.print("<section id='content'><article>");
		pw.print("<h3 >Invntory Detail</h3>");
		
        pw.print("<fieldset><legend>Product On Sale</legend><table> ");
		pw.print("<tr><th>Product Name</th><th>Price</th></tr>");
		Iterator itr2 = hm.iterator();
        while(itr2.hasNext()) {
			Bestrating bestrating = (Bestrating)itr2.next();
			pw.print("<tr>");
			pw.print("<td>");
			pw.print(bestrating.getProductname());
			pw.print("</td>");
			pw.print("<td>");
			pw.print(bestrating.getRating());
			pw.print("</td>");
			pw.print("</tr>");
        }
		pw.print("</table></fieldset><br />");
	
		pw.print("</article> </section>");
        utility.printHtml("LeftNavigationBar.html");			
		utility.printHtml("Footer.html");
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	}

}
