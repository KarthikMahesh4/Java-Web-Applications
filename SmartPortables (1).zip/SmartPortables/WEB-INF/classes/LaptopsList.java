import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LaptopsList")

public class LaptopsList extends HttpServlet {

	/* Laptopss Page Displays all the Laptopss and their Information in Laptops Speed */

	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		/* Checks the Laptopss type whether it is electronicArts or activision or takeTwoInteractive */
				
		String name = null;
		String CategoryName = request.getParameter("maker");
		HashMap<String, Laptops> hm = new HashMap<String, Laptops>();
		
		HashMap<String,Laptops> allLaptops = new HashMap<String,Laptops> ();
		try{
		     allLaptops = MySqlDataStoreUtilities.getLaptops();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		if(CategoryName==null)
		{
			hm.putAll(allLaptops);
			name = "";
		}
		else
		{
		  if(CategoryName.equals("apple"))
		  {
			for(Map.Entry<String,Laptops> entry : allLaptops.entrySet())
				{
				if(entry.getValue().getRetailer().equals("Apple"))
				 {
					 hm.put(entry.getValue().getId(),entry.getValue());
				 }
				}
			name = "Apple";
		  }
		  else if(CategoryName.equals("hp"))
		  {
			for(Map.Entry<String,Laptops> entry : allLaptops.entrySet())
				{
				if(entry.getValue().getRetailer().equals("HP"))
				 {
					 hm.put(entry.getValue().getId(),entry.getValue());
				 }
				}	
			name = "HP";
		  }
		  else if(CategoryName.equals("samsung"))
		  {
			for(Map.Entry<String,Laptops> entry : allLaptops.entrySet())
				{
				if(entry.getValue().getRetailer().equals("Samsung"))
				 {
					 hm.put(entry.getValue().getId(),entry.getValue());
				 }
				}
			name = "Samsung";
		  }
		  else if(CategoryName.equals("lenovo"))
		  {
			for(Map.Entry<String,Laptops> entry : allLaptops.entrySet())
				{
				if(entry.getValue().getRetailer().equals("Lenovo"))
				 {
					 hm.put(entry.getValue().getId(),entry.getValue());
				 }
				}
			name = "Lenovo";
		  }
		  else if(CategoryName.equals("dell"))
		  {
			for(Map.Entry<String,Laptops> entry : allLaptops.entrySet())
				{
				if(entry.getValue().getRetailer().equals("Dell"))
				 {
					 hm.put(entry.getValue().getId(),entry.getValue());
				 }
				}
			name = "Dell";
		  }
		}

		/* Header is Printed.

		All the Laptops and Laptops information are dispalyed in the Content Section

		and then Left Navigation Bar,Footer is Printed*/
		
		Utilities utility = new Utilities(request,pw);
		User user=utility.getUser();
		boolean showButton=true; 
		if(user!=null)
		{
			if(user.getUsertype().equals("retailer") || user.getUsertype().equals("manager"))
			{
				showButton=false;
			}
		}
		utility.printHtml("Header.html");
		utility.printHtml("NAV.html");
		pw.print("<section id='content'>  <article>");
		pw.print(" <h3>"+name+" Laptops</h3>");
		pw.print("<div id='wrap'><div id='columns' class='columns_3'>");
		int i = 1; int size= hm.size();
		for(Map.Entry<String, Laptops> entry : hm.entrySet()){
			Laptops laptops = entry.getValue();
		    pw.print("<figure>");
			pw.print("<img src='images/laptops/"+laptops.getImage()+"' style='max-height: 200px !important;'>");
			pw.print("<figcaption>"+laptops.getName()+"</figcaption>");
			pw.print("<span class=price>$" + laptops.getPrice() + "</span>");
			if(showButton)
			{
				pw.print("<form action='Cart' method='post' id='frmlaptopcart"+laptops.getId()+"'> <a class='button' onclick='document.getElementById(\"frmlaptopcart"+laptops.getId()+"\").submit();'>Buy Now</a>" +
						"<input type='hidden' name='name' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='laptops'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
				pw.print("<form action='ProductView' method='post' id='frmlaptopwriteReview"+laptops.getId()+"'> <a class='button' onclick='document.getElementById(\"frmlaptopwriteReview"+laptops.getId()+"\").submit();'>View</a> "+
						"<input type='hidden' name='name' value='"+laptops.getName()+"'>"+
						"<input type='hidden' name='condition' value='"+laptops.getCondition()+"'>"+
						"<input type='hidden' name='price' value='"+laptops.getPrice()+"'>"+
						"<input type='hidden' name='discount' value='"+laptops.getDiscount()+"'>"+
						"<input type='hidden' name='imagepath' value='images/laptops/"+laptops.getImage()+"'>"+
						"<input type='hidden' name='key' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='laptops'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
				pw.print("<form action='WriteReview' method='post' id='frmlaptopWRiview"+laptops.getId()+"'> <a class='button' onclick='document.getElementById(\"frmlaptopWRiview"+laptops.getId()+"\").submit();'>Write Review</a>" +
						"<input type='hidden' name='name' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='laptops'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
			   	pw.print("<form action='ViewReview' method='post' id='frmlaptopVRiview"+laptops.getId()+"'> <a class='button' onclick='document.getElementById(\"frmlaptopVRiview"+laptops.getId()+"\").submit();'>View Review</a>" +
						"<input type='hidden' name='name' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='laptops'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value=''>"+
						"</form>");
			}
			if(user!=null)
			{
				if(user.getUsertype().equals("manager"))
				{
					
					pw.print("<form action='DeleteProduct' method='post' id='frmdeletelaptop"+laptops.getId()+"'> <a class='button' onclick='document.getElementById(\"frmdeletelaptop"+laptops.getId()+"\").submit();'>Delete</a>" +
							"<input type='hidden' name='prodID' value='"+laptops.getId()+"'>"+
							"</form>");
					pw.print("<form action='UpdateProduct' method='get' id='frmUpdatelaptop"+laptops.getId()+"'> <a class='button' onclick='document.getElementById(\"frmUpdatelaptop"+laptops.getId()+"\").submit();'>Update</a>" +
							"<input type='hidden' name='prodID' value='"+laptops.getId()+"'>"+
							"<input type='hidden' name='prodName' value='"+laptops.getName()+"'>"+
							"<input type='hidden' name='prodPrice' value='"+laptops.getPrice()+"'>"+
							"<input type='hidden' name='prodCondition' value='"+laptops.getCondition()+"'>"+
							"<input type='hidden' name='prodDiscount' value='"+laptops.getDiscount()+"'>"+
							"</form>");
				}
			}
			pw.print("</figure>");
			
			i++;
		}		
		pw.print("</div></div></article> </section>");	
        utility.printHtml("LeftNavigationBar.html");		
		utility.printHtml("Footer.html");
		
	}

}
