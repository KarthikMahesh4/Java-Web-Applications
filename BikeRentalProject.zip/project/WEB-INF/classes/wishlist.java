import java.util.HashMap;

public class wishlist 
{
HashMap<String, Double> wishlistitems;

    public wishlist()
    {
     
     wishlistitems = new HashMap<String, Double>();
      
    }
    
    public HashMap getwishlistitems()
    {
        return wishlistitems;
    }
    
    public void addtoWishlist(String itemid, double price)
    {
        wishlistitems.put(itemid, price);
    }

    public void deletefromWishlist(String itemid)
    {
        wishlistitems.remove(itemid);
    }

}

