import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import com.mongodb.MongoClient;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.AggregationOutput;
import java.nio.file.Files;
import static javafx.scene.Cursor.cursor;



public class dataanalyticservlet extends HttpServlet 
{
	MongoClient mongo;
	public void init() throws ServletException
	{
		  mongo = new MongoClient("localhost", 27017);
  }
     
	public String readFile(String filename) 
				{
		   			File f = new File(filename);
		   			try 
		   			{
			         byte[] bytes = Files.readAllBytes(f.toPath());
				       return new String(bytes, "UTF-8");
	        	} 
	        	catch (Exception e) 
	        	{
	        	}
	        	return null;
	    		}

	public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
	{
				HttpSession session = request.getSession();
        String msg;
        cart shoppingCart= (cart) session.getAttribute("cart");
        String username= (String) session.getAttribute("sessionusername");
        PrintWriter pw = response.getWriter();
                if(username!=null)
                {                   
                    pw.println(readFile("C:\\apache-tomcat-7.0.34\\webapps\\project\\header.html").replaceAll("guest", username));
                    msg="successfully login";
                } 
                
                else 
                {
                    pw.println(readFile(":\\Program Files\\apache-tomcat-7.0.34\\webapps\\project\\header.html"));
                    
                }

                pw.println(readFile("C:\\apache-tomcat-7.0.34\\webapps\\project\\navigation.html"));
                pw.println(" <div class='content' id='about'><h2>Data Analytic</h2>");
                String ponsale  = request.getParameter("productonsale");
                String userid  = request.getParameter("puserID");
                String puserage  = request.getParameter("puserAge");
                String pusergender  = request.getParameter("puserGender");
                String puseroccupation = request.getParameter("puserOccupation");
                String pauthorname = request.getParameter("pmanuName");
                String prebate  = request.getParameter("manuRebate");
                String pdate = request.getParameter("previewDate");
                String productname = request.getParameter("productName");
                String productprice  = request.getParameter("pprice");
                String pricecmpr = request.getParameter("ppricecompare");
                String pretailerzip = request.getParameter("pzipcode");
                String pretailercity = request.getParameter("pcity");
                String prating = request.getParameter("previewrating");
                String pcategory  = request.getParameter("productCategory");
                String pretailer  = request.getParameter("pretailername");
                String pretailerstate = request.getParameter("pretailerstate");
                
        		
                 DB db= mongo.getDB("CustomerReview1");
                DBCollection myreview = db.getCollection("MyReview");
                myreview= db.getCollection("MyReview");
                
                //First Query
                
                pw.println("<h4 align='center' STYLE='font-weight: bold; color: red;' >All product with maximum rating</h4>");
               
                DBObject sort = new BasicDBObject();
                DBObject limit = new BasicDBObject();
                DBObject orderby=new BasicDBObject();
                limit=new BasicDBObject("$limit",5);
                orderby=new BasicDBObject("$sort",sort);
                sort.put("reviewRating",-1);

                AggregationOutput aggregate = myreview.aggregate(orderby,limit);
                int j=0;
                for (DBObject result : aggregate.results()) 
                {
                    BasicDBObject bobj= (BasicDBObject) result;
                    j++;
                    pw.println("<h5 align='center' STYLE='font-weight: bold; color: black;' >Review =  "+j+"</h5>");
                    String pname=bobj.getString("productName");
                    String reviewrate= bobj.getString("reviewRating");
                    pw.println("Product Name="+pname+"<br>Product rating="+reviewrate+"<br><hr>");
                }
                //Second Query
                pw.println("<h4 align='center' STYLE='font-weight: bold; color: red;' >Product with zipcode high rating</h4>");
                DBObject groupFields=new BasicDBObject();
                DBObject group=new BasicDBObject();
                DBObject projectFields=new BasicDBObject();
                DBObject project=new BasicDBObject();
                orderby=new BasicDBObject("$sort",sort);
                limit=new BasicDBObject("$limit",5);
                sort.put("reviewRating",-1);

                  groupFields= new BasicDBObject("_id", 0);
                  groupFields.put("count",new BasicDBObject("$sum",1));
                  groupFields.put("_id", "$retailorZip");
                  group = new BasicDBObject("$group", groupFields);
                  
                  projectFields.put("value", "$_id");
                  projectFields.put("reviewRating","$count");
                  project = new BasicDBObject("$project", projectFields);
                 
               

                  aggregate = myreview.aggregate(group,project,orderby,limit);
                  int k=0;
                  for (DBObject result : aggregate.results()) 
                  {
                      BasicDBObject bobj= (BasicDBObject) result;
                      k++;
                      pw.println("<h5 align='center' STYLE='font-weight: bold; color: black;' >Review =  "+k+"</h5>");
                      String zipcode=bobj.getString("value");
                      String reviewrate= bobj.getString("reviewRating");
                      pw.println("Product zipcode="+zipcode);
                      pw.println("<br>");
                      pw.println("Total review="+reviewrate);
                      pw.println("<br>");
                      pw.println("<hr>");
                  }

                //Third Query-3
                pw.println("<h4 align='center' STYLE='font-weight: bold; color: red;' >display 5 product with maximum reiew</h4>");
                  groupFields= new BasicDBObject("_id", 0);
                  groupFields.put("count",new BasicDBObject("$sum",1));
                  groupFields.put("_id", "$productName");
                  group = new BasicDBObject("$group", groupFields);
                  aggregate = myreview.aggregate(group,orderby,limit);
                  int m=0;
                  for (DBObject result : aggregate.results()) 
                  {
                      BasicDBObject bobj= (BasicDBObject) result;
                      m++;
                      pw.println("<h5 align='center' STYLE='font-weight: bold; color: black;' >Review =  "+m+"</h5>");
                      productname=bobj.getString("_id");
                      String reviewrate= bobj.getString("count");
                      pw.println("Product Name="+productname+"<br>");
                      pw.println("Total review="+reviewrate+"<br><hr>");
                  }

                pw.println("</div>");
                
                pw.println(readFile("C:\\apache-tomcat-7.0.34\\webapps\\project\\footer.html"));

	}
}