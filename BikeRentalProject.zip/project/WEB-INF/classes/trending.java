import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import com.mongodb.MongoClient;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.AggregationOutput;
import java.nio.file.Files;

public class trending extends HttpServlet 
{
MongoClient mongo;
public void init() throws ServletException {
        mongo = new MongoClient("localhost", 27017);
}
     
  public String readData(String filename) 
        {
            File f = new File(filename);
            try 
            {
                 byte[] bytes = Files.readAllBytes(f.toPath());
               return new String(bytes, "UTF-8");
              } 
              catch (Exception e) 
              {
              }
              return "";
          
          }

  public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
  {     
    PrintWriter pw = response.getWriter();
     String msg;
        HttpSession sessionHttp = request.getSession();
            cart shoppingCart= (cart) sessionHttp.getAttribute("cart");
                String username = (String) sessionHttp.getAttribute("sessionusername");
                if(username!=null)
                {                   
                    pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\header.html").replaceAll("guest", username));
                    msg="successfully logged-in";
                }
                else 
                {
                    pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\header.html"));
                }
                pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\navigation.html"));
                pw.println(" < <div class='content' id='about'> ");
                
                DB db= mongo.getDB("CustomerReview1");
                DBCollection MyReview = db.getCollection("MyReview");
                MyReview= db.getCollection("MyReview");
                pw.println("<h4 align='center' STYLE='font-weight: bold; color: red;' >Top 5 most liked products by customers</h4>");
               
                DBObject sort = new BasicDBObject();
                DBObject limit = new BasicDBObject();
                DBObject orderby=new BasicDBObject();

                orderby=new BasicDBObject("$sort",sort);
                limit=new BasicDBObject("$limit",5);
               
                sort.put("reviewRating",-1);

                AggregationOutput aggregate = MyReview.aggregate(orderby,limit);
                int k=0;
                for (DBObject result : aggregate.results()) 
                {
                    BasicDBObject bobj= (BasicDBObject) result;
                    k++;
                    pw.println("<h5 align='center' STYLE='font-weight: bold; color: black;' >Review =  "+k+"</h5>");
                    String pname=bobj.getString("productName");
                    String reviewrate= bobj.getString("reviewRating");
                    pw.println("Product Name="+pname+"<br>");
                    pw.println("Product rating="+reviewrate+"<br<hr>");
                }

                pw.println("<h4 align='center' STYLE='font-weight: bold; color: red;' >Top 5 Product based on zipcode</h4>");
            
               
                DBObject groupFields=new BasicDBObject();
                DBObject group=new BasicDBObject();
                DBObject projectFields=new BasicDBObject();
                DBObject project=new BasicDBObject();
                orderby=new BasicDBObject("$sort",sort);
                limit=new BasicDBObject("$limit",5);
                sort.put("reviewRating",-1);
                  groupFields= new BasicDBObject("_id", 0);
                  groupFields.put("count",new BasicDBObject("$sum",1));
                  groupFields.put("_id", "$retailorZip");
                  group = new BasicDBObject("$group", groupFields);
                  
                  projectFields.put("value", "$_id");
                  projectFields.put("reviewRating","$count");
                  project = new BasicDBObject("$project", projectFields);
                 
               

                  aggregate = MyReview.aggregate(group,project,orderby,limit);
                  int h=0;
                  for (DBObject result : aggregate.results()) 
                  {
                      BasicDBObject bobj= (BasicDBObject) result;
                      h++;
                      pw.println("<h5 align='center' STYLE='font-weight: bold; color: black;' >Review =  "+h+"</h5>");
                      String zipcode=bobj.getString("value");
                      String reviewrate= bobj.getString("reviewRating");
                      pw.println("Product zipcode="+zipcode);
                      pw.println("<br>");
                      pw.println("Total review="+reviewrate);
                      pw.println("<br><hr>");
                  }

                  pw.println("<h4 align='center' STYLE='font-weight: bold; color: red;' >Top Five most sold Product</h4>");
                  groupFields= new BasicDBObject("_id", 0);
                  groupFields.put("count",new BasicDBObject("$sum",1));
                  groupFields.put("_id", "$productName");
                  group = new BasicDBObject("$group", groupFields);
               

                  aggregate = MyReview.aggregate(group,orderby,limit);
                  int i=0;
                  for (DBObject result : aggregate.results()) 
                  {
                      BasicDBObject bobj= (BasicDBObject) result;
                      i++;
                      pw.println("<h5 align='center' STYLE='font-weight: bold; color: black;' >Review =  "+i+"</h5>");
                      String productname=bobj.getString("_id");
                      String reviewrate= bobj.getString("count");
                      pw.println("Product Name="+productname);
                      pw.println("<br>");
                      pw.println("Total review="+reviewrate);
                      pw.println("<br><hr>");
                  }
                pw.println("</div>");
                
                pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\footer.html"));

 }
}