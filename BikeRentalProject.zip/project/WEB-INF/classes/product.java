//package ecom;

import java.util.HashMap;

public class product implements java.io.Serializable
{
    String id;
    String image;
    String name;
    String producttype;
    String pickup;
    String descr;
    double rentprice;
    double lendprice;
    int  quantity;
	int discount;
    
   // HashMap<String,Accessory> accessories = new HashMap<String,Accessory>();
    
    public product(String id,String image,String name,String producttype,String pickup,String descr,double rentprice,double lendprice,
    int  quantity,	int discount)
    {	
        this.id=id;
        this.image=image;
        this.name=name;
        this.producttype= producttype;
        this.pickup = pickup;
        this.descr = descr;
        this.rentprice=rentprice;
        this.lendprice=lendprice; 
        this.quantity=quantity;
        this.discount=discount;
    }
    
    public product()
    {
        
    }
    
    public String getId() 
    {
        return id;
    }
    public void setId(String id) 
    {
        this.id = id;
    }

    public String getProducttype() 
    {
        return producttype;
    }
    public void setProducttype(String producttype) 
    {
        this.producttype = producttype;
    }

    
    public String getImage() 
    {
        return image;
    }
    public void setImage(String image) 
    {
        this.image = image;
    }

    public String getName() 
    {
        return name;
    }
    public void setName(String name) 
    {
        this.name = name;
    }

     public String getPickup() 
    {
        return pickup;
    }
    public void setPickup(String pickup) 
    {
        
        this.pickup = pickup;
    }
    public String getDescr() 
    {
        return descr;
    }
    public void setDescr(String descr) 
    {
        
        this.descr= descr;
    }

    public double getLendPrice() 
    {
        return lendprice;
    }
    public void setLendPrice(double lendprice) 
    {
        
        this.lendprice = lendprice;
    }
    
     public double getRentPrice() 
    {
        return rentprice;
    }
    public void setRentPrice(double rentprice) 
    {
        this.rentprice = rentprice;
    }
     
    public Integer getDiscount() 
    {
        return discount;
    }
    public void setDiscount(Integer discount) 
    {
        this.discount = discount;
    }
    public Integer getQuantity() 
    {
        return quantity;
    }
    public void setQuantity(Integer quantity) 
    {
        this.quantity = quantity;
    }

     public String toString() 
     {
        

        return "Product:: ID="+this.id+"         Name="+this.name+"        Image="+ this.image + "       Producttype = "+this.producttype+"    Pickup = "+this.pickup+"   Descr = "+this.descr+"  RentPrice = "+ this.rentprice+"  lendPrice = "+ this.lendprice+"   Quantity = "+ this.quantity+"  Discount = "+ this.discount ;        
    }
}
