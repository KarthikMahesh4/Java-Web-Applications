import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.logging.Logger;


public class addtowishlist extends HttpServlet 
{

    public static Logger LOGGER = Logger.getLogger("InfoLogging"); 
    
    public String readFile(String filename) 
                {
                    File f = new File(filename);
                    try 
                    {
                       byte[] bytes = Files.readAllBytes(f.toPath());
                       return new String(bytes, "UTF-8");
                    } 
                    catch (Exception e) 
                    {
                      e.printStackTrace();
                    }
                    return "";
            
                }

    public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
    {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        HttpSession session = request.getSession();
        
        wishlist wish = (wishlist) session.getAttribute("wishlist");

        if(wish == null)
        {
          wish = new wishlist();
          session.setAttribute("wishlist", wish);
        }

        String pname = request.getParameter("productname");
        LOGGER.info("Addtowishlist pname = "+pname);

        double pprice = Double.parseDouble(request.getParameter("productprice"));
        LOGGER.info("Addtowishlist Price of pname = "+pprice);

        wish.addtoWishlist(pname, pprice);

        session.setAttribute("wishlist", wish);
        
        
        String username = (String) session.getAttribute("sessionusername"); // session is set

           
                String msg;
                String hdr = readFile("C:\\apache-tomcat-7.0.34\\webapps\\project\\header.html");
                
                if(session!=null)
                {                   
                    out.println(hdr.replaceAll("guest", username));
                    msg="successfully login";
                } 
                
                else 
                {
                    out.println(hdr);
                    
                }
        
                out.println(readFile("C:\\apache-tomcat-7.0.34\\webapps\\project\\navigationbar.html"));
                out.println(" <div class='content'> ");
                /*out.println("<h1>Added to Wishlist</h1>");
                out.println("<form action=''><input style='background-color: #121D33; color: white;' type='submit' value='Continue shopping'></form>");
                out.println("<hr>");*/
                out.println("<h2>WishList</h2>");

            HashMap<String, Double> items = wish.getwishlistitems();


            out.println("<table class='table' border='1px'>");
           
            out.println("<tr>");

            out.println("<th style='background-color: #121D33; color: white;'>");
            out.println("Product");
            out.println("</th>");

            out.println("<th style='background-color: #121D33; color: white;'>");
            out.println("price");
            out.println("</th>");

            out.println("<th style='background-color: #121D33; color: white;'>");
            out.println("Action");
            out.println("</th>");

            out.println("</tr>");

            
            for (String key: items.keySet())
            {
                out.println("<tr>");
                out.println("<td>");
                String itemkey =key;

                String value = items.get(key).toString();  
                out.println(itemkey);
                out.println("</td>");

                out.println("<td>");
                out.println(value);
                out.println("</td>");

                out.println("<td>");
                out.println("<form  method = 'get' action = 'deletefromwishlist'>");
                out.println("<input type = 'hidden' name='productname' value='"+itemkey+"'>");
                out.println("<input style='background-color: #121D33; color: white;' type = 'submit' name = 'Remove' value='Remove Item'>");
                out.println("</form>");
                
                /*out.println("<form  method = 'get' action = 'addtocart'>");
                out.println("<input type = 'hidden' name='name' value='"+itemkey+"'>");
                out.println("<input style='background-color: #121D33; color: white;' type = 'submit' name = 'Add' value='addtocart'>");
                out.println("</form>");*/
                out.println("</td>");

                out.println("</tr>");
            } 

                out.println("</table>");
                /*out.println("<form  method = 'get' action = 'checkout'>");
                out.println("<input style='background-color: #121D33; color: white;' type = 'submit' name = 'buy' value = 'Checkout'>");
                out.println("</form>");*/
                out.println("</div>");
                
                out.println(readFile("C:\\apache-tomcat-7.0.34\\webapps\\project\\footer.html"));

    }

}