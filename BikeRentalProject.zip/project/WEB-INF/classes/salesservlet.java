import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.nio.file.Files;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class salesservlet extends HttpServlet 
{
  public void init() throws ServletException
  {
    
    } 
     
  public String readData(String filename) 
        {
            File f = new File(filename);
            try 
            {
                byte[] bytes = Files.readAllBytes(f.toPath());
                return new String(bytes, "UTF-8");
              } 
              catch (Exception e) 
              {
              }
              return  null;
          
          }

  public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
  {
      try {
          String msg;
          HttpSession sessionHttp = request.getSession();
          cart shoppingCart= (cart) sessionHttp.getAttribute("cart");
          String username= (String) sessionHttp.getAttribute("sessionusername"); 
          PrintWriter pw = response.getWriter();
          
          if(username!=null)
          {
              pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\header.html").replaceAll("guest", username));
              pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\navigation.html"));
              pw.println(" <div class='content' id='about'> ");
              MySqlDataStoreUtilities mysqlObject;
          mysqlObject = new MySqlDataStoreUtilities();
          int k=0;
          
          HashMap<Integer, inventory> result = mysqlObject.getSales();
          pw.println("<table class='table' border='2px'><tr><th>Product Type</th><th>Product Name</th><th>Product Price</th><th>Product Quantity</th></tr>");
          for(Integer i : result.keySet())
          {
            // inventory odobj = result.get(i);
            // pw.println("<h4 align='center' STYLE='font-weight: bold; color: black;' >Product Details</h4><table border='1' class='table'><tr>");
            // pw.println("<input type = 'hidden' name='Product' value='"+i+"'></tr><tr><th>");
            // pw.println("Product Type");
            // pw.println("</th><td>");
            // pw.println(odobj.getproducttype());
            // pw.println("</td></tr><tr><th>");
            // pw.println("Product Name");
            // pw.println("</th><td>");
            // pw.println(odobj.getproductname());
            // pw.println("</td></tr><tr><th>");
            // pw.println("Product Price");
            // pw.println("</th><td>");
            // pw.println(odobj.getprice());
            // pw.println("</td></tr><tr><th>");
            // pw.println("Product Count");
            // pw.println("</th><td>");
            // pw.println(odobj.getquantity());
            // pw.println("</td></tr><tr><th>");
            // pw.println("Product Condition");
            // pw.println("</th><td>");
            // pw.println(odobj.getpcondition());
            // pw.println("</td></tr></table><hr>");
            // pw.println("<form  method = 'get' action = 'rebate'><input  type = 'submit' name = 'rebate' value = 'index'></form>");


            inventory odobj = result.get(i);
            // pw.println("<h4 align='center' STYLE='font-weight: bold; color: black;' >Product Details</h4><table border='1' class='table'><tr>");
            // pw.println("<input type = 'hidden' name='Product' value='"+i+"'></tr><tr><th>");
            // pw.println("Product Type");
            pw.println("<tr>");

              pw.println("<td>");
              pw.println(odobj.getproducttype());
              pw.println("</td>");
              // pw.println("Product Name");
              pw.println("<td>");
              pw.println(odobj.getproductname());
              pw.println("</td>");

              pw.println("<td>");
              pw.println(odobj.getprice());
              pw.println("</td>");

              pw.println("<td>");
              pw.println(odobj.getquantity());
              pw.println("</td>");

            pw.println("</tr>");

          }
          pw.println("</table>");
          pw.println("<hr>");

         // pw.println("<form  method = 'get' action = 'rebate'><input  type = 'submit' name = 'rebate' value = 'Rebate'></form>");
          pw.println("</div>");
          pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\footer.html"));
          }
          
          else
          {
              pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\header.html"));
              pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\navigation.html"));
              pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\footer.html"));
              
          }
      } catch (SQLException e) {
          Logger.getLogger(orderservlet.class.getName()).log(Level.SEVERE, null, e);
      }

    }
  }