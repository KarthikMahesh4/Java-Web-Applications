
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.nio.file.Files;
import java.util.logging.Logger;

import javax.servlet.http.*;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.SQLException;
import java.util.*;


public class showorder extends HttpServlet 
{
	public String readFile(String filename) 
				{
		   			File f = new File(filename);
		   			try 
		   			{
			           byte[] bytes = Files.readAllBytes(f.toPath());
				       return new String(bytes, "UTF-8");
	        		} 
	        		catch (Exception e) 
	        		{
		       		//	e.printStackTrace();
	        		}
	        		return "";
	        
	    		}

 public static Logger LOGGER = Logger.getLogger("InfoLogging");
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
	{

           //   HttpSession session = request.getSession();

				HttpSession session = request.getSession();
        
        		cart shoppingCart;

        		shoppingCart = (cart) session.getAttribute("cart");
               // HttpSession session = request.getSession(true);
                String username;
                username = (String) session.getAttribute("sessionusername"); // session is set

                PrintWriter out = response.getWriter();
                String msg;
                String hdr = readFile("C:\\apache-tomcat-7.0.34\\webapps\\project\\header.html");
                
                if(username!=null)
                {                   
                    out.println(hdr.replaceAll("guest", username));
                    msg="successfully login";
                } 
                
                else 
                {
                    out.println(hdr);
                    
                }
                out.println(readFile("C:\\apache-tomcat-7.0.34\\webapps\\project\\navigationbar.html"));
                out.println(" <div class='content'> ");
                out.println("<h2>Here is your order detail</h2>");
                out.println("currently login user is "+username);

                int  ordernumber=  Integer.parseInt(request.getParameter("ordernumber"));
                Double totalamt=Double.parseDouble(request.getParameter("totalamount"));
				//System.out.println("total amount is received:",+totalamt);
                String address= request.getParameter("address");
                int creditcard= Integer.parseInt(request.getParameter("cardnumber"));
                String deliverydate=  request.getParameter("deliverydate");
			    String productname=  request.getParameter("productname");

           

             
                        
			    String producttype=  null;
			

                
                username= request.getParameter("name");
             

                // call the method of insert order into table
                MySqlDataStoreUtilities mysqlObject;
                mysqlObject = new MySqlDataStoreUtilities();
				  try
	                {
                        LOGGER.info("ShowOrder: value of producttype=========================== "+productname);
	                    producttype = mysqlObject.getProductType(productname);
	                    System.out.println(producttype);
	                    Logger.getLogger("ShowOrder: value of producttype= "+producttype);
                        
	                } 

	                catch (SQLException ex) 
	                {
	                    Logger.getLogger(showorder.class.getName()).log(Level.SEVERE, null, ex);
	                }

                mysqlObject.insertOrder(ordernumber,username,totalamt,address,creditcard,deliverydate,null,null,productname,producttype);
                
         
               // Double totalamount=
                 out.println("<table class='table' border='1px'>");
                 
                 out.println("<tr>");
                 out.println("<th>");
                 out.println("Order Number");
                 out.println("</th>");
                 out.println("<td>");
                 out.println(ordernumber);
                 out.println("</td>");
                 out.println("</tr>");
				 
				/* out.println("<tr>");
                 out.println("<th>");
                 out.println("Product Name");
                 out.println("</th>");
                 out.println("<td>");
                 out.println(productname);
                 out.println("</td>");
                 out.println("</tr>");
				 
				 out.println("<tr>");
                 out.println("<th>");
                 out.println("Product Type");
                 out.println("</th>");
                 out.println("<td>");
                 out.println(producttype);
                 out.println("</td>");
                 out.println("</tr>");*/
                 
                 out.println("<tr>");
                 out.println("<th>");
                  out.println("Name");
                 out.println("</th>");
                 out.println("<td>");
                  out.println(username);
                 out.println("</td>");
                 out.println("</tr>");

                 out.println("<tr>");
                 out.println("<th>");
                  out.println("Product Name");
                 out.println("</th>");
                 out.println("<td>");
                  out.println(productname);
                 out.println("</td>");
                 out.println("</tr>");


                  out.println("<tr>");
                 out.println("<th>");
                  out.println("Product Type");
                 out.println("</th>");
                 out.println("<td>");
                  out.println(producttype);
                 out.println("</td>");
                 out.println("</tr>");

                 out.println("<tr>");
                 out.println("<th>");
                  out.println("Total Amount");
                 out.println("</th>");
                 out.println("<td>");
                  out.println("$"+totalamt);
                 out.println("</td>");
                 out.println("</tr>");

                 out.println("<tr>");
                 out.println("<th>");
                  out.println("deliverydate");
                 out.println("</th>");
                 out.println("<td>");
                  out.println(deliverydate);
                 out.println("</td>");
                 out.println("</tr>");

                 out.println("<tr>");
                 out.println("<th>");
                 out.println("Address");
                 out.println("</th>");
                 out.println("<td>");
                 out.println(address);
                 out.println("</td>");
                 out.println("</tr>");

                 out.println("<tr>");
                 out.println("<th>");
                 out.println("<form  method = 'get' action = 'cancelorder'>");
	             out.println("<input  type = 'submit' name = 'buy' value = 'cancel order'>");
	             out.println("<input type = 'hidden' name='orderid' value='"+ordernumber+"'>");
	             out.println("</form>");

                 out.println("</th>");
                 out.println("</tr>");

                 out.println("</table>");



               
                out.println("</div>");
                
                out.println(readFile("C:\\apache-tomcat-7.0.34\\webapps\\project\\footer.html"));

    }

}


