//package ecom;

import java.util.HashMap;
class filter
{
    private Integer productid;
    String productretailer;
    String productimage;
    String productname;
    String productisbn;
    String productdescription;
    String productauthor;
    //double buyprice;
   // double rentprice;
   // double sellprice;
    //double discount;
    String producttype;
    
   // HashMap<String,Accessory> accessories = new HashMap<String,Accessory>();
    
    public filter()
	{}
	public filter (Integer productid,String producttype, String productimage, String productname,String productisbn, String productdescription,  String productauthor)
    {
        this.productid=productid;
        this.producttype=producttype;
        this.productimage=productimage;
        this.productname=productname;
        this.productisbn= productisbn;
        this.productdescription = productdescription;
        this.productauthor = productauthor;
        // this.buyprice=buyprice;
        // this.rentprice=rentprice;
        // this.sellprice=sellprice; 
    }
    
    
    
    public Integer getproductid() 
	{
    
        return this.id ;
    }

    public String getproducttype() 
	{
    
        return this.type ;
    }

    
    public String getproductimage() 
    {
        return this.image;
    }
    

    public String getproductname() 
    {
        return this.name;
    }
    

     public String getIsbn() 
    {
        return this.isbn;
    }
    
    public String getproductdescription() 
    {
        return this.description;
    }
    

    public String getproductauthor() 
    {
        return this.author;
    }
    
    //  public double getBuyPrice() 
    // {
    //     return this.buyprice;
    // }
    
    //  public double getRentPrice() 
    // {
    //     return this.rentprice;
    // }
    
    //  public double getSellPrice() 
    // {
    //     return this.sellprice;
    // }
    

     public String toString() 
     {
        

        return "Product:: ID="+this.productid+"        Name="+this.productname+"        Image="+ this.productimage + "       id = "+this.productisbn+"    Description = "+this.productdescription+"   Author = "+this.productauthor;        
    }
}
