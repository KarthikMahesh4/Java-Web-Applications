import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.logging.Logger;


public class wishlistaddtocart extends HttpServlet 
{

    public static Logger LOGGER = Logger.getLogger("InfoLogging"); 
    
    public String readFile(String filename) 
                {
                    File f = new File(filename);
                    try 
                    {
                       byte[] bytes = Files.readAllBytes(f.toPath());
                       return new String(bytes, "UTF-8");
                    } 
                    catch (Exception e) 
                    {
                      e.printStackTrace();
                    }
                    return "";
            
                }

    public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
    {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        HttpSession session = request.getSession();
        
        cart shoppingCart;

        shoppingCart = (cart) session.getAttribute("cart");

        if(shoppingCart == null)
        {
          shoppingCart = new cart();
          session.setAttribute("cart", shoppingCart);
        }

        String pname = request.getParameter("name");
        
        double pprice = Double.parseDouble(request.getParameter("buyprice"));
        
        LOGGER.info("AddToCart: Value of pname = "+pname);
        
        LOGGER.info("AddToCart: Value of pname = "+pprice);

        shoppingCart.addToCart(pname, pprice);

        session.setAttribute("cart", shoppingCart);
        
        
        String username = (String) session.getAttribute("sessionusername"); // session is set

           
                String msg;
                String hdr = readFile("C:\\apache-tomcat-7.0.34\\webapps\\project\\header.html");
                
                if(session!=null)
                {                   
                    out.println(hdr.replaceAll("guest", username));
                    msg="successfully login";
                } 
                
                else 
                {
                    out.println(hdr);
                    
                }
        
                out.println(readFile("C:\\apache-tomcat-7.0.34\\webapps\\project\\navigationbar.html"));
                out.println(" <div class='content'> ");
                
                out.println("<h1>Item successfully added </h1>");
                out.println("<form action='index'>Continue shopping...<input style='background-color: #121D33; color: white;' type='submit' value='Add more items'></form>");
                out.println("<hr>");
                out.println("<h2>Cart</h2>");

            HashMap<String, Double> items = shoppingCart.getcartitems();


            out.println("<table class='table' border='1px'>");
           
            out.println("<tr>");

            out.println("<th style='background-color: #121D33; color: white;'>");
            out.println("Product");
            out.println("</th>");

            out.println("<th style='background-color: #121D33; color: white;'>");
            out.println("price");
            out.println("</th>");

            out.println("<th style='background-color: #121D33; color: white;'>");
            out.println("Action");
            out.println("</th>");

            out.println("</tr>");

            
            for (String key: items.keySet())
            {
                out.println("<tr>");
                out.println("<td>");
                String itemkey =key;

                String value = items.get(key).toString();  
                out.println(itemkey);
                out.println("</td>");

                out.println("<td>");
                out.println(value);
                out.println("</td>");

                out.println("<td>");
                out.println("<form  method = 'get' action = 'addtocart'>");
                out.println("<input style='background-color: #121D33; color: white;' type = 'submit' name = 'AddToCart' value = 'Add to Cart'>");
                out.println("<input type = 'hidden' name='productname' value="+itemkey+">");
                out.println("</form>");
                out.println("</td>");
                out.println("</tr>");
            } 

                out.println("</table>");
                out.println("<form  method = 'get' action = 'checkout'>");
                out.println("<input style='background-color: #121D33; color: white;' type = 'submit' name = 'buy' value = 'Checkout'>");
                out.println("</form>");
                out.println("<h3>Accessories</h3>");
                out.println("<div id='myCarousel' class='carousel slide'>"+
                                    "<ol class= 'carousel-indicators'>"+
                                    "<li data-target='#myCarousel' data-slide-to='0' class='active'></li>"+
                                    "<li data-target='#myCarousel' data-slide-to='1'></li>"+
                                    "<li data-target='#myCarousel' data-slide-to='2'></li>"+
                                    "</ol>"+
                                    "<div class='carousel-inner'>"+
                                    
                                    "<div class='item active'>"+
                                    "<form method='get' action='headphones'>"+
                                    "<img src='images/ass1.jpg' alt='first slide' style='width:500px height:300px; align: center;''>"+
            "<input style='background-color: #121D33; color: white;' type='submit' name='Add to Cart' value='View this Item' >"+
          "</form>"+
                                    "</div>"+
                                    
                                    "<div class='item'>"+
                                    "<form method='get' action='laptop'>"+
                                    "<img src='images/ass2.jpg' alt='second slide' style='width:500px height:300px;''>"+
            "<input style='background-color: #121D33; color: white;' type='submit' name='Add to Cart' value='View this Item' >"+
          "</form>"+
                                    "</div>"+
                                    
                                    "<div class='item'>"+
                                    "<form method='get' action='smartphone'>"+
                                    "<img src='images/ass4.jpg' alt='third slide' style='width:500px height:300px;''>"+
            "<input style='background-color: #121D33; color: white;' type='submit' name='Add to Cart' value='View this Item' >"+
          "</form>"+
                                    "</div>"+
                                    "</div>"+
                                    "<a class='carousel-control left' href='#myCarousel' data-slide='prev'>"+
                                    "<span class='icon-prev'></span>"+
                                    "</a>"+
                                    "<a class='carousel-control right' href='#myCarousel' data-slide='next'>"+
                                    "<span class='icon-next'></span>"+
                                    "</a>"+
                                    "</div>"+
                                    "<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>"+
                                    "<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js'></script>"+
                                    "<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>");

                out.println("</div>");
                
                out.println(readFile("C:\\apache-tomcat-7.0.34\\webapps\\project\\footer.html"));

    }

}