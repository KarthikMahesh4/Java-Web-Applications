 class salesreport
 {
    private String producttype;
    private String productname;
    private double price;
    private int quantity;
    private double totalsales;
    private String dailydates;

    
    public salesreport()
    {}

    public salesreport(String producttype, String productname,double price,int quantity,double totalsales,String dailydates)
    {
        this.producttype = producttype;
        this.productname = productname;
        this.price = price;
        this.quantity = quantity;
        this.totalsales=totalsales;
        this.dailydates=dailydates;
    }
    
    public String getproducttype(){
        return this.producttype;
    }
    
    public String getproductname(){
        return this.productname;
    }
    
    public double getprice(){
        return this.price;
    }
       
    public int getquantity(){
        return this.quantity;
    }

    public double gettotalsales(){
        return this.totalsales;
    }

    public String getdailydates() {
        return this.dailydates;
    }

    public String ToString()
    {
         return this.producttype+" "+this.productname+" "+this.price+" "+this.quantity+" "+this.totalsales+" "+this.dailydates;
    }
     
}