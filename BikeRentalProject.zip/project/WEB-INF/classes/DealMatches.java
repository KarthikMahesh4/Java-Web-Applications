import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.nio.file.Files;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;



import java.io.File;
import java.io.IOException;
import java.util.List;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;



public class DealMatches extends HttpServlet 
{
	public String readData(String filename) 
				{
		   			File f = new File(filename);
		   			try 
		   			{
			           byte[] bytes = Files.readAllBytes(f.toPath());
				       return new String(bytes, "UTF-8");
	        		} 
	        		catch (Exception e) 
	        		{}
	        		return null;
	        
	    		}

	public static Logger LOGGER = Logger.getLogger("InfoLogging");

	public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
	{
				int counter =0;
				int countproduct = 0;
				String line=null;
				Connection conn = null;
				ResultSet rs = null;
				HashMap<String,product> productssel=new HashMap<String,product>(); 

				try
				{
						PrintWriter pw = response.getWriter();
						conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/cs584","root","root");
						String products = "SELECT productname From product ";					
						PreparedStatement checkuserstmt = conn.prepareStatement(products);
						HttpSession sessionHttp = request.getSession(true);
						String username = (String) sessionHttp.getAttribute("sessionusername"); 
		                
		                if(username!=null)
		                {       			
		                	pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\header.html").replaceAll("guest", username));
		            	} 
		            	else 
		            	{
		            		pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\header.html"));
		            	}
		               
		                pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\navigationbar.html"));
		                pw.println(" <div id='content'><h2>Books Best Deals from Abebooks</h2>");
						rs=checkuserstmt.executeQuery();
						BufferedReader bufferReader = new BufferedReader(new FileReader (new File("C:\\apache-tomcat-7.0.34\\webapps\\project\\DealMatches.txt")));
						StringBuffer strBuffer = new StringBuffer();
					try
					{
						pw.println("<br><br>");
						MySqlDataStoreUtilities util = new MySqlDataStoreUtilities();
						HashMap<String,product> map=util.getData();
					
					for(Map.Entry<String, product> entry : map.entrySet())
					{
						if(productssel.size()<2 && !productssel.containsKey(entry.getKey()))
						{

									BufferedReader reader = new BufferedReader(new FileReader (new File("C:\\apache-tomcat-7.0.34\\webapps\\project\\DealMatches.txt")));
									line=reader.readLine();	
									if(line!=null)		
									{ 
										do 
										{			
											if(line.contains(entry.getKey()))			
											{				
											
												pw.println("<h3>"+line+"</h3>");
												pw.println("<br>");
												productssel.put(entry.getKey(),entry.getValue());
												break;
											}			
										 }while((line = reader.readLine()) != null);	
									}	
									else
									{	
										pw.println("<h2 align='center'>No Offers Found</h2>");
										break;
									}	
						}
					}
									 for(String  name : productssel.keySet())
							         {
							           
							            product proobj = productssel.get(name);
							            String img = proobj.getImage();
										pw.println("<img src='"+img+"' alt='image' height='100' width='100' /><br>");
										pw.println("<h3 style='color:orange;'>Name : "+proobj.getName()+    "</h3><br><h3 style='color:orange;'>Price : $"+proobj.getBuyPrice()+"</h3><br><h3 style='color:orange;'>Type : "+proobj.getType()+"</h3>");
										pw.println("<form  style='color:black;' method = 'get' action = 'addtocart'><input  type = 'submit' name = 'buy' value = 'BUY'>");
		                				pw.println("<input type = 'hidden' name='name' value="+proobj.getName()+"><input type = 'hidden' name='buyprice' value="+proobj.getBuyPrice()+"><input type = 'hidden' name='Type' value="+proobj.getType()+"></form>");
										pw.println("______________________________________________________________________________________________");
										pw.println("<br>");


									 }
					}		
					
					catch(Exception E)
					{}
					pw.println("</div>");
                	pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\footer.html"));
                }
				catch(Exception ex)
				{}
	}
}


