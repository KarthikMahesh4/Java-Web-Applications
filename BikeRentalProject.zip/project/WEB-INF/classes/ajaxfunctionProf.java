import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.nio.file.Files;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;


import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
//import org.apache.catalina.User;

public class ajaxfunctionProf extends HttpServlet 
{
    public void init() throws ServletException
    {
    }
    public String readFile(String filename) 
                {
                    File f = new File(filename);
                    try 
                    {
                       byte[] bytes = Files.readAllBytes(f.toPath());
                       return new String(bytes, "UTF-8");
                    } 
                    catch (Exception e) 
                    {
                    //  e.printStackTrace();
                    }
                    return "";
            
                }
                
    public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
    {
            PrintWriter out = response.getWriter();
            String searchid=  request.getParameter("id");
            //searchid = "";
            System.out.println("SEARCH ID is="+searchid);
            try{  
                                Connection conn = null;
                                Statement stmt = null;
                                ResultSet rs = null;
                                StringBuffer sb = new StringBuffer();
                                Class.forName("com.mysql.jdbc.Driver").newInstance();
                                conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/cs584?useSSL=false","root","Password@123");
                                
                                stmt=conn.createStatement();
                                String selectCustomerQuery="select * from product";
                                rs= stmt.executeQuery(selectCustomerQuery);
                               
                                String action = request.getParameter("action");

                                boolean namesAdded = false;
                                
                                if (action.equals("complete")) 
                                {
                                    if (!searchid.equals(""))
                                    { 
                                        while(rs.next())
                                        {
                                            String name =rs.getString("productname");
                                            
                                            if (name.toLowerCase().startsWith(searchid))
                                            {
                                                
                                                sb.append("<product>");
                                                sb.append("<productName>" + name + "</productName >");
                                                sb.append("</product>");
                                                namesAdded = true;
                                            }
                                        }
                                    }


                                        if (namesAdded)
                                        {
                                            response.setContentType("text/xml");
                                            response.setHeader("Cache-Control", "no-cache");
                                            response.getWriter().write("<products>" + sb.toString() + "</products >");
                                        }
                                } 
                                 if (!namesAdded) 
                                {
                                            String name = request.getParameter("productname");
                                            System.out.println("lookup action"+name);
                                            HttpSession session = request.getSession(true);
                                            String username = (String) session.getAttribute("sessionusername"); 
                                        
                                            String hdr = readFile("C:\\apache-tomcat-7.0.34\\webapps\\project\\header.html");
                                            
                                            if(username!=null)
                                            {                   
                                                out.println(hdr.replaceAll("guest", username));
                                               
                                            } 
                                            
                                            else 
                                            {
                                                out.println(hdr);
                                                
                                            }

                                           
                                            out.println(readFile("C:\\apache-tomcat-7.0.34\\webapps\\project\\navigationbar.html"));
                                            out.println(" <div id='content'> ");
                                            out.println("<h2>Product Searched</h2>");
                                            String displayproduct="select * from product where productname='"+name+"'";
                                            rs= stmt.executeQuery(displayproduct);
                                            out.println("<table>");
                                             while(rs.next())
                                             {
                                                    String pname=(rs.getString("productname"));
                                                    Double bprice=(rs.getDouble("buyprice"));
                                                    String image =(rs.getString("image"));

                    
                                                    out.println("<tr>");
                                                    out.println("<td>");
                                                    out.print("<img src='"+image+"' alt='image' height='85' width='85' />");
                                                    out.println("</td>");
                                                    out.println("<td>");
                                                    out.println("Product Name = "+pname+"<br>");
                                                    out.println("Price = $"+bprice+"<br>");
                                                    out.println("</td>");
                                                    out.println("<td>");
                                                    out.println("<form  method = 'get' action = 'addtocart'>");
                                                    out.println("<input  type = 'submit' name = 'buy' value = 'Buy'>");
                                                    out.println("<input type = 'hidden' name='name' value='"+pname+"''>");
                                                    out.println("<input type = 'hidden' name='buyprice' value="+bprice+">");
                                                    
                                                    out.println("</form>");

                                                    out.println("<form class = 'submit-button' method = 'get' action = 'writereview'>");
                                                    out.println("<input class = 'submit-button' type = 'submit' name = 'submit' value = 'Write Review'>");
                                                    out.println("<input type = 'hidden' name='productname' value='"+pname+"'>");
                                                    out.println("<input type = 'hidden' name='productprice' value='"+bprice+"'>");
                                                    out.println("<input type = 'hidden' name='category' value='book'>");
                                                    out.println("<input type = 'hidden' name='retailer' value='LionBooks'>");
                                                    out.println("</form>");

                                                    out.println("<form class = 'submit-button' method = 'get' action = 'viewreview'>");
                                                    out.println("<input class = 'submit-button' type = 'submit' name = 'submit' value = 'View Reviews'>");
                                                    out.println("<input type = 'hidden' name='productname' value='"+pname+"'>");
                                                    out.println("</form>");

                                                   
                                                    out.println("</td>");
                                                    out.println("</tr>");
                                             }
                                            out.println("</table>");
                                            out.println("</div>");
                
                                            out.println(readFile("C:\\apache-tomcat-7.0.34\\webapps\\project\\footer.html"));
                                }

                }
                catch(Exception e)
                {
                    e.printStackTrace();
                }  

    }
}