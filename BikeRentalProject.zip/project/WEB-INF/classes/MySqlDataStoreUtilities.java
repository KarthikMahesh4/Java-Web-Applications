
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MySqlDataStoreUtilities
{
	Connection conn = null;
	public String msg;

	MySqlDataStoreUtilities()
	{
		try
		{
			System.out.println("entered first try block in my sql");
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/cs584","root","Password@123");
			System.out.println("conn statement completed ");
			System.out.println("Connection Established Successfull and the DATABASE NAME IS:"
                        + conn.getMetaData().getDatabaseProductName());	
			System.out.println("completed first try block in my sql");
		}
	
		catch(Exception e)
		{
		System.out.println("encountered first exception");
		}
	}


	public  String insertUser(String username,String password,String usertype,String email,Integer phonenumber) throws SQLException
	{	
        ResultSet rs = null;
		
			
			String insertIntoCustomerRegisterQuery = "INSERT INTO registration(username,password,usertype,email,phonenumber) VALUES (?,?,?,?,?);";
			String checkqry = "SELECT username From registration ";
			PreparedStatement pst = conn.prepareStatement(insertIntoCustomerRegisterQuery);
			PreparedStatement pstcheckqry = conn.prepareStatement(checkqry);

			pst.setString(1,username);
			pst.setString(2,password);
			pst.setString(3,usertype);
			pst.setString(4,email);
			pst.setInt(5,phonenumber);

			rs=pstcheckqry.executeQuery();
			while (rs.next()) 
                        {
                            String exisiting_username=(rs.getString("username"));

                            if(username.equals(exisiting_username))
                            {
                            msg= "user name is already exist";
                            return msg;
                            }
                            else
                            {
                                    pst.execute();
                                    msg= "User is successfully registered";
                                    return msg;                                   
                            }
                        }
               
                return msg;
        }
        int i=0;
		public  int getUser(String username,String password) throws SQLException
		{
		        System.out.println("Entered getuser" + username +password);
                ResultSet rs = null;
					
				System.out.println("rs set to null" + rs);
					String checkuser = "SELECT username,password From registration ";
					System.out.println("Connection Established Successfull and the DATABASE NAME IS:"
                        + conn.getMetaData().getDatabaseProductName());					
					PreparedStatement checkuserstmt = conn.prepareStatement(checkuser);
					rs=checkuserstmt.executeQuery();
					System.out.println("ads" + rs.getString("username"));

					while (rs.next()) 
                    {
                                            String exisiting_username=(rs.getString("username"));
                                            String upwd=(rs.getString("password"));
                                            if(username.equals(exisiting_username) && password.equals(upwd) )
                                            {
                                            	i=1;
                                            }
                                            else
                                            {
                                            	i=0;
                                            }
                                            
			   		}
			   	
			   	return i;
		}

		 public String getUserType(String username,String password) throws SQLException
		{
                ResultSet resultset = null;
				String checkUserType = "SELECT usertype From registration where username=? and password=?";
					PreparedStatement checkUserResults = conn.prepareStatement(checkUserType);
                    checkUserResults.setString(1, username);
                    checkUserResults.setString(2, password);
					resultset=checkUserResults.executeQuery();
					String userTypeInfo=null;
                    if(resultset.next()){
                        userTypeInfo = resultset.getString("usertype");
                    }else{
                        userTypeInfo = null;
                    }
			   	return userTypeInfo;
		}

        		// store customer order into database
		public void insertOrder(int orderId,String userName,Double totalamount,String address,int creditcard,String deliverydate,String rentfrom,String rentto,String productname,String producttype)
		{ 
			try
			{
				
				String insertIntoCustomerOrderQuery = "INSERT INTO customerorder(orderid,username,totalamount,address,creditcard,deliverydate,rentfrom,rentto,productname,producttype) VALUES (?,?,?,?,?,?,?,?,?,?);";
				PreparedStatement pst = conn.prepareStatement(insertIntoCustomerOrderQuery);

				pst.setInt(1,orderId);
				
				pst.setString(2,userName);
				pst.setDouble(3,totalamount);
				pst.setString(4,address);
				pst.setInt(5,creditcard);
				pst.setString(6,deliverydate);
				pst.setString(7,rentfrom);
				pst.setString(8,rentto);
				pst.setString(9,productname);
				pst.setString(10,producttype);
				pst.execute();
			}
			catch(Exception e)
			{}
		}


		public void insertSellingInfo(int trackingId,String userName,Double totalamount,String address,int creditcard,String productname,String producttype)
		{ 
			try
			{
				
				String insertIntoCustomerOrderQuery = "INSERT INTO SellerInfo(trackingId,username,totalamount,address,creditcard,productname,producttype) VALUES (?,?,?,?,?,?,?);";
				PreparedStatement pst = conn.prepareStatement(insertIntoCustomerOrderQuery);

				pst.setInt(1,trackingId);
				
				pst.setString(2,userName);
				pst.setDouble(3,totalamount);
				pst.setString(4,address);
				pst.setInt(5,creditcard);
				// pst.setString(6,deliverydate);
				// pst.setString(7,rentfrom);
				// pst.setString(8,rentto);
				pst.setString(6,productname);
				pst.setString(7,producttype);
				pst.execute();
			}
			catch(Exception e)
			{}
		}

		public void deleteOrder(int orderId)
		{ 
			try
			{
				System.out.println("delete query is here");
				Statement stmt = null;
				String deleteorder = "delete from customerorder where orderid ="+orderId;
				stmt = conn.createStatement();
				
				stmt.executeUpdate(deleteorder);
				
			}
			catch(Exception e)
			{}
		}


		public HashMap<Integer,order> DisplayOrder(String currentusername) throws SQLException
		{
			HashMap<Integer,order> map = new HashMap<Integer,order>();
	        
	        Statement st = null;
	        ResultSet rs = null;
	    
	       // order orderobject;
	        
	        try{
		            st = conn.createStatement();
		            rs = st.executeQuery("SELECT * FROM customerorder WHERE username='"+currentusername+"'"); 
		           
		            while(rs.next())
		            {
		            	
		            	System.out.println("success");
		                int orderid = rs.getInt("orderid");
		                String username = rs.getString("username");
		                double totalamt = rs.getDouble("totalamount");
		                String address = rs.getString("address");
		                int creditcard = rs.getInt("creditcard");
		                String deliverydate = rs.getString("deliverydate");
		                
		                order orderobject;
		                orderobject = new order(orderid, username,totalamt,address,creditcard,deliverydate);
		                
		                // set data in the hashmap
		                map.put(orderid, orderobject);
			  
			    	}
		    	}
		    	catch(Exception ex)
		    	{
            		ex.printStackTrace();
        		}
		return map;
        }

        public HashMap<String,User> DisplayAllUser() throws SQLException
        {
			HashMap<String,User> umap = new HashMap<String,User>();
	        
	        Statement st11 = null;
	        ResultSet rs11 = null;
	    
	       // order orderobject;
	        
	        try{
		            st11 = conn.createStatement();
		            rs11 = st11.executeQuery("SELECT * FROM registration WHERE usertype='customer'"); 
		           
		            while(rs11.next())
		            {
		            	
		            	System.out.println("success");
		               
		                String username = rs11.getString("username");
						String userpassword = rs11.getString("userpassword");
						String email = rs11.getString("email");
						Integer phonenumber = rs11.getInt("phonenumber");
		                String usertype = rs11.getString("usertype");
		                User userobject;
		                userobject = new User(username,userpassword,usertype,email,phonenumber);
		              
		                umap.put(username, userobject);
			  
			    	}
		    	}
		    	catch(Exception ex)
		    	{
            		ex.printStackTrace();
        		}
		return umap;
        }

        public HashMap<Integer,order> DisplayAllOrder() throws SQLException
		{
			HashMap<Integer,order> map = new HashMap<Integer,order>();
	        
	        Statement st = null;
	        ResultSet rs = null;
	    
	       // order orderobject;
	        
	        try{
		            st = conn.createStatement();
		            rs = st.executeQuery("SELECT * FROM customerorder"); 
		           
		            while(rs.next())
		            {
		            	
		            	//
		            	System.out.println("success");
		                int orderid = rs.getInt("orderid");
		                String username = rs.getString("username");
		                double totalamt = rs.getDouble("totalamount");
		                String address = rs.getString("address");
		                int creditcard = rs.getInt("creditcard");
		                String deliverydate= rs.getString("deliverydate");
		                
		                order orderobject;
		                orderobject = new order(orderid, username,totalamt,address,creditcard,deliverydate);
		                
		                // set data in the hashmap
		                map.put(orderid, orderobject);
			  
			    	}
		    	}
		    	catch(Exception ex)
		    	{
            		ex.printStackTrace();
        		}
		return map;
        }

		public HashMap<String,inventory> getInventory() throws SQLException
		{
			HashMap<String,inventory> Hmap = new HashMap<String,inventory>();

            Statement st = null;
	        ResultSet rs = null;
			System.out.println("entered getInventory() of My SQL, HMAP object created");
	        
	        try{
		            st = conn.createStatement();
					System.out.println("Connection  success");
		            rs = st.executeQuery("select p.productid,p.producttype,p.productname,p.rentprice, p.pickup, case when p.quantity=0 then p.quantity when p.quantity-t.sold is null then p.quantity else p.quantity-t.sold end as quantity from product p LEFT JOIN (select productid,sum(quantity) as sold from customerorder group by productid) t ON t.productid=p.productid  order by p.productid");
		           
		           System.out.println("Select query completed getInventory() of My SQL");
		            while(rs.next())
		            {
						System.out.println("inside while of getInventory() of My SQL");
		                String productid = rs.getString("productid");
		                String producttype = rs.getString("producttype");
		                String productname = rs.getString("productname");
		                double rentprice = rs.getDouble("rentprice");
						String pickup = rs.getString("pickup");
		                int quantity = rs.getInt("quantity");
		                inventory orderobject = new inventory(producttype,productname,rentprice,pickup,0,quantity);
		                Hmap.put(productid, orderobject);
			    	}
		    }
		    catch(Exception ex)
		    {
			System.out.println("exception of getInventory() of My SQL");
        	}
        	return Hmap;
        }

        public HashMap<String,inventory> getDiscount() throws SQLException
		{
			HashMap<String,inventory> Hmap = new HashMap<String,inventory>();

            Statement st = null;
	        ResultSet rs = null;
	    
	        
	        try{
		            st = conn.createStatement();
					System.out.println("inside getDiscount - before query");
		            rs = st.executeQuery("select p.productid,p.producttype,p.productname,p.rentprice,p.discount,p.quantity from product p where p.discount is not null or p.discount!=0");
		           	while(rs.next())
		            {
		                String productid = rs.getString("productid");
		                String producttype = rs.getString("producttype");
		                String productname = rs.getString("productname");
		                double rentprice = rs.getDouble("rentprice");
						String pickup = rs.getString("pickup");
		                int quantity = rs.getInt("quantity");
		                int discount = rs.getInt("discount");
		                inventory orderobject = new inventory(producttype,productname,rentprice, pickup,quantity,discount);
		                Hmap.put(productid, orderobject);
			    	}
		    }
		    catch(Exception ex)
		    {

        	}
        	return Hmap;
        }

        /*public HashMap<String,inventory> getSales() throws SQLException
		{
			HashMap<String,inventory> Hmap = new HashMap<String,inventory>();

            Statement st = null;
	        ResultSet rs = null;
	    
	        
	        try{
		            st = conn.createStatement();
		            rs = st.executeQuery("select p.productid,p.producttype,p.productname,p.buyprice,p.quantity,p.discount from product p where p.quantity!=0");
		           
		            while(rs.next())
		            {
		                int productid = rs.getInt("productid");`
		                String producttype = rs.getString("producttype");
		                String productname = rs.getString("productname");
		                int buyprice = rs.getInt("buyprice");
		                int quantity = rs.getInt("quantity");
		               // String pcondition = rs.getString("pcondition");
		                int rebate = rs.getInt("rebate");
		                inventory orderobject = new inventory(producttype,productname,buyprice,quantity,rebate);
		                Hmap.put(productid, orderobject);
			    	}
		    }
		    catch(Exception ex)
		    {

        	}
        	return Hmap;
        }
*/
        public HashMap<String,salesreport> getSalesReport() throws SQLException
		{
			HashMap<String,salesreport> Hmap = new HashMap<String,salesreport>();

            Statement st = null;
	        ResultSet rs = null;
	    
	        
	        try{System.out.println("inside mysql, inside method try");
		           
		            st = conn.createStatement();
					System.out.println("inside mysql, before query");
					 /*rs = st.executeQuery("select o.productid,o.producttype,o.productname, sum(o.totalamount) as rentprice, sum(o.quantity) as quantity,sum(o.totalamount) as totalsales from customerorder o group by o.productid,o.producttype,o.productname ");*/
		            rs = st.executeQuery("select o.productid,p.producttype,p.productname, p.rentprice, o.quantity,round(o.totalSales,2) as totalsales from (select productid, sum(quantity) as quantity,sum(totalamount) as totalSales from customerorder group by productid)o inner join product p on p.productid=o.productid ");
		           System.out.println("inside mysql, query executed");
		           
		            while(rs.next())
		            {
						System.out.println("inside mysql, inside while");
		                String productid = rs.getString("productid");
		                String producttype = rs.getString("producttype");
		                String productname = rs.getString("productname");
		                int quantity = rs.getInt("quantity");
		                double totalsales=rs.getDouble("totalsales");
						double rentprice=rs.getDouble("rentprice");
		                salesreport orderobject = new salesreport(producttype,productname,rentprice,quantity,totalsales,null);
		                Hmap.put(productid, orderobject);
			    	}
		    }
		    catch(Exception ex)
		    {

        	}
        	return Hmap;
        }
		


        public HashMap<String,dailyreport> getDailySales() throws SQLException
		{
			HashMap<String,dailyreport> Hmap = new HashMap<String,dailyreport>();

            Statement st = null;
	        ResultSet rs = null;
	    
	        
	        try{
		            st = conn.createStatement();
					System.out.println("inside mysql, before query");
		            rs = st.executeQuery("select orderId,orderdate as dailydate,Count(*) as totalsales from customerorder where productname is not null group by orderdate");
		           System.out.println("inside mysql, query executed");
		           
		            while(rs.next())
		            {
		                String orderId = rs.getString("orderId");
		                String dailydate = rs.getString("dailydate");
		                int totalsales=rs.getInt("totalsales");
		                dailyreport orderobject = new dailyreport(totalsales,dailydate);
		                Hmap.put(orderId, orderobject);
			    	}
		    }
		    catch(Exception ex)
		    {

        	}
        	return Hmap;
        }

        public HashMap<String,productclass> getProdDetailsForBarGraph() throws SQLException
		{
			HashMap<String,productclass> map = new HashMap<String,productclass>();
	        
	        Statement st = null;
	        ResultSet rs = null;
	    	        
	        try{
		            st = conn.createStatement();
		            rs = st.executeQuery("select p.productid,p.producttype,p.productname,p.rentprice, p.pickup, case when p.quantity=0 then p.quantity when p.quantity-t.sold is null then p.quantity else round(p.quantity-t.sold,0) end as quantity from product p LEFT JOIN (select productid,sum(quantity) as sold from customerorder group by productid) t ON t.productid=p.productid  order by p.productid;");
					//SELECT productid, productname, quantity FROM product;"); 
		           
		            while(rs.next())
		            {
		            	System.out.println("success");
                                    
                        
                        String prod_id = rs.getString("productid");
                        String prod_name = rs.getString("productname");
                        int prod_quantity = rs.getInt("quantity");
		                productclass productclassobject = new productclass("NULL", prod_id, "NULL", prod_name, 0, 0, prod_quantity);

		                map.put(prod_id, productclassobject);
			  
			    	}
		    	}
		    	catch(Exception ex)
		    	{
            		ex.printStackTrace();
        		}
		return map;
        }

        public HashMap<String,productclass> getSalesDetailsForBarGraph() throws SQLException
		{
			HashMap<String,productclass> map = new HashMap<String,productclass>();
	        
	        Statement st = null;
	        ResultSet rs = null;
	    	        
	        try{
		            st = conn.createStatement();
		            rs = st.executeQuery("select orderId,productname,count(*) * totalamount as totalsales from customerorder where productname is not null and producttype is not null group by productname,producttype;"); 
		           
		            while(rs.next())
		            {
		            	System.out.println("success");
                        String prod_id = rs.getString("orderId");
                        String prod_name = rs.getString("productname");
                        int prod_quantity = rs.getInt("totalsales");
		                productclass productclassobject = new productclass("NULL", prod_id, "NULL", prod_name, 0, 0, prod_quantity);
						map.put(prod_id, productclassobject);
					}
		    	}
		    	catch(Exception ex)
		    	{
            		ex.printStackTrace();
        		}
		return map;
        }

         public HashMap<String,productclass> getSalesItemsDetailsForBarGraph() throws SQLException
		{
			HashMap<String,productclass> map = new HashMap<String,productclass>();
	        Statement st = null;
	        ResultSet rs = null;
	    	        
	        try{
		            st = conn.createStatement();
		            rs = st.executeQuery("select orderId,productname,count(*) as quantity from customerorder where productname is not null and producttype is not null group by productname,producttype;"); 
		           
		            while(rs.next())
		            {
		            	System.out.println("success");
                                    
                        
                        String productid = rs.getString("orderId");
                        String productname = rs.getString("productname");
                        int productquantity = rs.getInt("quantity");

		                productclass productclassobject = new productclass("NULL", productid, "NULL", productname, 0, 0, productquantity);

		                map.put(productid, productclassobject);
			  
			    	}
		    	}
		    	catch(Exception ex)
		    	{
            		ex.printStackTrace();
        		}
		return map;
        }

        public String getProductType(String productname) throws SQLException
		{

                ResultSet rs = null;
                String ptype=null;

					
					String checkuser = "SELECT producttype From product where productname=?";
					
					PreparedStatement checkuserstmt = conn.prepareStatement(checkuser);
				
                    checkuserstmt.setString(1, productname);

					rs=checkuserstmt.executeQuery();
                    if(rs.next()){
                        ptype = rs.getString("producttype");
                    }else{
                        ptype = null;
                    }        
            
			   	return ptype;
		}
    
    
		/*
		public Double getDateDifference(String rentto,String rentfrom) throws SQLException
		{

                ResultSet rs = null;
                Double counter=null;

					
					String checkuser = "select DATEDIFF(STR_TO_DATE(?,'%Y-%m-%d'),STR_TO_DATE(?,'%Y-%m-%d')) as counter from dual";
					
					PreparedStatement checkuserstmt = conn.prepareStatement(checkuser);
				
                    checkuserstmt.setString(1, rentto);
                    checkuserstmt.setString(2, rentfrom);

					rs=checkuserstmt.executeQuery();
                    if(rs.next()){
                        counter = rs.getDouble("counter");
                    }else{
                        counter = null;
                    }        
            
			   	return counter;
		}

*/
		public HashMap<String,product> getData() throws SQLException
		{
			HashMap<String,product> prohashmap =new HashMap<String,product>();

			Statement st1 = null;
		
			ResultSet rss = null;
			product p ;

			try{
					st1 = conn.createStatement(); 
					rss = st1.executeQuery("select * from product");
					
				           
				            while(rss.next())
				            {
				            	
				            	System.out.println(rss);
				                String id = rss.getString("productid");
				                String producttype = rss.getString("producttype");
				                double price = rss.getDouble("rentprice");
				                String name = rss.getString("productname");
				                String image = rss.getString("image");
								String pickup = rss.getString("pickup");
				                p= new product(id,image,name, producttype,pickup,null,price,0,0,0);
				                prohashmap.put(name,p);

				            }
				            
		        }
		        catch(Exception E)
		        {}
		        return prohashmap;
		           
		}

		public String getUserTypeUsingName(String username) throws SQLException
		{
				System.out.println("entered get user type in my sql");
                ResultSet resultset = null;
				String checkUserType = "select usertype From registration where username=?";
					PreparedStatement checkUserResults = conn.prepareStatement(checkUserType);
                    checkUserResults.setString(1, username);
					resultset=checkUserResults.executeQuery();
					String userTypeInfo=null;
                    if(resultset.next()){
                        userTypeInfo = resultset.getString("usertype");
                    }else{
                        userTypeInfo = null;
                    }
				System.out.println("completed get user type in my sql");
			   	return userTypeInfo;
			   }

		
}

