import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.nio.file.Files;

public class login extends HttpServlet 
{
	public String readData(String filename) 
                {
                    File file = new File(filename);
                    try 
                    {
                       byte[] bytesRead = Files.readAllBytes(file.toPath());
                       return new String(bytesRead, "UTF-8");
                    } 
                    catch (Exception e) 
                    {
                    }
                    return null;
                }

	public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
	{

            PrintWriter pw = response.getWriter();

                pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\header.html"));
                pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\navigation.html"));
                pw.println(" <div id='content' align='center'><h2>Welcome</h2><h4>Login</h4>");
                pw.println("<FORM action='loginservlet' method='get'><P><LABEL for='username'>Username </LABEL>");
                pw.println("<INPUT type='text' id='Username' name='uname'><BR>");
                pw.println("<LABEL for='password' >Password </LABEL>");
                pw.println("<INPUT type='password' name='upassword' id='Password'><BR>");
                pw.println("<INPUT type='submit' value='Go'> <INPUT type='reset'></P></FORM></div>");
                
                pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\footer.html"));

    }

}


