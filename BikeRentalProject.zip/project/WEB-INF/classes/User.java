 class User
 {
    
    private String username;
    private String userpassword;
    private String usertype;
    private String email;
    private Integer phonenumber;
   
    
    public User()
    {}

    public User(String username,String userpassword,String usertype,String email,Integer phonenumber)
    {
        this.username = username;
        this.userpassword = userpassword;
        this.usertype = usertype;
        this.email=email;
        this.phonenumber=phonenumber;
       
    }
   
    
    public String getusername(){
        return this.username;
    }
   
    
    public String getuserpassword(){
        return this.userpassword;
    }

    public String getusertype()
    {
         return this.usertype;
    }

    public String getemail()
    {
         return this.email;
    }

    public Integer getphonenumber()
    {
         return this.phonenumber;
    }
     
}