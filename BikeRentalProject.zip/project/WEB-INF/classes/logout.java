import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
//import org.apache.catalina.User;

public class logout extends HttpServlet 
{

public String readData(String filename) 
				{
		   			File file = new File(filename);
		   			try 
		   			{
			           byte[] bytesRead = Files.readAllBytes(file.toPath());
				       return new String(bytesRead, "UTF-8");
	        		} 
	        		catch (Exception e) 
	        		{
	        		}
	        		return null;
	    		}
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
	{

				String username = request.getParameter("uname");
                HttpSession sessionhttp = request.getSession();
                sessionhttp.setAttribute("username", username);
                

                String user = (String)sessionhttp.getAttribute("username");
                PrintWriter pw = response.getWriter();
                if (user != null) 
                {
                	pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\HW1\\mainpage.html").replaceAll("guest", user));
            	} 
            	else 
            	{
            		pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\HW1\\index.html"));
            	}

                pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\HW1\\index.html"));
                pw.println(" <div id='content'> ");
	            sessionhttp.invalidate();  
	              
	          //  pw.print("<br><h3>You are successfully logged out!</h3></div>");
               //pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\HW1\\footer.html"));

    }

    
}


