import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.nio.file.Files;
import java.util.HashMap;
import java.sql.*;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;

public class register extends HttpServlet{ 

	static Logger logger = Logger.getLogger("register.class");

	public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
	{
		HttpSession session = request.getSession();
		response.setContentType("text/html;charset=UTF-8");
		String username = (String) session.getAttribute("sessionusername"); 
                PrintWriter p = response.getWriter();
                String usrname = request.getParameter("username");
                String email = request.getParameter("Email");
                Integer phone = Integer.parseInt(request.getParameter("Phone"));
                String password = request.getParameter("password");
                String usertype = request.getParameter("usertype");
                logger.info("HORRORSERVLET: inside the TESTING OF BOOKS"+usertype+"77777777777777777777777"); 
                String errormsg = null;

                if(email == null|| email.equals("")){
                        errormsg = "Email is empty";
                }
                if(phone == null||phone.equals("")){
                        errormsg = "Phone is invalid";
                }
                if(password == null||password.equals("")){
                        errormsg = "password is empty";
                }
                if(usrname == null|| usrname.equals("")){
                        errormsg = "name is empty";
                }
                if(usertype == null|| usertype.equals("")){
                        usertype = "usertype is empty";
                }

	}
}