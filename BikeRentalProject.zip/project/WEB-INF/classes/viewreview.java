import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Logger;

public class viewreview extends HttpServlet 
{
  public void init() throws ServletException
  {
    
    }
     
  public String readData(String filename) 
        {
            File file = new File(filename);
            try 
            {
                 byte[] bytes = Files.readAllBytes(file.toPath());
               return new String(bytes, "UTF-8");
              } 
              catch (Exception e) 
              {
              }
              return "";
          
          }

          public static Logger LOGGER = Logger.getLogger("InfoLogging");
          

  public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
  {
                PrintWriter pw = response.getWriter();
                String msg;
                HttpSession sessionHttp = request.getSession();
        
                cart shoppingCart= (cart) sessionHttp.getAttribute("cart");
                String username= (String) sessionHttp.getAttribute("sessionusername"); 
               
                
                if(username!=null)
                {                   
                    pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\header.html").replaceAll("guest", username));
                    msg="successfully login";
                } 
                else 
                {
                    pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\header.html"));
                    
                }
                pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\navigationbar.html"));
                pw.println(" < <div class='content' id='about'> ");
               
                String productname = request.getParameter("productname");
                MongoDBDataStoreUtilities mongodbobject;
                mongodbobject = new MongoDBDataStoreUtilities();

                ArrayList<Review> listOfReview = mongodbobject.selectReview(productname);
                int j=0;
                for(Review review : listOfReview)
                {
                   LOGGER.info("view: inside the TESTING OF BOOKS");
                    j++;
                LOGGER.info("VIEWRIEW: inside the TESTING OF BOOKS");

                  pw.println("<h4 align='center' STYLE='font-weight: bold; color: black;' >Review  "+j+"</h4>");
                   pw.println("Product Name="+review.getproductname()+"<br>");
                  
                  pw.println("Product Category="+ review.getpcategory()+"<br>");
                  pw.println("Retailer="+ review.getpretailer()+"<br>");
                  pw.println("Retailer Zip="+ review.getpretailerzip()+"<br>");
                  pw.println("Retailer city"+ review.getpretailercity()+"<br>");
                  pw.println("Retailer state"+ review.getpretailerstate()+"<br>");
                  pw.println("Product on Sale?"+ review.getponsale()+"<br>");
                  pw.println("Manufacturer Name"+ review.getpmanufacturename()+"<br>");
                  pw.println("Manufacturer Rebate?"+ review.getprebate()+"<br>");
                  pw.println("User Id =" + review.getouserid()+"<br>");
                  pw.println("User Age="+ review.getpuserage()+"<br>");
                  pw.println("User Gender="+ review.getpusergender()+"<br>");
                  pw.println("User Occupation="+ review.getpuseroccupation()+"<br>");
                  pw.println("Product Rating="+review.getprating()+"<br>");
                  pw.println("Review date="+review.getpdate()+"<br>");
                  pw.println("Review Text="+ review.getpreview()+"<br><hr>");
                }
                pw.println("</div>");
                pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\footer.html"));

 }
}