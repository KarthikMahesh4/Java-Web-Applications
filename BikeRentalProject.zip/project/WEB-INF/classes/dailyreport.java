 class dailyreport
 {
    private int totalsales;
    private String dailydates;

    
    public dailyreport()
    {}

    public dailyreport(int totalsales,String dailydates)
    {
        this.totalsales=totalsales;
        this.dailydates=dailydates;
    }
    

    public int gettotalsales(){
        return this.totalsales;
    }

    public String getdailydates() {
        return this.dailydates;
    }

    public String ToString()
    {
         return this.totalsales+" "+this.dailydates;
    }
     
}