 class inventory
 {
    private String producttype;
    private String productname;
	private String pickup;
    private double price;
    private int quantity;
    private int discount;

    
    public inventory()
    {}

    public inventory(String producttype, String productname, double price, String pickup, int discount,int quantity)
    {
        this.producttype = producttype;
        this.productname = productname;
        this.price = price;
		this.pickup=pickup;
		this.discount=discount;
        this.quantity = quantity;
    }
    
    public String getproducttype(){
        return this.producttype;
    }
	
	public String getproductname(){
        return this.productname;
    }
    
    public double getprice(){
        return this.price;
    }
	
	public String getpickup(){
        return this.pickup;
    }
    
    public int getdiscount(){
        return this.discount;
    }
       
    public int getquantity(){
        return this.quantity;
    }

    public String ToString()
    {
         return this.producttype+" "+this.productname+" "+this.price+" "+this.pickup+" "+this.discount+" "+this.quantity;
    }
     
}