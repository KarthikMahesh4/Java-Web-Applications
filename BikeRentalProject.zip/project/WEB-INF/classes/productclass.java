public class productclass {
    private String product_type;
    private String product_id;
    private String product_image;
    private String product_name;
   // private String product_condition;
    private int product_price;
    private int product_rebate;
    private int product_quantity;

    public productclass() {
    }

    public productclass(String product_type, String product_id, String product_image, String product_name, int product_price, int product_rebate, int product_quantity) {
        this.product_type = product_type;
        this.product_id = product_id;
        this.product_image = product_image;
        this.product_name = product_name;
       // this.product_condition = product_condition;
        this.product_price = product_price;
        this.product_rebate = product_rebate;
        this.product_quantity = product_quantity;
    }

    public String getProduct_type() {
        return product_type;
    }

    public String getProduct_id() {
        return product_id;
    }

    public String getProduct_image() {
        return product_image;
    }

    public String getProduct_name() {
        return product_name;
    }

   /* public String getProduct_condition() {
        return product_condition;
    }*/

    public int getProduct_price() {
        return product_price;
    }

    public int getProduct_rebate() {
        return product_rebate;
    }

    public int getProduct_quantity() {
        return product_quantity;
    }

    @Override
    public String toString() {
        return "productclass{" +
                "product_type='" + product_type + '\'' +
                ", product_id=" + product_id +
                ", product_image='" + product_image + '\'' +
                ", product_name='" + product_name + '\'' +
               // ", product_condition='" + product_condition + '\'' +
                ", product_price=" + product_price +
                ", product_rebate=" + product_rebate +
                ", product_quantity=" + product_quantity +
                '}';
    }
}