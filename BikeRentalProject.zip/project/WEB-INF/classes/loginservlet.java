import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.SQLException;
import java.util.logging.Logger;

public class loginservlet extends HttpServlet 
{
    public String readData(String filename) 
                {
                    File file = new File(filename);
                    try 
                    {
                       byte[] bytesRead = Files.readAllBytes(file.toPath());
                       return new String(bytesRead, "UTF-8");
                    } 
                    catch (Exception e) 
                    {
                    }
                    return null;
                }

    public static Logger LOGGER = Logger.getLogger("InfoLogging");
    public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
    {
                String username = request.getParameter("Username");
                String userpassword = request.getParameter("Password");
                MySqlDataStoreUtilities mysqlObject;
                PrintWriter pw = response.getWriter();
                mysqlObject = new MySqlDataStoreUtilities();
				System.out.println("mysql object created for login");
				System.out.println("parameters are " + username +userpassword );
                int j=0;
                try
                {
					
				System.out.println("initiating get user now");
                    j = mysqlObject.getUser(username,userpassword);
					
				System.out.println("getuser completed");
                } 

                catch (SQLException ex) 
                {
                    Logger.getLogger(loginservlet.class.getName()).log(Level.SEVERE, null, ex);
                }

                String msg=null;

                if( username!=null)
                {   
                    HttpSession session=request.getSession();  
                    session.setAttribute("sessionusername",username);
                    pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\header.html").replaceAll("guest", username));
                    //pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\content.html"));

                    String uType=null;

                    try
                    {
                        uType = mysqlObject.getUserType(username,userpassword);
                        System.out.println(uType);
                    } 

                    catch (SQLException ex) 
                    {
                        Logger.getLogger(loginservlet.class.getName()).log(Level.SEVERE, null, ex);
                    }


                    if(uType.equals("manager")){
                         pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\navigation.html"));
                         LOGGER.info("LoginServlet: inside the if(uType==manager)");
                    } else{
                         pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\navigationbar.html"));
                        LOGGER.info("LoginServlet: inside the if(uType==manager) in else");
                    }
                }
                else                
				{
                    pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\header.html"));
                    msg="username or password is incorrect. Please try again with the proper one";
                    pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\navigationbar.html"));
					pw.println(" <div id='content'> ");
					pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\content.html"));
					// pw.println("<h2>"+msg+"</h2>");
					pw.println("</div>");

                }

                pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\footer.html"));
                

    }
}