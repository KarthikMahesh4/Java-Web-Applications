import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.nio.file.Files;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import org.xml.sax.SAXException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class addtocart extends HttpServlet 
{

    public static Logger LOGGER = Logger.getLogger("InfoLogging"); 
    
    public String readFile(String filename) 
                {
                    File f = new File(filename);
                    try 
                    {
                       byte[] bytes = Files.readAllBytes(f.toPath());
                       return new String(bytes, "UTF-8");
                    } 
                    catch (Exception e) 
                    {
                      e.printStackTrace();
                    }
                    return "";
            
                }

    public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
    {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        HttpSession session = request.getSession();
        
        cart shoppingCart;

        shoppingCart = (cart) session.getAttribute("cart");

        if(shoppingCart == null)
        {
          shoppingCart = new cart();
          session.setAttribute("cart", shoppingCart);
        }

        String pname = request.getParameter("name");
        
        double pprice = Double.parseDouble(request.getParameter("buyprice"));
        
        LOGGER.info("AddToCart Starting: Value of pname = "+pname);
        
        LOGGER.info("AddToCart Starting: Value of pname = "+pprice);

        shoppingCart.addToCart(pname, pprice);

        session.setAttribute("cart", shoppingCart);
        
        
        String username = (String) session.getAttribute("sessionusername"); // session is set

           
                String msg;
                String hdr = readFile("C:\\apache-tomcat-7.0.34\\webapps\\project\\header.html");
                
                if(session!=null)
                {                   
                    out.println(hdr.replaceAll("guest", username));
                    msg="successfully login";
                } 
                
                else 
                {
                    out.println(hdr);
                    
                }
        
                out.println(readFile("C:\\apache-tomcat-7.0.34\\webapps\\project\\navigationbar.html"));
                out.println(" <div class='content'> ");
                
                out.println("<h1>Item successfully added </h1>");
                out.println("<form action='mainpage.html'>Continue shopping...<input style='background-color: #121D33; color: white;' type='submit' value='Add more items'></form>");
                out.println("<hr>");
                out.println("<h2>Cart</h2>");

            HashMap<String, Double> items = shoppingCart.getcartitems();


            out.println("<table class='table' border='1px'>");
           
            out.println("<tr>");

            out.println("<th style='background-color: #121D33; color: white;'>");
            out.println("Product");
            out.println("</th>");

            out.println("<th style='background-color: #121D33; color: white;'>");
            out.println("price");
            out.println("</th>");

            out.println("<th style='background-color: #121D33; color: white;'>");
            out.println("Action");
            out.println("</th>");

            out.println("</tr>");

            
            for (String key: items.keySet())
            {
                out.println("<tr>");
                out.println("<td>");
                String itemkey =key;

                String value = items.get(key).toString();  
                out.println(itemkey);
                out.println("</td>");

                out.println("<td>");
                out.println("$"+value);
                out.println("</td>");

                out.println("<td>");
                out.println("<form  method = 'get' action = 'deletefromcart'>");
                out.println("<input style='background-color: #121D33; color: white;' type = 'submit' name = 'Remove' value = 'Remove Item'>");
                out.println("<input type = 'hidden' name='productname' value="+itemkey+">");
                out.println("</form>");

                // out.println("<form  method = 'get' action = 'addtowishlist'>");
                // out.println("<input type = 'hidden' name='productname' value='"+itemkey+"'>");
                // out.println("<input style='background-color: #121D33; color: white;' type = 'submit' name='Save to Wishlist' value='AddWishlist'>");
                // out.println("</form>");
                out.println("</td>");
                out.println("</tr>");

            } 

                out.println("</table>");
                out.println("<form  method = 'get' action = 'checkout'>");
                out.println("<input style='background-color: #121D33; color: white;' type = 'submit' name = 'buy' value = 'Checkout'>");
                out.println("</form>");
               




                //Carousel

                out.println("<h2>Frequently bought together</h2>");

                //TODO: Get product type of that product which was added to cart
                String ptype = request.getParameter("producttype");
                String pauthor = request.getParameter("author");
                Connection conn = null;
                ResultSet res = null;

                try{
                    Class.forName("com.mysql.jdbc.Driver").newInstance();
                    conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/cs584","root","root");
                    String order = "Select * from product where producttype='"+ptype+"' or author='"+pauthor+"' order by author";
                    PreparedStatement checkuserstmt = conn.prepareStatement(order);
                    res=checkuserstmt.executeQuery();

                    int i=0;

                    out.println("<div id='myCarousel' class='carousel slide'>"+

                                    "<div class='carousel-inner'>");

                    while(res.next()){
                                //int id = res.getInt("id");
                                String type = res.getString("producttype");
                                String img = res.getString("image");
                                String name = res.getString("productname");
                                String isbn = res.getString("isbn");
                                String desc = res.getString("description");
                                String author = res.getString("author");
                                double buyprice = res.getDouble("buyprice");
                                double rentprice = res.getDouble("rentprice");
                                double sellprice = res.getDouble("sellprice");
                                LOGGER.info("AddToCart: Value of pname in while = "+type+name+author+buyprice);

                                if(i==0){
                                    i++;
                                    out.println("<div class='item active'>"+
                                    "<form method='get' action='addtocart'>"+
                                    "<img src='"+img+"' alt='first slide' style='width: 300px; height: 350px; align: center; margin-left: 200px;''>"+
                                    "<input style='background-color: #121D33; color: white; margin-left: 100px; font-size: 20px;' type='submit' name='Add to Cart' value='Buy' >"+
                                    "<input type = 'hidden' name='name' value='"+name+"'>"+
                                    "<input type = 'hidden' name='type' value='"+type+"'>"+
                                    "<input type = 'hidden' name='author' value='"+author+"'>"+
                                    "<input type = 'hidden' name='buyprice' value='"+buyprice+"'>"+
                                    "</form>"+

                                    "<form method='get' action='Horror'>"+
                                    
                                    "<input style='background-color: #121D33; color: white; margin-left: 300px; font-size: 20px;' type='submit' name='Add to Cart' value='Click here for other options' >"+
                                    "<input type = 'hidden' name='name' value='"+name+"'>"+
                                    "<input type = 'hidden' name='type' value='"+type+"'>"+
                                    "<input type = 'hidden' name='author' value='"+author+"'>"+
                                    "<input type = 'hidden' name='buyprice' value='"+buyprice+"'>"+
                                    "</form>"+

                                    "</div>");
                                }else{
                                    i++;
                                    out.println("<div class='item'>"+
                                    "<form method='get' action='addtocart'>"+
                                    "<img src='"+img+"' alt='second slide' style='width:200px; height:350px; margin-left: 200px;''>"+
                                    "<input style='background-color: #121D33; color: white; margin-left: 100px; font-size: 20px;' type='submit' name='Add to Cart' value='Buy' >"+
                                    "<input type = 'hidden' name='name' value='"+name+"'>"+
                                    "<input type = 'hidden' name='type' value='"+type+"'>"+
                                    "<input type = 'hidden' name='author' value='"+author+"'>"+
                                    "<input type = 'hidden' name='buyprice' value='"+buyprice+"'>"+
                                    "</form>"+

                                    "<form method='get' action='Horror'>"+
                                    "<input style='background-color: #121D33; color: white; margin-left: 300px; font-size: 20px;' type='submit' name='Add to Cart' value='Click here for other options' >"+
                                    "<input type = 'hidden' name='name' value='"+name+"'>"+
                                    "<input type = 'hidden' name='type' value='"+type+"'>"+
                                    "<input type = 'hidden' name='author' value='"+author+"'>"+
                                    "<input type = 'hidden' name='buyprice' value='"+buyprice+"'>"+
                                    "</form>"+

                                    "</div>");
                                }
                  
                    }

                    out.println("</div>"+
                                "<a class='carousel-control left' href='#myCarousel' data-slide='prev'>"+
                                "<span class='icon-prev'></span>"+
                                "</a>"+
                                "<a class='carousel-control right' href='#myCarousel' data-slide='next'>"+
                                "<span class='icon-next'></span>"+
                                "</a>"+
                                "</div>"+
                                "<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>"+
                                "<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js'></script>"+
                                "<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>");

                    out.println("</div>");

                }
                 catch(Exception ex){
                    ex.printStackTrace();
                }


                out.println("</div>");
                
                out.println(readFile("C:\\apache-tomcat-7.0.34\\webapps\\project\\footer.html"));

    }

}