import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.nio.file.Files;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


public class barGraph extends HttpServlet 
{

  public static Logger LOGGER = Logger.getLogger("InfoLogging"); 

  public void init() throws ServletException
  {
    
    } // Get a set of the entries
     
  public String readFile(String filename) 
        {
            File f = new File(filename);
            try 
            {
                 byte[] bytes = Files.readAllBytes(f.toPath());
               return new String(bytes, "UTF-8");
              } 
              catch (Exception e) 
              {
              //  e.printStackTrace();
              }
              return "";
          
          }

  public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
  {
      try {
          HttpSession session = request.getSession();
          
          cart shoppingCart;
          
          shoppingCart = (cart) session.getAttribute("cart");
          // HttpSession session = request.getSession(true);
          String username;
          username = (String) session.getAttribute("sessionusername"); // session is set
          
          PrintWriter out = response.getWriter();
          String msg;
          String hdr = readFile("C:\\apache-tomcat-7.0.34\\webapps\\project\\header.html");
          
          if(username!=null)
          {
              out.println(hdr.replaceAll("guest", username));
              msg="successfully login";

              out.println(readFile("C:\\apache-tomcat-7.0.34\\webapps\\project\\navigation.html"));
              out.println(" <div class='content' id='about'> ");

              MySqlDataStoreUtilities mysqlObject;
              mysqlObject = new MySqlDataStoreUtilities();
              // int j=0;
              
              HashMap<String, productclass> result = mysqlObject.getProdDetailsForBarGraph();

              out.println(" <div id='chart_div'></div> ");


             out.println(    "<script type='text/javascript'>"+

              // Load the Visualization API and the corechart package.
              "google.charts.load('current', {'packages':['corechart']});"+

              // Set a callback to run when the Google Visualization API is loaded.
              "google.charts.setOnLoadCallback(drawChart);"+

              // Callback that creates and populates a data table,
              // instantiates the pie chart, passes in the data and
              // draws it.
              "function drawChart() {"+

                // Create the data table.
                "var data = new google.visualization.DataTable();"+
                "data.addColumn('string', 'Prod_ID');"+
                "data.addColumn('number', 'Quantity');"     );


             for(String i : result.keySet())
                    {
                      productclass odobj = result.get(i);

                      // out.println("["+"'"+odobj.getProduct_name()+"'"+","+odobj.getProduct_quantity()+"]");

                      out.println("data.addRows([['"+odobj.getProduct_name()+"',"+odobj.getProduct_quantity()+"]])");

                      LOGGER.info("barGraph.java: keyValue pair new : " + '['+odobj.getProduct_name()+','+odobj.getProduct_quantity()+']');

                      // LOGGER.info("barGraph.java: keyValue pair old : " + "["+"'"+odobj.getProduct_id()+"'"+","+odobj.getProduct_quantity()+"]");
                     
                    }

              out.println("var options = {'title':'Bar Chart shows the number of items available for every product','width':650,'height':1000};"+

                "var chart = new google.visualization.BarChart(document.getElementById('chart_div'));"+
                "chart.draw(data, options);}"+
            "</script>");


          
          out.println("</div>");
          
          out.println(readFile("C:\\apache-tomcat-7.0.34\\webapps\\project\\footer.html"));

          }
          
          else
          {
              out.println(hdr);
              out.println(readFile("C:\\apache-tomcat-7.0.34\\webapps\\project\\navigation.html"));
              out.println(" <div id='content'> ");
              out.println("<h3 Style=' color: black;'>Too see the order first do the login");
              out.println("</h3>");
              out.println("</div>");
          
              out.println(readFile("C:\\apache-tomcat-7.0.34\\webapps\\project\\footer.html"));
              
          }
          
          
          
      } catch (Exception ex) {
          Logger.getLogger(orderservlet.class.getName()).log(Level.SEVERE, null, ex);
      }

    }


 }