import java.io.*;
import javax.servlet.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.HashMap;
import javax.servlet.http.*;
import java.nio.file.Files;



import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
//import org.apache.catalina.User;
import java.util.logging.Level;
import java.util.logging.Logger;

public class index extends HttpServlet 
{

    public void init() throws ServletException
    {
        productsaxparser productsaxparserobj=null;
        try 
        {


					System.out.println("entered index begin parser");
                    SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
            
                    SAXParser saxParser = saxParserFactory.newSAXParser();

                    productsaxparserobj = new productsaxparser();

                    saxParser.parse(new File("C:\\apache-tomcat-7.0.34\\webapps\\project\\BikeCatalog.xml"), productsaxparserobj);

                logger.info("Parsed successfully"); 
                HashMap<String,product> map = productsaxparserobj.getproductlist();
                //Class.forName("com.mysql.jdbc.Driver").newInstance();
                logger.info("Before"); 
                Connection conn = null;
                Class.forName("com.mysql.jdbc.Driver").newInstance();
                conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/cs584","root","Password@123");
				System.out.println("inside index- sql conection created");
                logger.info("After");
                Statement stTruncate = conn.createStatement();
                stTruncate.executeUpdate("Truncate table product");
				System.out.println("inside index- products truncated");
                //logger.info("Deleted");


                 for(String key : map.keySet()) 
                 {

                    product productobj=map.get(key);
                    int id = productobj.getId();
                    String type = productobj.getType();
                    String img = productobj.getImage();
                    String name = productobj.getName();
                    String isbn = productobj.getIsbn();
                    String description = productobj.getDescription();
                    String Author = productobj.getAuthor();
                    Double bprice = productobj.getBuyPrice();
                    Double sprice = productobj.getSellPrice();
                    Double rprice = productobj.getRentPrice();
                    int rebate = productobj.getRebate();
                    int quantity = productobj.getQuantity();



   
					System.out.println("inside index- insert product");
                    String insertIntoCustomerRegisterQuery = "INSERT INTO product(productid,producttype,image,productname,isbn,description,author,buyprice,rentprice,sellprice,rebate,quantity) VALUES (?,?,?,?,?,?,?,?,?,?,?,?);";
            
                    PreparedStatement pst = conn.prepareStatement(insertIntoCustomerRegisterQuery);
                    
                    pst.setInt(1,id);
                    pst.setString(2,type);
                    pst.setString(3,img);
                    pst.setString(4,name);
                    pst.setString(5,isbn);
                    pst.setString(6,description);
                    pst.setString(7,Author);
                    pst.setDouble(8,bprice);
                    pst.setDouble(9,sprice);
                    pst.setDouble(10,rprice);
                    pst.setInt(11,rebate);
                    pst.setInt(12,quantity);


                    pst .executeUpdate();
					System.out.println("inside index- insert product completed");
                    }
                    }
                    catch(Exception ex){
						System.out.println("inside index- first exception");
                        ex.printStackTrace();
                    }
                
         
}
	public String readData(String filename) 
				{
		   			File file = new File(filename);
		   			try 
		   			{
			           byte[] bytesRead = Files.readAllBytes(file.toPath());
				       return new String(bytesRead, "UTF-8");
	        		} 
	        		catch (Exception e) 
	        		{
	        		}
	        		return null;
	    		}
	static Logger logger = Logger.getLogger("register.class");
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
	{
                HttpSession httpsession = request.getSession();
                String username = request.getParameter("uname");
                httpsession.setAttribute("username", username);
                String user = (String)httpsession.getAttribute("username");
                PrintWriter pw = response.getWriter();
                if (user != null) 
                {
                	pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\index.html").replaceAll("guest", user));
            	} 
            	else 
            	{
            		pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\index.html"));
            	}
    }

    public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
	{
		String username = request.getParameter("username");
        String password = request.getParameter("password");
        String email =  request.getParameter("Email");
        Integer phone = Integer.parseInt(request.getParameter("Phone"));
        String usertype =  request.getParameter("usertype");
        logger.info("HORRORSERVLET: inside the TESTING OF BOOKS"+usertype+"************************"); 

		PrintWriter pw = response.getWriter();
		
		MySqlDataStoreUtilities mysqlObject;
        mysqlObject = new MySqlDataStoreUtilities();
        
		String msg = null;
            try {
                msg = mysqlObject.insertUser(username,password,usertype,email,phone);
            }
            catch (Exception ex) {
                Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
            }
           	pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\index.html"));

}
}
