
import java.util.ArrayList;
import java.util.List;
import java.lang.*;
import java.util.HashMap;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;



public class productsaxparser extends DefaultHandler 
{

  
  public product productobj = null;
  public HashMap<String, product> listofproducts = null;
  public productsaxparser() {}
  public HashMap<String, product> getproductlist() {
  return listofproducts;
}  
    
    boolean bid = false;
    boolean bimage = false;
    boolean bname = false;
    boolean bproducttype = false;
    boolean bpickup = false;
    boolean bdescr = false;
    boolean brentprice = false;
    boolean blendprice = false;
    boolean bquantity = false;
	boolean bdiscount = false;

    public void startElement(String uri, String localName, String Name, Attributes attributes) throws SAXException 
    {

        if (Name.equalsIgnoreCase("bike")) 
        {
            
            String id = attributes.getValue("id");
            String type= attributes.getValue("type");
            productobj = new product();
            productobj.setId(Integer.parseInt(id));
            productobj.setType(type);
            if (listofproducts == null)
                listofproducts = new HashMap();
                listofproducts.put(id,productobj);    

        }

        else if (Name.equalsIgnoreCase("image")) 
        {
            //set boolean values for fields, will be used in setting Employee variables
            bimage = true;
        } 

        else if (Name.equalsIgnoreCase("name")) 
        {
            bname = true;
        }

        else if (Name.equalsIgnoreCase("pickup")) 
        {
            bisbn = true;
        }
        else if (Name.equalsIgnoreCase("rentPrice")) 
        {
            bdescription = true;

        }
        else if (Name.equalsIgnoreCase("author")) 
        {
            bauthor = true;
        }
        else if (Name.equalsIgnoreCase("buyprice")) 
        {
            bbuyprice = true;
        }
        else if (Name.equalsIgnoreCase("rentprice")) 
        {
            brentprice = true;
        }
        else if (Name.equalsIgnoreCase("sellprice")) 
        {
            bsellprice = true;
        }
        else if (Name.equalsIgnoreCase("rebate")) 
        {
            brebate = true;
        }
        else if (Name.equalsIgnoreCase("quantity")) 
        {
            bquantity= true;
        }
        
    }

    public void endElement(String uri, String localName, String Name) throws SAXException 
    {
        if (Name.equalsIgnoreCase("product")) 
        {
            //listofproducts.add(productobj);
        }
    }

 
    public void characters(char ch[], int start, int length) throws SAXException 
    {

        if (bimage) 
        {
            //age element, set Employee age
            productobj.setImage(new String(ch, start, length));
            bimage = false;
        } 
        
        else if (bname) 
        {
            productobj.setName(new String(ch, start, length));
            bname = false;
        } 
        
        else if (bisbn) 
        {
            productobj.setIsbn(new String(ch , start , length));
            bisbn = false;
        } 
        
        else if (bdescription) 
        {
            productobj.setDescription(new String(ch, start, length));
            bdescription = false;
        } 
        else if (bauthor) 
        {
            productobj.setAuthor(new String(ch, start, length));
            bauthor= false;
        } 
                
        else if (bbuyprice) 
        {
            productobj.setBuyPrice(Double.parseDouble(new String(ch, start, length)));
            bbuyprice = false;
        }
        else if (brentprice) 
        {
            productobj.setRentPrice(Double.parseDouble(new String(ch, start, length)));
            brentprice = false;
        }
        else if (bsellprice) 
        {
            productobj.setSellPrice(Double.parseDouble(new String(ch, start, length)));
            bsellprice = false;
        }
        else if (brebate) 
        {
            productobj.setRebate(Integer.parseInt(new String(ch, start, length)));
            brebate = false;
        }
        else if (bquantity) 
        {
            productobj.setQuantity(Integer.parseInt(new String(ch, start, length)));
            bquantity = false;
        }
    }
}

