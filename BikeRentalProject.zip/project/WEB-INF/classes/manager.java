import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.nio.file.Files;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
//import org.apache.catalina.User;

public class manager extends HttpServlet 
{
	public void init() throws ServletException
	{
		
    } 

    public String readf(String fname) 
                {
                    File fl = new File(fname);
                    try 
                    {
                       byte[] b = Files.readAllBytes(fl.toPath());
                       return new String(b, "UTF-8");
                    } 
                    catch (Exception e) 
                    {

                    }
                    return "";
            
                }


	public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
	{
                    String userpassword = request.getParameter("upassword");
                    PrintWriter prw = response.getWriter();
                    ResultSet res = null;
                try{
                    Connection conn = null;
                    Class.forName("com.mysql.jdbc.Driver").newInstance();
                    conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/cs584","root","Password@123");
                    PreparedStatement chckusrstmt = conn.prepareStatement("select * from product");
                    res=chckusrstmt.executeQuery();
					PreparedStatement chckusrstmt = conn.prepareStatement("select * from lendbike");
					res2=chckusrstmt.executeQuery();
					System.out.println("select * product executed");
					System.out.println(res);
					System.out.println("completed printing res");
            		HttpSession session = request.getSession();
                	cart shoppingCart = (cart) session.getAttribute("cart");
                    String username= (String) session.getAttribute("sessionusername");
                    String password = (String) session.getAttribute("sessionpassword");
                    MySqlDataStoreUtilities mysqlObject = new MySqlDataStoreUtilities();
                    String msg;
                    String header = readf("C:\\apache-tomcat-7.0.34\\webapps\\project\\header.html");
                
                    if(username!=null)
                    {                   
                      prw.println(header.replaceAll("guest", username));              
                    }else{
                    prw.println(header);
                    }
                    prw.println(readf("C:\\apache-tomcat-7.0.34\\webapps\\project\\navigation.html"));

                    prw.println(" <div class='content' id='about'> ");               
                    if(username==null)
                    { 
                      prw.println("<h3 align='center'>Login as a manager first</h3>");
                    }else{
                    String uType=null;
                    try
                    {
                        uType = mysqlObject.getUserTypeUsingName(username);
                    } 

                    catch (SQLException ex) 
                    {
                       ex.printStackTrace();
                    }

                    if(uType.equals("manager"))
                    { 

                      prw.println("<h3>Insert product here</h3>");       
                      prw.println("<form class = 'submit-button' method = 'get' action = 'insertproduct'>");
                      prw.println("<input class = 'submit-button' type = 'submit' name = 'submit' value = 'insert'>");
                      prw.println("</form><hr>");
                      prw.println("<table><tr>");
                      prw.println("<td>ID</td>");
                      prw.println("<td>Type</td>");
                      prw.println("<td>Name</td>");
                      prw.println("<td>Price</td>");
                      prw.println("<td>Delete</td>");
                      prw.println("<td>Update</td>");
                      prw.println(" </tr>");
                    while (res.next()) 
                    {
						System.out.println("entered while loop in maganer java");
						System.out.println(res.next());
                        String id=(res.getString("productid"));
                        String type=(res.getString("producttype"));
                        String name=(res.getString("productname"));
                        Double price=(res.getDouble("rentprice"));
                        String image =(res.getString("image"));
                        prw.println("<tr>");						
                        prw.println("<td>"+id+"</td>");
                        prw.println("<td>"+type+"</td>");
                        prw.println("<td>"+name+"</td>");
                        prw.println("<td>"+price+"</td>");
                        prw.println("<td>");
                        prw.println("<form class = 'submit-button' method = 'get' action = 'deleteproduct'>");
                        prw.println("<input class = 'submit-button' type = 'submit' name = 'submit' value = 'Delete'>");
                        prw.println("<input type = 'hidden' name='pid' value='"+id+"'>");
                        prw.println("</form></td>");
                        prw.println("<td>");
                        prw.println("<form class = 'submit-button' method = 'get' action = 'updateproduct'>");
                        prw.println("<input class = 'submit-button' type = 'submit' name = 'submit' value = 'Update'>");
                        prw.println("<input type = 'hidden' name='pid' value='"+id+"'>");
                        prw.println("</form></td>");
                        prw.println("</tr>");
                      } 
                        prw.println("</table>");
   
                        }
                      else
                      { 
                       prw.println("<h3 align='center'>Not a manager</h3>");
                      } 
                      }       

                       }
                    catch(Exception ex)
                    {
                      ex.printStackTrace();
                    }       
                  prw.println("</div>");
                  //prw.println(readf("C:\\apache-tomcat-7.0.34\\webapps\\project\\footer.html"));

    }
  }