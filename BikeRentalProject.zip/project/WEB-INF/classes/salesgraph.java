import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.nio.file.Files;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


public class salesgraph extends HttpServlet 
{

  public static Logger LOGGER = Logger.getLogger("InfoLogging"); 

  public void init() throws ServletException
  {
    
    } // Get a set of the entries
     
  public String readData(String filename) 
        {
            File f = new File(filename);
            try 
            {
                 byte[] bytes = Files.readAllBytes(f.toPath());
               return new String(bytes, "UTF-8");
              } 
              catch (Exception e) 
              {
              //  e.printStackTrace();
              }
              return "";
          
          }

  public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
  {
      try {
          HttpSession session = request.getSession();
          PrintWriter pw = response.getWriter();
          String msg;
          cart shoppingCart = (cart) session.getAttribute("cart");
          String username = (String) session.getAttribute("sessionusername"); 
          
          if(username!=null)
          {
              pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\header.html").replaceAll("guest", username));
              msg="successfully login";

              pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\navigation.html"));
              pw.println(" <div class='content' id='about'> ");

              MySqlDataStoreUtilities mysqlObject;
              mysqlObject = new MySqlDataStoreUtilities();
              
              HashMap<String, salesreport> result = mysqlObject.getSalesReport();

              pw.println(" <div id='chart_div'></div> ");
             pw.println(    "<script type='text/javascript' >"+
              "google.charts.load('current', {'packages':['corechart']});"+
              "google.charts.setOnLoadCallback(drawChart);"+
              "function drawChart() {"+
                "var data = new google.visualization.DataTable();"+
                "data.addColumn('string', 'Prod_ID');"+
                "data.addColumn('number', 'TotalSales');");


              for(String i : result.keySet())
                    {
                      salesreport pclass = result.get(i);
                      pw.println("data.addRows([['"+pclass.getproductname()+"',"+pclass.gettotalsales()+"]])");
                     
                    }


              pw.println("var options = {'title':'Chart of Total sales for each Bike','width':800,'height':1000};"+

                "var chart = new google.visualization.BarChart(document.getElementById('chart_div'));"+
                "chart.draw(data, options);}"+
            "</script>");


          HashMap<String, salesreport> resultNew = mysqlObject.getSalesReport();

              pw.println(" <div id='chart_div1'></div> ");
             pw.println(    "<script type='text/javascript' >"+
              "google.charts.load('current', {'packages':['corechart']});"+
              "google.charts.setOnLoadCallback(drawChart);"+
              "function drawChart() {"+
                "var data = new google.visualization.DataTable();"+
                "data.addColumn('string', 'Prod_ID');"+
                "data.addColumn('number', 'Quantity');"     );


              for(String i : resultNew.keySet())
                    {
                      salesreport pclass = resultNew.get(i);
                      pw.println("data.addRows([['"+pclass.getproductname()+"',"+pclass.getquantity()+"]])");
                     
                    }


              pw.println("var options = {'title':'Chart of Total number of rentals for each Bike','width':800,'height':1000};"+

                "var chart = new google.visualization.BarChart(document.getElementById('chart_div1'));"+
                "chart.draw(data, options);}"+
            "</script></div>");
          
          pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\footer.html"));

          }
          
          else
          {
              pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\header.html"));
              pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\navigation.html"));
              pw.println(" <div id='content'> <h3 Style=' color: black;'>Too see the order first do the login");
              pw.println("</h3></div>");
              pw.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\footer.html"));
              
          }
          
          
          
      } catch (Exception ex) {
          Logger.getLogger(orderservlet.class.getName()).log(Level.SEVERE, null, ex);
      }

    }


 }