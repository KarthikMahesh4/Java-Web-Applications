import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.nio.file.Files;
import java.util.HashMap;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;


  public class updateproduct extends HttpServlet 
  {

    public String readf(String fname) 
                {
                    File fl = new File(fname);
                    try 
                    {
                       byte[] b = Files.readAllBytes(fl.toPath());
                       return new String(b, "UTF-8");
                    } 
                    catch (Exception e) 
                    {

                    }
                    return "";
            
                }

  public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
  {

             HttpSession session = request.getSession();
             cart shoppingCart= (cart) session.getAttribute("cart");
             String username = (String) session.getAttribute("sessionusername"); 
             PrintWriter prw = response.getWriter();
             String header = readf("C:\\apache-tomcat-7.0.34\\webapps\\project\\header.html");

             if (username != null) 
                {
                  prw.println(header.replaceAll("guest", username));
              } 
              else 
              {
                prw.println(header);
              }

              prw.println(readf("C:\\apache-tomcat-7.0.34\\webapps\\project\\navigation.html"));
              prw.println(" <div id='content' align='center'> ");
              prw.println("<h3 align='center'>Product Update</h3><hr>");
              String id= request.getParameter("pid");
              try{

              Connection conn = null;
              conn =DriverManager.getConnection("jdbc:mysql://localhost:3306/cs584","root","Password@123");
              ResultSet res = null;
              System.out.println("..first");
              Statement stmt = null;
              stmt = conn.createStatement();
              System.out.println("second");
              res = stmt.executeQuery("select * fROM product WHERE productid='"+id+"'"); 

              System.out.println("..third");
              while(res.next())
                {
                  

                String uid=res.getString("productid");
                String type=res.getString("producttype");
                String name=res.getString("productname");
                Double price=res.getDouble("rentprice");
                String image =res.getString("image");
				String pickup =res.getString("pickup");
                System.out.println("fourth");
              prw.println("<form class = 'submit-button' method = 'post' action = 'updateproduct'> ");            
              prw.println("<table><tr>");
              prw.println("<td>ID</td>  <td><input type='text'  name='pid' value='"+uid+"'></td>");
              prw.println("</tr><tr>");

              prw.println("<td>Type</td> <td><input type='text' name='ptype' value='"+type+"'></td>");
              prw.println("</tr><tr>");
              prw.println("<td>Name</td><td><input type='text' name='pname' value='"+name+"' ></td>");
              prw.println("</tr><tr>");

              prw.println("<td>Price</td>  <td><input type='text' name='pprice' value='"+price+"' ></td>");
              prw.println("</tr><tr>");
			  prw.println("<td>Pickup</td>  <td><input type='text' name='pickup' value='"+pickup+"' ></td>");
              prw.println("</tr><tr>");
              prw.println("<td>Image</td>   <td><input type='text' name='pimg' value='"+image+"' ></td>");
              prw.println("</tr></table>");
       
              prw.println("<input class = 'submit-button' type = 'submit' name = 'submit' value = 'Update'>");
              prw.println("<input type = 'hidden' name='dbid' value='"+uid+"'>");
              prw.println("</form>");
             }

        }
                catch(Exception ex)
                {
                  ex.printStackTrace();
                }
            

                prw.println("</div>");
                prw.println(readf("C:\\apache-tomcat-7.0.34\\webapps\\project\\footer.html"));

    }

    public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
   {

                PrintWriter prw = response.getWriter();
                String id= request.getParameter("pid");
                String dbid= request.getParameter("dbid");
                String type=request.getParameter("ptype");
                String name= request.getParameter("pname");
                String x=request.getParameter("pprice");
                double price= Double.parseDouble(x);
				//int price= Integer.parseInt(x);
                String img= request.getParameter("pimg");
				String pickup= request.getParameter("pickup");         

                try{
                  Class.forName("com.mysql.jdbc.Driver").newInstance();
                  Connection conn = null;
                  conn =DriverManager.getConnection("jdbc:mysql://localhost:3306/cs584","root","Password@123");
                  Statement stmt = null;
                  stmt = conn.createStatement();
                  String updateproduct = "UPDATE product SET productid='"+id+"', producttype='"+type+"', productname='"+name+"', rentprice="+price+", pickup='"+pickup+"', image='"+img+"' WHERE productid='"+dbid+"' ";
                  System.out.println("QUERY="+updateproduct);
                  stmt.executeUpdate(updateproduct);            
                  prw.println("update successful");
                  response.sendRedirect("manager");
        }
        catch(Exception ex)
        {
          ex.printStackTrace();
        }


    }


}

