import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.nio.file.Files;
import java.util.HashMap;
public class deletefromcart extends HttpServlet 
{
  public String readf(String fname) 
                {
                    File fl = new File(fname);
                    try 
                    {
                       byte[] b = Files.readAllBytes(fl.toPath());
                       return new String(b, "UTF-8");
                    } 
                    catch (Exception e) 
                    {

                    }
                    return "";
            
                }
    public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
    {

                response.setContentType("text/html;charset=UTF-8");
        
                HttpSession session = request.getSession();
        
                cart shoppingCart = (cart) session.getAttribute("cart");
        
                String pname = request.getParameter("productname");
        
                shoppingCart.deleteFromCart(pname);
                

                String username = (String) session.getAttribute("sessionusername"); 

                PrintWriter prw = response.getWriter();
                prw.println(readf("C:\\apache-tomcat-7.0.34\\webapps\\project\\header.html"));
 
                prw.println(readf("C:\\apache-tomcat-7.0.34\\webapps\\project\\navigationbar.html"));
                prw.println(" <div class='content' id='about'> ");
                prw.println("<h1>Item successfully Deleted </h1>");
                prw.println("<form action='mainpage.html'>Continue Shopping...<input type='submit' value='add more item'></form>");
                prw.println("<hr><hr>");
                prw.println("<h2>Cart</h2>");

                HashMap<String, Double> items = shoppingCart.getcartitems();

                prw.println("<table class='table' border='1px'>");
           
                prw.println("<tr><th>");
                prw.println("Product");
                prw.println("</th><th>");
                prw.println("price");
                prw.println("</th><th>");
                prw.println("Action");
                prw.println("</th></tr>");
               
               for (String key: items.keySet())
                {
                 
                    String itemkey =key;

                    String value = items.get(key).toString();  
                    prw.println("<tr><td>");
                    prw.println(itemkey);
                    prw.println("</td><td>");
                    prw.println("$"+svalue);
                    prw.println("</td><td>"); 
                    prw.println("<form  method = 'get' action = 'deletefromcart'>");
                    prw.println("<input  type = 'hidden' name = 'productname' value = '"+itemkey+"'>");
                    prw.println("<input style='background-color: #121D33; color: white;'  type = 'submit'  value = 'remove Item'>");
                    prw.println("</form></td></tr>");


/*
                prw.println("<td>");
                prw.println("<form  method = 'get' action = 'deletefromcart'>");
                prw.println("<input  type = 'submit' name = 'buy' value = 'Remove Item'>");
                prw.println("<input type = 'hidden' name='productname' value="+itemkey+">");
                prw.println("</form>");
*/
                } 
            
          
         
                    prw.println("</table>");
                    prw.println("<form  method = 'get' action = 'checkout'>");
                    prw.println("<input  type = 'submit' name = 'buy' value = 'Checkout'>");
                    prw.println("</form></div>");
                
                    prw.println(readf("C:\\apache-tomcat-7.0.34\\webapps\\project\\footer.html"));

    }

}


