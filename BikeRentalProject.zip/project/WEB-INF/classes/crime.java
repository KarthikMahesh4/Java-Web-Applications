import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.nio.file.Files;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.SQLException;
import java.util.logging.Logger;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import org.xml.sax.SAXException;

public class crime extends HttpServlet 
{

    productsaxparser productsaxparserobj;

    public void init() throws ServletException
    {

    }

      public static Logger LOGGER = Logger.getLogger("InfoLogging");

    public String readData(String fname) 
                {
                    File fl = new File(fname);
                    try 
                    {
                       byte[] b = Files.readAllBytes(fl.toPath());
                       return new String(b, "UTF-8");
                    } 
                    catch (Exception e) 
                    {

                    }
                    return "";
            
                }

    public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
    {

                 PrintWriter p = response.getWriter();

                Connection conn = null;
                ResultSet res = null;

                try{
                    Class.forName("com.mysql.jdbc.Driver").newInstance();
                    conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/cs584","root","root");
                    String order = "Select * from product where producttype='crime'";
                    PreparedStatement checkuserstmt = conn.prepareStatement(order);
                    res=checkuserstmt.executeQuery();

                    HttpSession session = request.getSession(true);
                    String username = (String) session.getAttribute("sessionusername");

                    String header = readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\header.html");
                    String msg;
                    if(username != null) 
                    {
                    p.println(header.replaceAll("guest", username));  
                    msg="successfully login";
                    }else{
                    p.println(header);
                    msg ="Login to start ordering";
                    }

                    p.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\navigationbar.html"));
                    p.println("<div class='content' id='about'>");
                    p.println("<h2>Crimes</h2>");
                    p.println("<table>");
                     
                    while(res.next()){
                                //int id = res.getInt("productid");
                                //String type = res.getString("producttype");
                                String type = res.getString("producttype"); 
                                String img = res.getString("image");
                                String name = res.getString("productname");
                                String isbn = res.getString("isbn");
                                String desc = res.getString("description");
                                String author = res.getString("author");
                                double buyprice = res.getDouble("buyprice");
                                double rentprice = res.getDouble("rentprice");
                                double sellprice = res.getDouble("sellprice");
                         
                        
                       p.println("<div id='myTabMain'>");
                        p.println("<ul class='nav nav-tabs'>");
                        p.println("<li class='active'><a data-toggle='tab' href='f#home'>Details</a></li>");
                        p.println("<li class='floatleft'><a data-toggle='tab' href='#menu1'>Buy</a></li>");
                        p.println("<li class='floatleft'><a data-toggle='tab' href='#menu2'>Rent</a></li>");
                        p.println("<li class='floatleft'><a data-toggle='tab' href='#menu3'>Sell</a></li>");
                        p.println("</ul>");   
                        p.println(" <div class='tab-content'>");
                        p.println(" <div id='home' class='tab-pane fade in active'>");
                        p.println("<div class='clearfix'>");
                        p.println("<div class='column menu'>");
                        p.println("<img class='card-img-top1' src='"+img+"' alt='Card image cap'>");
                        p.println("</div>");
                        p.println("<div class='column content1'>");
                        p.println("<h3><span style='color: #FE6D50'>"+name+"</span></h3>");
                        p.println("<p><span style='justify-content:auto;'><b>Description:</b>"+desc+"</span></p>");
                        p.println("<p><b>Authors:</b>"+author+"</p>");
                        p.println("<p><b>ISBN:</b>"+isbn+"</p>");
                        p.println("<input type = 'hidden' name='productname' value='"+name+"'>");
                        p.println("<input type = 'hidden' name='buyprice' value='"+buyprice+"'>");

                         p.println("<form method='get' action='writereview'>");
                        p.println("<input type='submit' name='writereview' value='Write Review'>");
                        p.println("<input type='hidden' name='productname' value='"+name+"'>");
                        p.println("<input type='hidden' name='pcategory' value='"+type+"'>");
                        p.println("</form>");

                        p.println("<form method='get' action='viewreview'>");
                        p.println("<input type='submit' name='viewreview' value='View Review'>");
                        p.println("<input type='hidden' name='productname' value='"+name+"'>");
                        p.println("<input type='hidden' name='pcategory' value='"+type+"'>");
                        p.println("</form>");
                       // p.println("<a href='viewreview'><input type='submit' name='viewreview' value='View Review'></a>");
                        //p.println("<a href='writereview'><input type='submit' name='writereview' value='Write Review'></a>");
                        
                        p.println("<form method='get' action='addtowishlist'>");
                        p.println("<input style='background-color: crimson; color: white' type='submit' name='wishlist' value='Add to WishList'>");
                        p.println("<input type='hidden' name='productname' value='"+name+"'>");
                        p.println("<input type='hidden' name='productprice' value='"+buyprice+"'>");
                        p.println("</form>");
                        p.println("</div></div></div>");
                  
                        p.println("<div id='menu1' class='tab-pane fade'>");
                        p.println("<div class='clearfix'>");
                        p.println("<div class='column menu'>");
                        p.println("<img class='card-img-top1' src='"+img+"' alt='Card image cap'></div>");
                        p.println("<div class='column content1'>");
                        p.println("<h3><span style='color: #FE6D50'>"+name+"</span></h3>");
                        p.println("<p><b>Authors:</b>"+author+"</p>");
                        p.println("<p><b>ISBN:</b>"+isbn+"</p>");
                        p.println("<p><b>Buy Price:</b>"+buyprice+"</p>");
                        p.println("<form class='form-inline pull-xs-left' action='addtocart'>");
                        p.println("<button class='btn btn-primary btn-sm' type='submit'>BUY NOW</button>");
                        // p.println("<input type = 'hidden' name='name' value='"+name+"'>");
                        p.println("<input type = 'hidden' name='buyprice' value='"+buyprice+"'>");
                        p.println("<input type = 'hidden' name='name' value='"+name+"'>");
                        p.println("<input type = 'hidden' name='type' value='"+type+"'>");
                        p.println("<input type = 'hidden' name='author' value='"+author+"'>");
                        p.println("<input type = 'hidden' name='price' value='"+buyprice+"'>");
                        LOGGER.info("HORRORSERVLET: inside the TESTING OF BOOKS"+buyprice+"completed"); 
                        p.println("</form></div></div></div>");
                  
                        p.println("<div id='menu2' class='tab-pane fade'>");
                        p.println("<div class='clearfix'>");
                        p.println("<div class='column menu'>");
                        p.println("<img class='card-img-top1' src='"+img+"' alt='Card image cap'></div>");
                        p.println("<div class='column content1'>");
                        p.println("<h3><span style='color: #FE6D50'>"+name+"</span></h3>");
                        p.println("<p><b>Authors:</b>"+author+"</p>");
                        p.println("<p><b>ISBN:</b>"+isbn+"</p>");
                        p.println("<p><b>Rent Price:</b>"+rentprice+"</p>");
                        p.println("<form class='form-inline pull-xs-left' action='addtocartrent'>");
                        p.println("<button class='btn btn-primary btn-sm' type='submit'>RENT NOW</button>");
                       // p.println("<input type = 'hidden' name='name' value='"+name+"'>");
                        p.println("<input type = 'hidden' name='rentprice' value='"+rentprice+"'>");

                        p.println("<input type = 'hidden' name='name' value='"+name+"'>");
                        p.println("<input type = 'hidden' name='type' value='"+type+"'>");
                        p.println("<input type = 'hidden' name='author' value='"+author+"'>");
                        p.println("<input type = 'hidden' name='price' value='"+rentprice+"'>");
                        p.println("</form></div></div></div>");
                  
                        p.println("<div id='menu3' class='tab-pane fade'>");
                        p.println("<div class='clearfix'>");
                        p.println("<div class='column menu'>");
                        p.println("<img class='card-img-top1' src='bookstore1.jpg' alt='Card image cap'></div>");
                        p.println("<div class='column content1'>");
                        p.println("<h3><span style='color: #FE6D50'>"+name+"</span></h3>");
                        p.println("<p><b>Authors:</b>"+author+"</p>");
                        p.println("<p><b>ISBN:</b>"+isbn+"</p>");
                        p.println("<p><b>Sell Price:</b>"+sellprice+"</p>");
                        p.println("<form class='form-inline pull-xs-left' action='addtocartsell'>");
                        p.println("<button class='btn btn-primary btn-sm' type='submit'>SELL NOW</button>");
                       // p.println("<input type = 'hidden' name='name' value='"+name+"'>");
                        p.println("<input type = 'hidden' name='sellprice' value='"+sellprice+"'>");

                        p.println("<input type = 'hidden' name='name' value='"+name+"'>");
                        p.println("<input type = 'hidden' name='type' value='"+type+"'>");
                        p.println("<input type = 'hidden' name='author' value='"+author+"'>");
                        p.println("<input type = 'hidden' name='price' value='"+sellprice+"'>");
                        p.println("</form></div></div></div></div></div>");
                                    
                    }
                }
                catch(Exception ex){
                    ex.printStackTrace();
                }
                p.println("<table></div>");
                p.println(readData("C:\\apache-tomcat-7.0.34\\webapps\\project\\footer.html"));

    }

}


